//! Profile-specific mode mutations. Shared native commands commit parameters
//! in wire order; hosts consume ordered window, archive and sync effects.
use crate::{protocol_state::ProtocolState, screen::ScreenState};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum ModeNamespace {
    Ansi,
    DecPrivate,
}

/// Apply one Ember mode parameter. `false` means a host hook is required and
/// guarantees that both arguments remain completely untouched. In particular,
/// 5522 is host-owned in both directions, even though enabling it is just a bit.
/// Unknown pure modes are handled no-ops, as TerminalModes stores only known bits.
/// DECOM homes the cursor but deliberately preserves pending wrap.
pub fn apply_ember_mode(
    screen: &mut ScreenState,
    protocol: &mut ProtocolState,
    namespace: ModeNamespace,
    mode: u16,
    enabled: bool,
) -> bool {
    match namespace {
        ModeNamespace::Ansi => {
            if mode == 4 {
                screen.insert_mode = enabled;
            }
        }
        ModeNamespace::DecPrivate => match mode {
            1004 | 47 | 1047 | 1048 | 1049 | 2026 | 5522 => return false,
            6 => {
                screen.origin_mode = enabled;
                screen.cursor_row = if enabled { screen.scroll_region_top } else { 0 };
                screen.cursor_col = 0;
            }
            _ => {
                if enabled {
                    protocol.modes_mut().insert(mode);
                } else {
                    protocol.modes_mut().remove(&mode);
                }
            }
        },
    }
    true
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FrostModeEffect {
    None,
    MouseReportingChanged,
    AlternateScreen,
    SynchronizedOutput,
}

/// Apply one FrostLegacyV1 mode parameter. A mouse change requires the host
/// to revoke queued scroll input before proceeding to the next parameter.
/// Alternate screen and sync leave screen and protocol state to the host
/// until it can take the required snapshots and apply the transition.
pub fn apply_frost_mode(
    screen: &mut ScreenState,
    protocol: &mut ProtocolState,
    namespace: ModeNamespace,
    mode: u16,
    enabled: bool,
) -> FrostModeEffect {
    use FrostModeEffect::{AlternateScreen, MouseReportingChanged, None, SynchronizedOutput};

    if namespace == ModeNamespace::Ansi {
        if mode == 4 {
            screen.insert_mode = enabled;
        }
        return None;
    }

    let effect = match mode {
        47 | 1047 | 1049 => return AlternateScreen,
        2026 => return SynchronizedOutput,
        6 => {
            screen.cursor_controls().set_origin_mode(enabled);
            return None;
        }
        1048 => {
            if enabled {
                screen.save_cursor_state(protocol);
            } else {
                // Frost restores the saved drawing state with live DECAWM.
                let _ = screen.restore_cursor();
            }
            None
        }
        1000..=1003 | 1005 | 1006 | 1015 if protocol.modes().contains(&mode) != enabled => {
            MouseReportingChanged
        }
        1 | 7 | 25 | 66 | 1004 | 2004 | 2031 | 5522 => None,
        _ => return None,
    };

    if enabled {
        protocol.modes_mut().insert(mode);
    } else {
        protocol.modes_mut().remove(&mode);
    }
    effect
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeModeProfile {
    Ember,
    FrostLegacy,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum NativeModeEffect {
    None,
    Reply(&'static [u8]),
    RevokePasteGrant,
    MouseReportingChanged,
    AlternateScreen { mode: u16, enabled: bool },
    SynchronizedOutput { enabled: bool },
}

/// One parameter is committed before its effect is returned. The caller must
/// consume that effect before advancing to another parameter or input event.
pub struct NativeModeCommand<'a> {
    profile: NativeModeProfile,
    namespace: ModeNamespace,
    params: std::slice::Iter<'a, u16>,
    enabled: bool,
}

/// Both legacy profiles ignore intermediates for h/l. Ember admits ANSI and
/// DEC-private only; Frost historically treats every other namespace as ANSI.
pub fn prepare_native_mode_command<'a>(
    profile: NativeModeProfile,
    params: &'a [u16],
    cmd: char,
    prefix: Option<u8>,
) -> Option<NativeModeCommand<'a>> {
    let enabled = match cmd {
        'h' => true,
        'l' => false,
        _ => return None,
    };
    let namespace = match prefix {
        Some(b'?') => ModeNamespace::DecPrivate,
        None => ModeNamespace::Ansi,
        _ if profile == NativeModeProfile::FrostLegacy => ModeNamespace::Ansi,
        _ => return None,
    };
    Some(NativeModeCommand {
        profile,
        namespace,
        params: params.iter(),
        enabled,
    })
}

impl NativeModeCommand<'_> {
    pub fn step(
        &mut self,
        screen: &mut ScreenState,
        protocol: &mut ProtocolState,
        focused: bool,
    ) -> Option<NativeModeEffect> {
        let mode = *self.params.next()?;
        Some(apply_native_mode_parameter(
            self.profile,
            screen,
            protocol,
            self.namespace,
            mode,
            self.enabled,
            focused,
        ))
    }
}

/// Apply a single native mode parameter, including the previously host-owned
/// focus/paste bits and Ember's DECSC/DECRC mode. Snapshot/archive and native
/// window clock operations remain ordered callbacks with unchanged policies.
pub fn apply_native_mode_parameter(
    profile: NativeModeProfile,
    screen: &mut ScreenState,
    protocol: &mut ProtocolState,
    namespace: ModeNamespace,
    mode: u16,
    enabled: bool,
    focused: bool,
) -> NativeModeEffect {
    if profile == NativeModeProfile::FrostLegacy {
        return match apply_frost_mode(screen, protocol, namespace, mode, enabled) {
            FrostModeEffect::None => NativeModeEffect::None,
            FrostModeEffect::MouseReportingChanged => NativeModeEffect::MouseReportingChanged,
            FrostModeEffect::AlternateScreen => NativeModeEffect::AlternateScreen { mode, enabled },
            FrostModeEffect::SynchronizedOutput => NativeModeEffect::SynchronizedOutput { enabled },
        };
    }
    if apply_ember_mode(screen, protocol, namespace, mode, enabled) {
        return NativeModeEffect::None;
    }
    match mode {
        1004 => {
            let newly = !protocol.modes().contains(&1004);
            if enabled {
                protocol.modes_mut().insert(1004);
            } else {
                protocol.modes_mut().remove(&1004);
            }
            if enabled && newly && focused {
                NativeModeEffect::Reply(b"\x1b[I")
            } else {
                NativeModeEffect::None
            }
        }
        5522 => {
            if enabled {
                protocol.modes_mut().insert(5522);
                NativeModeEffect::None
            } else {
                protocol.modes_mut().remove(&5522);
                NativeModeEffect::RevokePasteGrant
            }
        }
        1048 => {
            if enabled {
                screen.save_cursor_state(protocol);
                protocol.modes_mut().insert(1048);
            } else {
                screen.restore_cursor_state(protocol);
                protocol.modes_mut().remove(&1048);
            }
            NativeModeEffect::None
        }
        47 | 1047 | 1049 => NativeModeEffect::AlternateScreen { mode, enabled },
        2026 => NativeModeEffect::SynchronizedOutput { enabled },
        _ => unreachable!("legacy pure mutation left an unknown host mode"),
    }
}

#[cfg(test)]
mod command_tests {
    use super::*;
    #[test]
    fn admission_and_focus_reply_are_profiled_and_parameter_ordered() {
        let params = [1004, 1004, 5522];
        let mut screen = ScreenState::new(2, 3);
        let mut protocol = ProtocolState::default();
        let mut command =
            prepare_native_mode_command(NativeModeProfile::Ember, &params, 'h', Some(b'?'))
                .unwrap();
        assert_eq!(
            command.step(&mut screen, &mut protocol, true),
            Some(NativeModeEffect::Reply(b"\x1b[I"))
        );
        assert!(!protocol.modes().contains(&5522));
        assert_eq!(
            command.step(&mut screen, &mut protocol, true),
            Some(NativeModeEffect::None)
        );
        assert_eq!(
            command.step(&mut screen, &mut protocol, true),
            Some(NativeModeEffect::None)
        );
        assert!(protocol.modes().contains(&5522));
        let mut command =
            prepare_native_mode_command(NativeModeProfile::Ember, &[5522], 'l', Some(b'?'))
                .unwrap();
        assert_eq!(
            command.step(&mut screen, &mut protocol, false),
            Some(NativeModeEffect::RevokePasteGrant)
        );
        assert!(!protocol.modes().contains(&5522));
        assert!(
            prepare_native_mode_command(NativeModeProfile::Ember, &params, 'h', Some(b'>'))
                .is_none()
        );
        assert!(prepare_native_mode_command(
            NativeModeProfile::FrostLegacy,
            &params,
            'h',
            Some(b'>')
        )
        .is_some());
    }

    #[test]
    fn cursor_save_restore_mode_is_owned_by_the_engine() {
        let mut screen = ScreenState::new(3, 4);
        let mut protocol = ProtocolState::default();
        screen.cursor_row = 1;
        screen.cursor_col = 2;
        apply_native_mode_parameter(
            NativeModeProfile::Ember,
            &mut screen,
            &mut protocol,
            ModeNamespace::DecPrivate,
            1048,
            true,
            false,
        );
        screen.cursor_row = 0;
        screen.cursor_col = 0;
        apply_native_mode_parameter(
            NativeModeProfile::Ember,
            &mut screen,
            &mut protocol,
            ModeNamespace::DecPrivate,
            1048,
            false,
            false,
        );
        assert_eq!((screen.cursor_row, screen.cursor_col), (1, 2));
    }
}
