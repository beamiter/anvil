//! No-LLM state reducer for the native ASCII organism.
//!
//! This module is toolkit-free. Block panes feed it authoritative
//! command lifecycle events; the UI renders the returned [`Reaction`]. It does
//! not inspect output contents, execute commands, or perform network I/O.

use std::borrow::Cow;
use std::time::Duration;

#[path = "organism_animation.rs"]
mod animation;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum CommandKind {
    BuildOrTest,
    GitPush,
    Other,
}

impl CommandKind {
    const fn label(self) -> &'static str {
        match self {
            Self::BuildOrTest => "build/test",
            Self::GitPush => "git push",
            Self::Other => "command",
        }
    }
}

/// Content-free, repo/day-scoped work facts shared between memory, reducers,
/// and the window coordinator. Repository identity never enters this value;
/// the UI uses it only to route the snapshot to the matching pane bodies.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub struct RepoWorkState {
    pub open_failures: u32,
    pub recovered_pending_push: bool,
    pub failure_success_flips: u32,
}

impl RepoWorkState {
    pub const fn new(
        open_failures: u32,
        recovered_pending_push: bool,
        failure_success_flips: u32,
    ) -> Self {
        Self {
            open_failures,
            // Ordered replay never leaves recovered and failed work open at
            // once. Normalize hostile/runtime callers to the safer failure
            // interpretation instead of creating an ambiguous visible state.
            recovered_pending_push: recovered_pending_push && open_failures == 0,
            failure_success_flips,
        }
    }

    pub const fn vigil(self) -> RepoVigil {
        if self.open_failures >= STUCK_OPEN_FAILURES {
            RepoVigil::Stuck
        } else if self.open_failures > 0 {
            RepoVigil::Failure
        } else if self.recovered_pending_push
            && self.failure_success_flips >= CAUTIOUS_RECOVERY_FLIPS
        {
            RepoVigil::CautiousRecovery
        } else if self.recovered_pending_push {
            RepoVigil::Recovery
        } else {
            RepoVigil::None
        }
    }
}

/// Visible phase of the current repo/day work loop. It is always derived from
/// [`RepoWorkState`], never persisted as a second source of truth.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum RepoVigil {
    #[default]
    None,
    Failure,
    Stuck,
    Recovery,
    CautiousRecovery,
}

impl RepoVigil {
    pub const fn is_active(self) -> bool {
        !matches!(self, Self::None)
    }
}

const STUCK_OPEN_FAILURES: u32 = 3;
const CAUTIOUS_RECOVERY_FLIPS: u32 = 3;

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Behavior {
    Idle,
    WatchCommand,
    InspectError,
    SitNearError,
    Celebrate,
    CelebrateBig,
    RestAfterPush,
    UnknownOutcome,
    /// A live-only orienting cue: another local pane reported a failure. It
    /// never comes from the reducer and carries no command or output content.
    GlanceAside,
    // Ambient dispositions chosen by the utility mind, never by event
    // reactions: they only ever reach the display through AmbientBehavior.
    Sleep,
    Explore,
    Approach,
    /// Crouched a little apart, watching the Shell Agent work — distinct from
    /// WatchCommand so the body shows whose command is running.
    WatchAgent,
    /// Settled in for a long command: still watching, but lying down with
    /// half-closed eyes — a vigil, not a nap.
    WatchSettled,
    /// A failed build is still open in this repo/day. It stays with the work
    /// after the immediate error reaction has settled.
    GuardFailure,
    /// Three or more failures remain open. The lower, quieter posture records
    /// that the loop is stubborn without escalating speech or stimulus.
    GuardStuck,
    /// A recovered build has not been pushed yet. Between real events the cat
    /// stays beside that finished work instead of forgetting it at settle.
    GuardRecovery,
    /// Repeated same-day failure/success flips make the recovery worth checking
    /// again before push; this is caution, not a claim that a test is flaky.
    GuardCautious,
}

// ── Live-body frame sets ────────────────────────────────────────────────
// Every frame within one visual set shares its bounding box (identical line
// count and maximum line width), so the overlay's measured size — and with it
// the fail-closed fit check in `surface_point` — never flaps between frames.
const IDLE_FRAMES: [&str; 2] = [" /\\_/\\\n( -.- )\n > ^ <", " /\\_/\\\n( -.- )\n >~^ <"];
const IDLE_TENSE: &str = " =\\_/=\n( -.- )\n > ^ <";
const YAWN_FRAME: &str = " /\\_/\\\n( >o< )\n > ^ <";
const DOZE_FRAMES: [&str; 2] = [" /\\_/\\\n( =.= )\n  zzZ ", " /\\_/\\\n( =.= )\n   zZ "];
const GAIT_FRAMES: [&str; 2] = [" /\\_/\\\n( o.o )\n >/ \\<", " /\\_/\\\n( o.o )\n >\\ /<"];
const GAIT_TENSE_FRAMES: [&str; 2] = [" =\\_/=\n( o.o )\n >/ \\<", " =\\_/=\n( o.o )\n >\\ /<"];
const WATCH_FRAMES: [&str; 2] = [" /\\_/\\\n( o.o )\n > ^ <", " /\\_/\\\n( o.o )\n >~^ <"];
const WATCH_TENSE_FRAMES: [&str; 2] = [" =\\_/=\n( o.o )\n > ^ <", " =\\_/=\n( o.o )\n >~^ <"];
const WATCH_BUSY_FRAMES: [&str; 2] = [" /\\_/\\\n( o.> )\n > ^ <", " /\\_/\\\n( <.o )\n >~^ <"];
const WATCH_BUSY_TENSE_FRAMES: [&str; 2] = [" =\\_/=\n( o.> )\n > ^ <", " =\\_/=\n( <.o )\n >~^ <"];
const WATCH_WAITING_FRAMES: [&str; 2] =
    [" /\\_/\\\n( -.- )\n (___) ", " /\\_/\\\n( -.o )\n (___) "];
const WATCH_WAITING_TENSE_FRAMES: [&str; 2] =
    [" =\\_/=\n( -.- )\n (___) ", " =\\_/=\n( -.o )\n (___) "];
const WATCH_RESUMED_FRAMES: [&str; 2] = [" /\\_/\\\n( O.O )\n > ^ <", " /\\_/\\\n( o.o )\n >~^ <"];
const WATCH_RESUMED_TENSE_FRAMES: [&str; 2] =
    [" =\\_/=\n( O.O )\n > ^ <", " =\\_/=\n( o.o )\n >~^ <"];
const INSPECT_FRAME: &str = " /\\_/\\  ->\n( o_o )\n /|_|\\";
const SIT_FRAMES: [&str; 2] = [
    " /\\_/\\\n( ._. )  !\n /|_|\\",
    " /\\_/\\\n( ._. )   \n /|_|\\",
];
// Celebration keeps the same cat silhouette as every other behavior; the
// old raised-arm human figure made a successful build look like a different
// character had replaced the organism.
const CELE_FRAMES: [&str; 2] = [
    " /\\_/\\\n<( ^.^ )>\n  > ^ <",
    " /\\_/\\\n<( ^o^ )>\n  > ^ <",
];
const BIG_FRAMES: [&str; 2] = [
    "* /\\_/\\ *\n<( ^o^ )>\n* > ^ < *",
    "  /\\_/\\  \n<( ^o^ )>\n  > ^ <  ",
];
const REST_FRAMES: [&str; 2] = [
    " /\\_/\\\n( ^.^ )  ok\n > ^ <",
    " /\\_/\\\n( ^.^ )  ok\n >~^ <",
];
const UNKNOWN_FRAME: &str = " /\\_/\\\n( ?.? )\n > ^ <";
const GLANCE_ASIDE_FRAMES: [&str; 2] = [" /\\_/\\\n( <.< )\n > ^ <", " /\\_/\\\n( <.< )\n >~^ <"];
const SLEEP_FRAMES: [&str; 2] = [
    " /\\_/\\\n( -_- )zZ\n (___) ",
    " /\\_/\\\n( -_- )Z \n (___) ",
];
const EXPLORE_FRAMES: [&str; 2] = [" /\\_/\\\n( o.o)?\n > ^ <", " /\\_/\\\n?(o.o )\n > ^ <"];
const APPROACH_FRAMES: [&str; 2] = [" /\\_/\\\n( ^.^ )\n > ^ <", " /\\_/\\\n( ^.^ )\n >~^ <"];
const WATCH_AGENT_FRAMES: [&str; 2] = [" /\\_/\\\n( -.o )\n (___) ", " /\\_/\\\n( o.- )\n (___) "];
const WATCH_AGENT_BUSY_FRAMES: [&str; 2] =
    [" /\\_/\\\n( -.> )\n (___) ", " /\\_/\\\n( <.- )\n (___) "];
const WATCH_AGENT_WAITING_FRAMES: [&str; 2] =
    [" /\\_/\\\n( -.- )\n (___) ", " /\\_/\\\n( -.o )\n (___) "];
const WATCH_AGENT_RESUMED_FRAMES: [&str; 2] =
    [" /\\_/\\\n( o.o )\n (___) ", " /\\_/\\\n( -.o )\n (___) "];
const WATCH_SETTLED_FRAMES: [&str; 2] =
    [" /\\_/\\\n( -.- )\n (___) ", " /\\_/\\\n( -.o )\n (___) "];
const WATCH_SETTLED_BUSY_FRAMES: [&str; 2] =
    [" /\\_/\\\n( -.> )\n (___) ", " /\\_/\\\n( <.- )\n (___) "];
const WATCH_SETTLED_WAITING_FRAMES: [&str; 2] =
    [" /\\_/\\\n( ._. )\n (___) ", " /\\_/\\\n( -.- )\n (___) "];
const WATCH_SETTLED_RESUMED_FRAMES: [&str; 2] =
    [" /\\_/\\\n( o.o )\n (___) ", " /\\_/\\\n( -.o )\n (___) "];
const GUARD_FAILURE_FRAMES: [&str; 2] = [
    " /\\_/\\\n( o_o ) [!]\n /|_|\\",
    " /\\_/\\\n( o.o ) [!]\n /|_|\\",
];
const GUARD_STUCK_FRAMES: [&str; 2] = [
    " =\\_/=\n( ._. ) [!!]\n /|_|\\",
    " =\\_/=\n( -.- ) [!!]\n /|_|\\",
];
const GUARD_RECOVERY_FRAMES: [&str; 2] = [
    " /\\_/\\\n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\\n( -.o ) [ok]\n /|_|\\",
];
const GUARD_CAUTIOUS_FRAMES: [&str; 2] = [
    " /\\_/\\\n( ?.? ) [?]\n /|_|\\",
    " /\\_/\\\n( ?.o ) [?]\n /|_|\\",
];

// Semantic pose changes are short, one-shot arcs rather than new reducer
// states. Every frame in one arc has the same three-line bounding box. The UI
// can therefore render the intermediate frames in Full motion, while Calm and
// Static can keep using the canonical destination pose.
const INSPECT_TO_GUARD_FAILURE_FRAMES: [&str; 4] = [
    " /\\_/\\  -->\n( o_o )\n /|_|\\",
    " /\\_/\\  <- \n( o_o ) [!]\n /|_|\\",
    " /\\_/\\     \n( ._. ) [!]\n /|_|\\",
    " /\\_/\\     \n( o_o ) [!]\n /|_|\\",
];
const SIT_TO_GUARD_STUCK_FRAMES: [&str; 4] = [
    " =\\_/=      \n( ._. )  !!\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
// Second open failure settles SitNearError → GuardFailure (still the middle
// vigil tier). Without this arc Full motion snaps while the 1-failure and
// 3+-failure settles animate.
const SIT_TO_GUARD_FAILURE_FRAMES: [&str; 4] = [
    " /\\_/\\     \n( ._. )  !\n /|_|\\",
    " /\\_/\\     \n( ._. ) [!]\n /|_|\\",
    " /\\_/\\     \n( o_o ) [!]\n /|_|\\",
    " /\\_/\\     \n( o.o ) [!]\n /|_|\\",
];
// Sibling heal while still sitting on the second open failure: settle must
// animate SitNearError → GuardRecovery (and Cautious) the same way matching-
// tier Failure/Stuck settles already do.
const SIT_TO_GUARD_RECOVERY_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
const SIT_TO_GUARD_CAUTIOUS_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ?.o ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
// One-failure inspect hold can likewise settle to Recovery/Cautious/Stuck after
// sibling sync changes the idle vigil target during the hold.
const INSPECT_TO_GUARD_RECOVERY_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
const INSPECT_TO_GUARD_CAUTIOUS_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ?.o ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
const INSPECT_TO_GUARD_STUCK_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o ) [! ]\n /|_|\\",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
const CAUTIOUS_TO_RECOVERY_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
// Cross-pane / midnight escalation: an idle GuardFailure retargets to Stuck
// when a sibling admits the third open failure.
const FAILURE_TO_STUCK_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
// Recovery → Cautious when a third same-day flip retargets an idle vigil.
const RECOVERY_TO_CAUTIOUS_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ?.o ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
const FAILURE_TO_RECOVERY_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
const FAILURE_TO_CAUTIOUS_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ?.o ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
const STUCK_TO_RECOVERY_FRAMES: [&str; 4] = [
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
const STUCK_TO_CAUTIOUS_FRAMES: [&str; 4] = [
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ?.o ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
const SETTLED_TO_CELEBRATE_FRAMES: [&str; 4] = [
    " /\\_/\\\n ( -.- ) \n  (___)  ",
    " /\\_/\\\n ( o.o ) \n  > ^ <  ",
    " /\\_/\\\n<( ^.^ )>\n  > ^ <  ",
    " /\\_/\\\n<( ^o^ )>\n  > ^ <  ",
];
const SETTLED_TO_CELEBRATE_BIG_FRAMES: [&str; 4] = [
    "  /\\_/\\  \n ( -.- ) \n  (___)  ",
    "  /\\_/\\  \n<( o.o )>\n  > ^ <  ",
    "* /\\_/\\ *\n<( ^.^ )>\n* > ^ < *",
    "* /\\_/\\ *\n<( ^o^ )>\n* > ^ < *",
];
const CELEBRATE_TO_RECOVERY_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <     ",
    " /\\_/\\      \n ( ^.^ )    \n  > ^ <     ",
    " /\\_/\\      \n( -.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
const CELEBRATE_TO_CAUTIOUS_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <     ",
    " /\\_/\\      \n ( ^.^ )    \n  > ^ <     ",
    " /\\_/\\      \n( ?.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
const CELEBRATE_BIG_TO_RECOVERY_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *   ",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <     ",
    " /\\_/\\      \n( -.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
const CELEBRATE_BIG_TO_CAUTIOUS_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *   ",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <     ",
    " /\\_/\\      \n( ?.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
// Celebrate hold relapse: sibling sync reopens failures while arms are still
// up. Recovery/Cautious settles already animate; Failure/Stuck must not snap.
const CELEBRATE_TO_FAILURE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <     ",
    " /\\_/\\      \n ( ^.^ )    \n  > ^ <     ",
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o.o ) [! ]\n /|_|\\",
];
const CELEBRATE_TO_STUCK_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <     ",
    " /\\_/\\      \n ( ^.^ )    \n  > ^ <     ",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
const CELEBRATE_BIG_TO_FAILURE_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *   ",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <     ",
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o.o ) [! ]\n /|_|\\",
];
const CELEBRATE_BIG_TO_STUCK_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *   ",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <     ",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
const RECOVERY_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
const CAUTIOUS_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
// Failure/Stuck vigil still showing when a push lands: Recovery/Cautious→Rest
// already animate; Failure/Stuck must not snap to RestAfterPush.
const FAILURE_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o.o ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
const STUCK_TO_REST_FRAMES: [&str; 4] = [
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
    " =\\_/=      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
// Error hold still showing when a pass arrives: WatchSettled→Celebrate already
// animates; Inspect/SitNear must not snap into Celebrate/CelebrateBig.
const INSPECT_TO_CELEBRATE_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n<( ^o^ )>   \n  > ^ <",
];
const INSPECT_TO_CELEBRATE_BIG_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
];
// Inspect hold still showing when a second open failure lands without Watch:
// Unknown/Celebrate/Rest/Recovery→SitNear already animate; Inspect must not snap.
const INSPECT_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
];
// Error hold still showing when a missing-exit finish lands: Celebrate/Rest/
// Recovery→Unknown already animate; Inspect/SitNear must not snap to Unknown.
const INSPECT_TO_UNKNOWN_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\      \n( ?.o )     \n > ^ <",
    " /\\_/\\      \n( ?.? )     \n > ^ <",
];
const SIT_TO_UNKNOWN_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( ?.o )     \n > ^ <",
    " /\\_/\\      \n( ?.? )     \n > ^ <",
];
const SIT_TO_CELEBRATE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n<( ^o^ )>   \n  > ^ <",
];
const SIT_TO_CELEBRATE_BIG_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
];
// Celebrate hold still showing when a push lands: Recovery/Cautious/Failure/
// Stuck→Rest already animate; Celebrate must not snap to RestAfterPush.
const CELEBRATE_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n ( ^.^ )    \n  > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
const CELEBRATE_BIG_TO_REST_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
// Long-watch fail: Celebrate already bridges from WatchSettled; Inspect/SitNear
// must not snap when a settled vigil ends in error.
const SETTLED_TO_INSPECT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- )     \n (___) ",
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  ->  \n( o_o )     \n /|_|\\",
];
const SETTLED_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- )     \n (___) ",
    " /\\_/\\      \n( ._. )     \n (___) ",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
];
// Live watch still showing when the command finishes: WatchSettled already
// bridges from the post-output vigil; WatchCommand/WatchAgent must not snap
// into Celebrate/Inspect/Sit (or RestAfterPush for a push mid-watch /
// mid-settle).
const WATCH_TO_CELEBRATE_FRAMES: [&str; 4] = [
    " /\\_/\\\n ( o.o ) \n  > ^ <  ",
    " /\\_/\\\n ( o.o ) \n  > ^ <  ",
    " /\\_/\\\n<( ^.^ )>\n  > ^ <  ",
    " /\\_/\\\n<( ^o^ )>\n  > ^ <  ",
];
const WATCH_TO_CELEBRATE_BIG_FRAMES: [&str; 4] = [
    "  /\\_/\\  \n ( o.o ) \n  > ^ <  ",
    "  /\\_/\\  \n<( o.o )>\n  > ^ <  ",
    "* /\\_/\\ *\n<( ^.^ )>\n* > ^ < *",
    "* /\\_/\\ *\n<( ^o^ )>\n* > ^ < *",
];
const WATCH_TO_INSPECT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  ->  \n( o_o )     \n /|_|\\",
];
const WATCH_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( ._. )     \n > ^ <",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
];
const WATCH_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
const WATCH_AGENT_TO_CELEBRATE_FRAMES: [&str; 4] = [
    " /\\_/\\\n ( -.o ) \n  (___)  ",
    " /\\_/\\\n ( o.o ) \n  > ^ <  ",
    " /\\_/\\\n<( ^.^ )>\n  > ^ <  ",
    " /\\_/\\\n<( ^o^ )>\n  > ^ <  ",
];
const WATCH_AGENT_TO_INSPECT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.o )     \n (___) ",
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  ->  \n( o_o )     \n /|_|\\",
];
const WATCH_AGENT_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.o )     \n (___) ",
    " /\\_/\\      \n( ._. )     \n (___) ",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
];
// Agent watch or settled vigil still showing when a push lands: WatchCommand→Rest
// already animates; WatchAgent/WatchSettled must not snap to RestAfterPush.
const WATCH_AGENT_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.o )     \n (___) ",
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
const SETTLED_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- )     \n (___) ",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
// Hold settles back to Idle when repo vigil is clear: Celebrate→Guard* and
// Guard*→Rest exist; Celebrate/Rest→Idle must not snap.
const CELEBRATE_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n ( ^.^ )    \n  > ^ <",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const CELEBRATE_BIG_TO_IDLE_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const REST_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
// UnknownOutcome hold: clear-vigil settle must not snap to Idle, and a first
// open failure that overtakes the hold must not snap to InspectError.
// Success / second-failure overwrites (Celebrate{,Big}, SitNearError) are the
// same hold class. Settling while a repo vigil is still open must not snap to
// GuardFailure/Stuck/Recovery/Cautious either. GlanceAside is live-only, so it
// is not a transition source.
const UNKNOWN_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( ?.o )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const UNKNOWN_TO_INSPECT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( o.? )     \n > ^ <",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  ->  \n( o_o )     \n /|_|\\",
];
const UNKNOWN_TO_CELEBRATE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( ?.o )     \n > ^ <",
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n<( ^o^ )>   \n  > ^ <",
];
const UNKNOWN_TO_CELEBRATE_BIG_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( o.? )     \n > ^ <",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
];
const UNKNOWN_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( ._. )     \n > ^ <",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
];
// Unknown hold settle while a sibling still shows an open vigil: Idle is already
// bridged for clear vigil; these four cover Failure/Stuck/Recovery/Cautious.
const UNKNOWN_TO_GUARD_FAILURE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( o.? )     \n /|_|\\",
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o.o ) [! ]\n /|_|\\",
];
const UNKNOWN_TO_GUARD_STUCK_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
const UNKNOWN_TO_GUARD_RECOVERY_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( ?.o )     \n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
];
const UNKNOWN_TO_GUARD_CAUTIOUS_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( ?.o )     \n /|_|\\",
    " /\\_/\\      \n( ?.o ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
];
// Error-hold clear-vigil settle: Unknown→Idle already animates; Inspect/SitNear
// must not snap when the hold ends with no open repo vigil.
const INSPECT_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const SIT_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
// Repo vigil clear: Celebrate/Unknown→Idle already animate; Guard* must not
// snap when sibling sync clears the open vigil under an idle Guard pose.
const FAILURE_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o.o )     \n /|_|\\",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const STUCK_TO_IDLE_FRAMES: [&str; 4] = [
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
    " =\\_/=      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const RECOVERY_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.o )     \n /|_|\\",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const CAUTIOUS_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ?.o )     \n /|_|\\",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
// Error-hold or unknown hold still showing when a push lands: Guard*/Watch*/
// Celebrate→Rest already animate; Inspect/SitNear/Unknown must not snap.
const INSPECT_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
const SIT_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
const UNKNOWN_TO_REST_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? )     \n > ^ <",
    " /\\_/\\      \n( ?.o )     \n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
];
// Clean Other finish while a watch pose is still showing: Watch*→Rest already
// animates for GitPush; Watch* must not snap to Idle.
const WATCH_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const WATCH_AGENT_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.o )     \n (___) ",
    " /\\_/\\      \n( o.o )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
const SETTLED_TO_IDLE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- )     \n (___) ",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n > ^ <",
    " /\\_/\\      \n( -.- )     \n >~^ <",
];
// Celebrate hold still showing when another finish lands: Guard*/Idle/Rest
// already animate; Inspect/SitNear/Unknown must not snap.
const CELEBRATE_TO_INSPECT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^o^ )>   \n  > ^ <",
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
];
const CELEBRATE_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^o^ )>   \n  > ^ <",
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
];
const CELEBRATE_TO_UNKNOWN_FRAMES: [&str; 4] = [
    " /\\_/\\      \n<( ^o^ )>   \n  > ^ <",
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n( ?.o )     \n > ^ <",
    " /\\_/\\      \n( ?.? )     \n > ^ <",
];
const CELEBRATE_BIG_TO_INSPECT_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
];
const CELEBRATE_BIG_TO_SIT_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
];
const CELEBRATE_BIG_TO_UNKNOWN_FRAMES: [&str; 4] = [
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    " /\\_/\\      \n( o.? )     \n > ^ <",
    " /\\_/\\      \n( ?.? )     \n > ^ <",
];
// Rest hold still showing when another finish lands: Rest→Idle already
// animates; Celebrate*/Inspect/SitNear/Unknown must not snap. Rest→Watch*
// and Rest→Guard* stay None (new command / open vigil appearing).
const REST_TO_INSPECT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\  <-  \n( o_o )     \n /|_|\\",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
];
const REST_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ._. )     \n /|_|\\",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
];
const REST_TO_UNKNOWN_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n( ?.o )     \n > ^ <",
    " /\\_/\\      \n( ?.? )     \n > ^ <",
];
const REST_TO_CELEBRATE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    " /\\_/\\      \n ( ^.^ )    \n  > ^ <",
    " /\\_/\\      \n<( ^.^ )>   \n  > ^ <",
];
const REST_TO_CELEBRATE_BIG_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ^.^ ) [ok]\n >~^ <",
    " /\\_/\\      \n( ^.^ ) [ok]\n > ^ <",
    "  /\\_/\\     \n<( ^.^ )>   \n  > ^ <",
    "* /\\_/\\ *   \n<( ^o^ )>   \n* > ^ < *",
];
// Recovery vigil still showing when a finish lands without Watch: Idle/Rest
// already animate; Inspect/SitNear/Unknown must not snap. GuardRecovery→Watch*
// stays None (new command from vigil, same as Celebrate→Watch).
const RECOVERY_TO_INSPECT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\  <-  \n( o_o ) [~ ]\n /|_|\\",
    " /\\_/\\  --> \n( o_o )     \n /|_|\\",
];
const RECOVERY_TO_SIT_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( ._. )  !  \n /|_|\\",
];
const RECOVERY_TO_UNKNOWN_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( -.o ) [ok]\n /|_|\\",
    " /\\_/\\      \n( ?.o )     \n /|_|\\",
    " /\\_/\\      \n( ?.? )     \n > ^ <",
];
// Idle vigil relapse: a sibling reopens failures while this pane still shows
// Recovery/Cautious (or Stuck downgrades to Failure). Without these arcs Full
// motion snaps on the reverse of the already-bridged recovery/escalation graph.
const RECOVERY_TO_FAILURE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o.o ) [! ]\n /|_|\\",
];
const RECOVERY_TO_STUCK_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( -.- ) [ok]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
const CAUTIOUS_TO_FAILURE_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o.o ) [! ]\n /|_|\\",
];
const CAUTIOUS_TO_STUCK_FRAMES: [&str; 4] = [
    " /\\_/\\      \n( ?.? ) [? ]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [~ ]\n /|_|\\",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
];
const STUCK_TO_FAILURE_FRAMES: [&str; 4] = [
    " =\\_/=      \n( -.- ) [!!]\n /|_|\\",
    " =\\_/=      \n( ._. ) [!!]\n /|_|\\",
    " /\\_/\\      \n( ._. ) [! ]\n /|_|\\",
    " /\\_/\\      \n( o_o ) [! ]\n /|_|\\",
];

impl Behavior {
    /// Canonical single pose: the first frame of each behavior's set. Used by
    /// the inline card, which records events rather than animating.
    pub const fn sprite(self) -> &'static str {
        match self {
            Self::Idle => IDLE_FRAMES[0],
            Self::WatchCommand => WATCH_FRAMES[0],
            Self::InspectError => INSPECT_FRAME,
            Self::SitNearError => SIT_FRAMES[0],
            Self::Celebrate => CELE_FRAMES[0],
            Self::CelebrateBig => BIG_FRAMES[0],
            Self::RestAfterPush => REST_FRAMES[0],
            Self::UnknownOutcome => UNKNOWN_FRAME,
            Self::GlanceAside => GLANCE_ASIDE_FRAMES[0],
            Self::Sleep => SLEEP_FRAMES[0],
            Self::Explore => EXPLORE_FRAMES[0],
            Self::Approach => APPROACH_FRAMES[0],
            Self::WatchAgent => WATCH_AGENT_FRAMES[0],
            Self::WatchSettled => WATCH_SETTLED_FRAMES[0],
            Self::GuardFailure => GUARD_FAILURE_FRAMES[0],
            Self::GuardStuck => GUARD_STUCK_FRAMES[0],
            Self::GuardRecovery => GUARD_RECOVERY_FRAMES[0],
            Self::GuardCautious => GUARD_CAUTIOUS_FRAMES[0],
        }
    }

    pub const fn is_repo_vigil(self) -> bool {
        matches!(
            self,
            Self::GuardFailure | Self::GuardStuck | Self::GuardRecovery | Self::GuardCautious
        )
    }

    /// One-line micro-poses for the sticky scrollback header. Every glyph is
    /// exactly five ASCII characters wide so the header never re-measures when
    /// the pose or animation frame changes.
    const fn sticky_frames(self) -> [&'static str; 2] {
        match self {
            Self::Idle => ["/\\_/\\", "/\\~/\\"],
            Self::WatchCommand => ["/\\_/\\", "/\\o/\\"],
            Self::InspectError => ["/\\!/\\", "/\\!/\\"],
            Self::SitNearError => ["=\\_/=", "=\\_/="],
            Self::Celebrate => ["*\\_/*", "*\\_/*"],
            Self::CelebrateBig => ["*\\o/*", "*\\_/*"],
            Self::RestAfterPush => ["/\\z/\\", "/\\_/\\"],
            Self::UnknownOutcome => ["/\\?/\\", "/\\?/\\"],
            Self::GlanceAside => ["/\\</\\", "/\\</\\"],
            Self::Sleep => ["=\\z/=", "=\\_/="],
            Self::Explore => ["~\\_/~", "/\\_/\\"],
            Self::Approach => ["/\\^/\\", "/\\_/\\"],
            Self::WatchAgent => ["/\\./\\", "/\\_/\\"],
            Self::WatchSettled => ["/\\-/\\", "/\\_/\\"],
            Self::GuardFailure => ["/\\!/\\", "/\\o/\\"],
            Self::GuardStuck => ["=\\!/=", "=\\_/="],
            Self::GuardRecovery => ["/\\+/\\", "/\\o/\\"],
            Self::GuardCautious => ["/\\?/\\", "/\\o/\\"],
        }
    }
}

/// Quantized, content-free body language derived from the continuous life
/// state. Only ambient poses (Idle/WatchCommand) let it show through —
/// reaction poses stay canonical so event records remain unambiguous.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub struct BodyLanguage {
    /// Low energy: lie down and doze instead of sitting, stop wandering.
    pub drowsy: bool,
    /// High stress: ears pressed flat while idling or watching.
    pub tense: bool,
    /// Boredom at the ceiling: occasional yawns, restless wandering.
    pub listless: bool,
}

impl BodyLanguage {
    pub fn from_state(state: LifeState) -> Self {
        let drowsy = state.energy < 0.25;
        Self {
            drowsy,
            tense: state.stress > 0.60,
            listless: !drowsy && state.boredom > 0.85,
        }
    }
}

/// Coarse lifetime appearance supplied by the memory/UI boundary. This lives
/// in the renderer rather than importing memory's `GrowthStage`, which keeps
/// the no-LLM reducer independent and avoids a module cycle.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum VisualGrowthStage {
    Juvenile,
    #[default]
    Adult,
    Seasoned,
}

/// Content-free rhythm of a running command. It describes only the cadence of
/// output activity, never bytes, lines, commands, or terminal contents.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum WatchRhythm {
    #[default]
    Steady,
    Busy,
    Waiting,
    Resumed,
}

/// A short visual bridge between semantically adjacent canonical behaviors.
/// Reducer state remains authoritative: these variants carry no data and are
/// selected only after the UI has already observed both endpoint behaviors.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum VisualTransition {
    InspectErrorToGuardFailure,
    InspectErrorToGuardRecovery,
    InspectErrorToGuardCautious,
    InspectErrorToGuardStuck,
    SitNearErrorToGuardFailure,
    SitNearErrorToGuardStuck,
    SitNearErrorToGuardRecovery,
    SitNearErrorToGuardCautious,
    GuardFailureToGuardStuck,
    GuardFailureToGuardRecovery,
    GuardFailureToGuardCautious,
    GuardStuckToGuardFailure,
    GuardStuckToGuardRecovery,
    GuardStuckToGuardCautious,
    WatchSettledToCelebrate,
    WatchSettledToCelebrateBig,
    WatchSettledToInspectError,
    WatchSettledToSitNearError,
    WatchSettledToRestAfterPush,
    WatchCommandToCelebrate,
    WatchCommandToCelebrateBig,
    WatchCommandToInspectError,
    WatchCommandToSitNearError,
    WatchCommandToRestAfterPush,
    WatchAgentToCelebrate,
    WatchAgentToInspectError,
    WatchAgentToSitNearError,
    WatchAgentToRestAfterPush,
    CelebrateToGuardRecovery,
    CelebrateToGuardCautious,
    CelebrateToGuardFailure,
    CelebrateToGuardStuck,
    CelebrateBigToGuardRecovery,
    CelebrateBigToGuardCautious,
    CelebrateBigToGuardFailure,
    CelebrateBigToGuardStuck,
    GuardRecoveryToGuardFailure,
    GuardRecoveryToGuardStuck,
    GuardRecoveryToGuardCautious,
    GuardCautiousToGuardFailure,
    GuardCautiousToGuardStuck,
    GuardCautiousToGuardRecovery,
    GuardRecoveryToRestAfterPush,
    GuardCautiousToRestAfterPush,
    GuardFailureToRestAfterPush,
    GuardStuckToRestAfterPush,
    InspectErrorToCelebrate,
    InspectErrorToCelebrateBig,
    InspectErrorToSitNearError,
    InspectErrorToUnknownOutcome,
    SitNearErrorToCelebrate,
    SitNearErrorToCelebrateBig,
    SitNearErrorToUnknownOutcome,
    CelebrateToRestAfterPush,
    CelebrateBigToRestAfterPush,
    CelebrateToIdle,
    CelebrateBigToIdle,
    RestAfterPushToIdle,
    UnknownOutcomeToIdle,
    UnknownOutcomeToInspectError,
    UnknownOutcomeToCelebrate,
    UnknownOutcomeToCelebrateBig,
    UnknownOutcomeToSitNearError,
    UnknownOutcomeToGuardFailure,
    UnknownOutcomeToGuardStuck,
    UnknownOutcomeToGuardRecovery,
    UnknownOutcomeToGuardCautious,
    InspectErrorToIdle,
    SitNearErrorToIdle,
    GuardFailureToIdle,
    GuardStuckToIdle,
    GuardRecoveryToIdle,
    GuardCautiousToIdle,
    InspectErrorToRestAfterPush,
    SitNearErrorToRestAfterPush,
    UnknownOutcomeToRestAfterPush,
    WatchCommandToIdle,
    WatchAgentToIdle,
    WatchSettledToIdle,
    CelebrateToInspectError,
    CelebrateToSitNearError,
    CelebrateToUnknownOutcome,
    CelebrateBigToInspectError,
    CelebrateBigToSitNearError,
    CelebrateBigToUnknownOutcome,
    RestAfterPushToInspectError,
    RestAfterPushToSitNearError,
    RestAfterPushToUnknownOutcome,
    RestAfterPushToCelebrate,
    RestAfterPushToCelebrateBig,
    GuardRecoveryToInspectError,
    GuardRecoveryToSitNearError,
    GuardRecoveryToUnknownOutcome,
}

impl VisualTransition {
    /// Recognize only intentional arcs. Unrelated behavior changes snap to the
    /// new canonical pose instead of inventing a misleading transition.
    pub const fn between(from: Behavior, to: Behavior) -> Option<Self> {
        match (from, to) {
            (Behavior::InspectError, Behavior::GuardFailure) => {
                Some(Self::InspectErrorToGuardFailure)
            }
            (Behavior::InspectError, Behavior::GuardRecovery) => {
                Some(Self::InspectErrorToGuardRecovery)
            }
            (Behavior::InspectError, Behavior::GuardCautious) => {
                Some(Self::InspectErrorToGuardCautious)
            }
            (Behavior::InspectError, Behavior::GuardStuck) => Some(Self::InspectErrorToGuardStuck),
            (Behavior::SitNearError, Behavior::GuardFailure) => {
                Some(Self::SitNearErrorToGuardFailure)
            }
            (Behavior::SitNearError, Behavior::GuardStuck) => Some(Self::SitNearErrorToGuardStuck),
            (Behavior::SitNearError, Behavior::GuardRecovery) => {
                Some(Self::SitNearErrorToGuardRecovery)
            }
            (Behavior::SitNearError, Behavior::GuardCautious) => {
                Some(Self::SitNearErrorToGuardCautious)
            }
            (Behavior::GuardFailure, Behavior::GuardStuck) => Some(Self::GuardFailureToGuardStuck),
            (Behavior::GuardFailure, Behavior::GuardRecovery) => {
                Some(Self::GuardFailureToGuardRecovery)
            }
            (Behavior::GuardFailure, Behavior::GuardCautious) => {
                Some(Self::GuardFailureToGuardCautious)
            }
            (Behavior::GuardStuck, Behavior::GuardFailure) => Some(Self::GuardStuckToGuardFailure),
            (Behavior::GuardStuck, Behavior::GuardRecovery) => {
                Some(Self::GuardStuckToGuardRecovery)
            }
            (Behavior::GuardStuck, Behavior::GuardCautious) => {
                Some(Self::GuardStuckToGuardCautious)
            }
            (Behavior::WatchSettled, Behavior::Celebrate) => Some(Self::WatchSettledToCelebrate),
            (Behavior::WatchSettled, Behavior::CelebrateBig) => {
                Some(Self::WatchSettledToCelebrateBig)
            }
            (Behavior::WatchSettled, Behavior::InspectError) => {
                Some(Self::WatchSettledToInspectError)
            }
            (Behavior::WatchSettled, Behavior::SitNearError) => {
                Some(Self::WatchSettledToSitNearError)
            }
            (Behavior::WatchSettled, Behavior::RestAfterPush) => {
                Some(Self::WatchSettledToRestAfterPush)
            }
            (Behavior::WatchCommand, Behavior::Celebrate) => Some(Self::WatchCommandToCelebrate),
            (Behavior::WatchCommand, Behavior::CelebrateBig) => {
                Some(Self::WatchCommandToCelebrateBig)
            }
            (Behavior::WatchCommand, Behavior::InspectError) => {
                Some(Self::WatchCommandToInspectError)
            }
            (Behavior::WatchCommand, Behavior::SitNearError) => {
                Some(Self::WatchCommandToSitNearError)
            }
            (Behavior::WatchCommand, Behavior::RestAfterPush) => {
                Some(Self::WatchCommandToRestAfterPush)
            }
            (Behavior::WatchAgent, Behavior::Celebrate) => Some(Self::WatchAgentToCelebrate),
            (Behavior::WatchAgent, Behavior::InspectError) => Some(Self::WatchAgentToInspectError),
            (Behavior::WatchAgent, Behavior::SitNearError) => Some(Self::WatchAgentToSitNearError),
            (Behavior::WatchAgent, Behavior::RestAfterPush) => {
                Some(Self::WatchAgentToRestAfterPush)
            }
            (Behavior::Celebrate, Behavior::GuardRecovery) => Some(Self::CelebrateToGuardRecovery),
            (Behavior::Celebrate, Behavior::GuardCautious) => Some(Self::CelebrateToGuardCautious),
            (Behavior::Celebrate, Behavior::GuardFailure) => Some(Self::CelebrateToGuardFailure),
            (Behavior::Celebrate, Behavior::GuardStuck) => Some(Self::CelebrateToGuardStuck),
            (Behavior::CelebrateBig, Behavior::GuardRecovery) => {
                Some(Self::CelebrateBigToGuardRecovery)
            }
            (Behavior::CelebrateBig, Behavior::GuardCautious) => {
                Some(Self::CelebrateBigToGuardCautious)
            }
            (Behavior::CelebrateBig, Behavior::GuardFailure) => {
                Some(Self::CelebrateBigToGuardFailure)
            }
            (Behavior::CelebrateBig, Behavior::GuardStuck) => Some(Self::CelebrateBigToGuardStuck),
            (Behavior::GuardRecovery, Behavior::GuardFailure) => {
                Some(Self::GuardRecoveryToGuardFailure)
            }
            (Behavior::GuardRecovery, Behavior::GuardStuck) => {
                Some(Self::GuardRecoveryToGuardStuck)
            }
            (Behavior::GuardRecovery, Behavior::GuardCautious) => {
                Some(Self::GuardRecoveryToGuardCautious)
            }
            (Behavior::GuardCautious, Behavior::GuardFailure) => {
                Some(Self::GuardCautiousToGuardFailure)
            }
            (Behavior::GuardCautious, Behavior::GuardStuck) => {
                Some(Self::GuardCautiousToGuardStuck)
            }
            (Behavior::GuardCautious, Behavior::GuardRecovery) => {
                Some(Self::GuardCautiousToGuardRecovery)
            }
            (Behavior::GuardRecovery, Behavior::RestAfterPush) => {
                Some(Self::GuardRecoveryToRestAfterPush)
            }
            (Behavior::GuardCautious, Behavior::RestAfterPush) => {
                Some(Self::GuardCautiousToRestAfterPush)
            }
            (Behavior::GuardFailure, Behavior::RestAfterPush) => {
                Some(Self::GuardFailureToRestAfterPush)
            }
            (Behavior::GuardStuck, Behavior::RestAfterPush) => {
                Some(Self::GuardStuckToRestAfterPush)
            }
            (Behavior::InspectError, Behavior::Celebrate) => Some(Self::InspectErrorToCelebrate),
            (Behavior::InspectError, Behavior::CelebrateBig) => {
                Some(Self::InspectErrorToCelebrateBig)
            }
            (Behavior::InspectError, Behavior::SitNearError) => {
                Some(Self::InspectErrorToSitNearError)
            }
            (Behavior::InspectError, Behavior::UnknownOutcome) => {
                Some(Self::InspectErrorToUnknownOutcome)
            }
            (Behavior::SitNearError, Behavior::Celebrate) => Some(Self::SitNearErrorToCelebrate),
            (Behavior::SitNearError, Behavior::CelebrateBig) => {
                Some(Self::SitNearErrorToCelebrateBig)
            }
            (Behavior::SitNearError, Behavior::UnknownOutcome) => {
                Some(Self::SitNearErrorToUnknownOutcome)
            }
            (Behavior::Celebrate, Behavior::RestAfterPush) => Some(Self::CelebrateToRestAfterPush),
            (Behavior::CelebrateBig, Behavior::RestAfterPush) => {
                Some(Self::CelebrateBigToRestAfterPush)
            }
            (Behavior::Celebrate, Behavior::Idle) => Some(Self::CelebrateToIdle),
            (Behavior::CelebrateBig, Behavior::Idle) => Some(Self::CelebrateBigToIdle),
            (Behavior::RestAfterPush, Behavior::Idle) => Some(Self::RestAfterPushToIdle),
            (Behavior::UnknownOutcome, Behavior::Idle) => Some(Self::UnknownOutcomeToIdle),
            (Behavior::UnknownOutcome, Behavior::InspectError) => {
                Some(Self::UnknownOutcomeToInspectError)
            }
            (Behavior::UnknownOutcome, Behavior::Celebrate) => {
                Some(Self::UnknownOutcomeToCelebrate)
            }
            (Behavior::UnknownOutcome, Behavior::CelebrateBig) => {
                Some(Self::UnknownOutcomeToCelebrateBig)
            }
            (Behavior::UnknownOutcome, Behavior::SitNearError) => {
                Some(Self::UnknownOutcomeToSitNearError)
            }
            (Behavior::UnknownOutcome, Behavior::GuardFailure) => {
                Some(Self::UnknownOutcomeToGuardFailure)
            }
            (Behavior::UnknownOutcome, Behavior::GuardStuck) => {
                Some(Self::UnknownOutcomeToGuardStuck)
            }
            (Behavior::UnknownOutcome, Behavior::GuardRecovery) => {
                Some(Self::UnknownOutcomeToGuardRecovery)
            }
            (Behavior::UnknownOutcome, Behavior::GuardCautious) => {
                Some(Self::UnknownOutcomeToGuardCautious)
            }
            (Behavior::InspectError, Behavior::Idle) => Some(Self::InspectErrorToIdle),
            (Behavior::SitNearError, Behavior::Idle) => Some(Self::SitNearErrorToIdle),
            (Behavior::GuardFailure, Behavior::Idle) => Some(Self::GuardFailureToIdle),
            (Behavior::GuardStuck, Behavior::Idle) => Some(Self::GuardStuckToIdle),
            (Behavior::GuardRecovery, Behavior::Idle) => Some(Self::GuardRecoveryToIdle),
            (Behavior::GuardCautious, Behavior::Idle) => Some(Self::GuardCautiousToIdle),
            (Behavior::InspectError, Behavior::RestAfterPush) => {
                Some(Self::InspectErrorToRestAfterPush)
            }
            (Behavior::SitNearError, Behavior::RestAfterPush) => {
                Some(Self::SitNearErrorToRestAfterPush)
            }
            (Behavior::UnknownOutcome, Behavior::RestAfterPush) => {
                Some(Self::UnknownOutcomeToRestAfterPush)
            }
            (Behavior::WatchCommand, Behavior::Idle) => Some(Self::WatchCommandToIdle),
            (Behavior::WatchAgent, Behavior::Idle) => Some(Self::WatchAgentToIdle),
            (Behavior::WatchSettled, Behavior::Idle) => Some(Self::WatchSettledToIdle),
            (Behavior::Celebrate, Behavior::InspectError) => Some(Self::CelebrateToInspectError),
            (Behavior::Celebrate, Behavior::SitNearError) => Some(Self::CelebrateToSitNearError),
            (Behavior::Celebrate, Behavior::UnknownOutcome) => {
                Some(Self::CelebrateToUnknownOutcome)
            }
            (Behavior::CelebrateBig, Behavior::InspectError) => {
                Some(Self::CelebrateBigToInspectError)
            }
            (Behavior::CelebrateBig, Behavior::SitNearError) => {
                Some(Self::CelebrateBigToSitNearError)
            }
            (Behavior::CelebrateBig, Behavior::UnknownOutcome) => {
                Some(Self::CelebrateBigToUnknownOutcome)
            }
            (Behavior::RestAfterPush, Behavior::InspectError) => {
                Some(Self::RestAfterPushToInspectError)
            }
            (Behavior::RestAfterPush, Behavior::SitNearError) => {
                Some(Self::RestAfterPushToSitNearError)
            }
            (Behavior::RestAfterPush, Behavior::UnknownOutcome) => {
                Some(Self::RestAfterPushToUnknownOutcome)
            }
            (Behavior::RestAfterPush, Behavior::Celebrate) => Some(Self::RestAfterPushToCelebrate),
            (Behavior::RestAfterPush, Behavior::CelebrateBig) => {
                Some(Self::RestAfterPushToCelebrateBig)
            }
            (Behavior::GuardRecovery, Behavior::InspectError) => {
                Some(Self::GuardRecoveryToInspectError)
            }
            (Behavior::GuardRecovery, Behavior::SitNearError) => {
                Some(Self::GuardRecoveryToSitNearError)
            }
            (Behavior::GuardRecovery, Behavior::UnknownOutcome) => {
                Some(Self::GuardRecoveryToUnknownOutcome)
            }
            _ => None,
        }
    }

    pub const fn source(self) -> Behavior {
        match self {
            Self::InspectErrorToGuardFailure
            | Self::InspectErrorToGuardRecovery
            | Self::InspectErrorToGuardCautious
            | Self::InspectErrorToGuardStuck
            | Self::InspectErrorToCelebrate
            | Self::InspectErrorToCelebrateBig
            | Self::InspectErrorToSitNearError
            | Self::InspectErrorToUnknownOutcome
            | Self::InspectErrorToIdle
            | Self::InspectErrorToRestAfterPush => Behavior::InspectError,
            Self::SitNearErrorToGuardFailure
            | Self::SitNearErrorToGuardStuck
            | Self::SitNearErrorToGuardRecovery
            | Self::SitNearErrorToGuardCautious
            | Self::SitNearErrorToCelebrate
            | Self::SitNearErrorToCelebrateBig
            | Self::SitNearErrorToUnknownOutcome
            | Self::SitNearErrorToIdle
            | Self::SitNearErrorToRestAfterPush => Behavior::SitNearError,
            Self::GuardFailureToGuardStuck
            | Self::GuardFailureToGuardRecovery
            | Self::GuardFailureToGuardCautious
            | Self::GuardFailureToRestAfterPush
            | Self::GuardFailureToIdle => Behavior::GuardFailure,
            Self::GuardStuckToGuardFailure
            | Self::GuardStuckToGuardRecovery
            | Self::GuardStuckToGuardCautious
            | Self::GuardStuckToRestAfterPush
            | Self::GuardStuckToIdle => Behavior::GuardStuck,
            Self::WatchSettledToCelebrate
            | Self::WatchSettledToCelebrateBig
            | Self::WatchSettledToInspectError
            | Self::WatchSettledToSitNearError
            | Self::WatchSettledToRestAfterPush
            | Self::WatchSettledToIdle => Behavior::WatchSettled,
            Self::WatchCommandToCelebrate
            | Self::WatchCommandToCelebrateBig
            | Self::WatchCommandToInspectError
            | Self::WatchCommandToSitNearError
            | Self::WatchCommandToRestAfterPush
            | Self::WatchCommandToIdle => Behavior::WatchCommand,
            Self::WatchAgentToCelebrate
            | Self::WatchAgentToInspectError
            | Self::WatchAgentToSitNearError
            | Self::WatchAgentToRestAfterPush
            | Self::WatchAgentToIdle => Behavior::WatchAgent,
            Self::CelebrateToGuardRecovery
            | Self::CelebrateToGuardCautious
            | Self::CelebrateToGuardFailure
            | Self::CelebrateToGuardStuck
            | Self::CelebrateToRestAfterPush
            | Self::CelebrateToIdle
            | Self::CelebrateToInspectError
            | Self::CelebrateToSitNearError
            | Self::CelebrateToUnknownOutcome => Behavior::Celebrate,
            Self::CelebrateBigToGuardRecovery
            | Self::CelebrateBigToGuardCautious
            | Self::CelebrateBigToGuardFailure
            | Self::CelebrateBigToGuardStuck
            | Self::CelebrateBigToRestAfterPush
            | Self::CelebrateBigToIdle
            | Self::CelebrateBigToInspectError
            | Self::CelebrateBigToSitNearError
            | Self::CelebrateBigToUnknownOutcome => Behavior::CelebrateBig,
            Self::GuardRecoveryToGuardFailure
            | Self::GuardRecoveryToGuardStuck
            | Self::GuardRecoveryToGuardCautious
            | Self::GuardRecoveryToRestAfterPush
            | Self::GuardRecoveryToIdle
            | Self::GuardRecoveryToInspectError
            | Self::GuardRecoveryToSitNearError
            | Self::GuardRecoveryToUnknownOutcome => Behavior::GuardRecovery,
            Self::GuardCautiousToGuardFailure
            | Self::GuardCautiousToGuardStuck
            | Self::GuardCautiousToGuardRecovery
            | Self::GuardCautiousToRestAfterPush
            | Self::GuardCautiousToIdle => Behavior::GuardCautious,
            Self::RestAfterPushToIdle
            | Self::RestAfterPushToInspectError
            | Self::RestAfterPushToSitNearError
            | Self::RestAfterPushToUnknownOutcome
            | Self::RestAfterPushToCelebrate
            | Self::RestAfterPushToCelebrateBig => Behavior::RestAfterPush,
            Self::UnknownOutcomeToIdle
            | Self::UnknownOutcomeToInspectError
            | Self::UnknownOutcomeToCelebrate
            | Self::UnknownOutcomeToCelebrateBig
            | Self::UnknownOutcomeToSitNearError
            | Self::UnknownOutcomeToGuardFailure
            | Self::UnknownOutcomeToGuardStuck
            | Self::UnknownOutcomeToGuardRecovery
            | Self::UnknownOutcomeToGuardCautious
            | Self::UnknownOutcomeToRestAfterPush => Behavior::UnknownOutcome,
        }
    }

    pub const fn target(self) -> Behavior {
        match self {
            Self::InspectErrorToGuardFailure
            | Self::SitNearErrorToGuardFailure
            | Self::GuardStuckToGuardFailure
            | Self::GuardRecoveryToGuardFailure
            | Self::GuardCautiousToGuardFailure
            | Self::CelebrateToGuardFailure
            | Self::CelebrateBigToGuardFailure
            | Self::UnknownOutcomeToGuardFailure => Behavior::GuardFailure,
            Self::SitNearErrorToGuardStuck
            | Self::InspectErrorToGuardStuck
            | Self::GuardFailureToGuardStuck
            | Self::GuardRecoveryToGuardStuck
            | Self::GuardCautiousToGuardStuck
            | Self::CelebrateToGuardStuck
            | Self::CelebrateBigToGuardStuck
            | Self::UnknownOutcomeToGuardStuck => Behavior::GuardStuck,
            Self::InspectErrorToGuardRecovery
            | Self::SitNearErrorToGuardRecovery
            | Self::GuardFailureToGuardRecovery
            | Self::GuardStuckToGuardRecovery
            | Self::GuardCautiousToGuardRecovery
            | Self::CelebrateToGuardRecovery
            | Self::CelebrateBigToGuardRecovery
            | Self::UnknownOutcomeToGuardRecovery => Behavior::GuardRecovery,
            Self::InspectErrorToGuardCautious
            | Self::SitNearErrorToGuardCautious
            | Self::GuardFailureToGuardCautious
            | Self::GuardStuckToGuardCautious
            | Self::GuardRecoveryToGuardCautious
            | Self::CelebrateToGuardCautious
            | Self::CelebrateBigToGuardCautious
            | Self::UnknownOutcomeToGuardCautious => Behavior::GuardCautious,
            Self::WatchSettledToCelebrate
            | Self::InspectErrorToCelebrate
            | Self::SitNearErrorToCelebrate
            | Self::WatchCommandToCelebrate
            | Self::WatchAgentToCelebrate
            | Self::UnknownOutcomeToCelebrate
            | Self::RestAfterPushToCelebrate => Behavior::Celebrate,
            Self::WatchSettledToCelebrateBig
            | Self::InspectErrorToCelebrateBig
            | Self::SitNearErrorToCelebrateBig
            | Self::WatchCommandToCelebrateBig
            | Self::UnknownOutcomeToCelebrateBig
            | Self::RestAfterPushToCelebrateBig => Behavior::CelebrateBig,
            Self::WatchSettledToInspectError
            | Self::WatchCommandToInspectError
            | Self::WatchAgentToInspectError
            | Self::UnknownOutcomeToInspectError
            | Self::CelebrateToInspectError
            | Self::CelebrateBigToInspectError
            | Self::RestAfterPushToInspectError
            | Self::GuardRecoveryToInspectError => Behavior::InspectError,
            Self::WatchSettledToSitNearError
            | Self::WatchCommandToSitNearError
            | Self::WatchAgentToSitNearError
            | Self::UnknownOutcomeToSitNearError
            | Self::CelebrateToSitNearError
            | Self::CelebrateBigToSitNearError
            | Self::RestAfterPushToSitNearError
            | Self::GuardRecoveryToSitNearError
            | Self::InspectErrorToSitNearError => Behavior::SitNearError,
            Self::GuardRecoveryToRestAfterPush
            | Self::GuardCautiousToRestAfterPush
            | Self::GuardFailureToRestAfterPush
            | Self::GuardStuckToRestAfterPush
            | Self::CelebrateToRestAfterPush
            | Self::CelebrateBigToRestAfterPush
            | Self::WatchCommandToRestAfterPush
            | Self::WatchAgentToRestAfterPush
            | Self::WatchSettledToRestAfterPush
            | Self::InspectErrorToRestAfterPush
            | Self::SitNearErrorToRestAfterPush
            | Self::UnknownOutcomeToRestAfterPush => Behavior::RestAfterPush,
            Self::CelebrateToIdle
            | Self::CelebrateBigToIdle
            | Self::RestAfterPushToIdle
            | Self::UnknownOutcomeToIdle
            | Self::InspectErrorToIdle
            | Self::SitNearErrorToIdle
            | Self::GuardFailureToIdle
            | Self::GuardStuckToIdle
            | Self::GuardRecoveryToIdle
            | Self::GuardCautiousToIdle
            | Self::WatchCommandToIdle
            | Self::WatchAgentToIdle
            | Self::WatchSettledToIdle => Behavior::Idle,
            Self::CelebrateToUnknownOutcome
            | Self::CelebrateBigToUnknownOutcome
            | Self::RestAfterPushToUnknownOutcome
            | Self::GuardRecoveryToUnknownOutcome
            | Self::InspectErrorToUnknownOutcome
            | Self::SitNearErrorToUnknownOutcome => Behavior::UnknownOutcome,
        }
    }

    pub const fn frame_count(self) -> u64 {
        4
    }

    /// `frame` is relative to the start of the arc. Holding beyond the fourth
    /// frame is safe and keeps the last bridge pose until the UI clears it.
    pub const fn sprite_frame(self, frame: u64) -> &'static str {
        let index = if frame >= self.frame_count() {
            self.frame_count() as usize - 1
        } else {
            frame as usize
        };
        match self {
            Self::InspectErrorToGuardFailure => INSPECT_TO_GUARD_FAILURE_FRAMES[index],
            Self::InspectErrorToGuardRecovery => INSPECT_TO_GUARD_RECOVERY_FRAMES[index],
            Self::InspectErrorToGuardCautious => INSPECT_TO_GUARD_CAUTIOUS_FRAMES[index],
            Self::InspectErrorToGuardStuck => INSPECT_TO_GUARD_STUCK_FRAMES[index],
            Self::SitNearErrorToGuardFailure => SIT_TO_GUARD_FAILURE_FRAMES[index],
            Self::SitNearErrorToGuardStuck => SIT_TO_GUARD_STUCK_FRAMES[index],
            Self::SitNearErrorToGuardRecovery => SIT_TO_GUARD_RECOVERY_FRAMES[index],
            Self::SitNearErrorToGuardCautious => SIT_TO_GUARD_CAUTIOUS_FRAMES[index],
            Self::GuardFailureToGuardStuck => FAILURE_TO_STUCK_FRAMES[index],
            Self::GuardFailureToGuardRecovery => FAILURE_TO_RECOVERY_FRAMES[index],
            Self::GuardFailureToGuardCautious => FAILURE_TO_CAUTIOUS_FRAMES[index],
            Self::GuardStuckToGuardFailure => STUCK_TO_FAILURE_FRAMES[index],
            Self::GuardStuckToGuardRecovery => STUCK_TO_RECOVERY_FRAMES[index],
            Self::GuardStuckToGuardCautious => STUCK_TO_CAUTIOUS_FRAMES[index],
            Self::WatchSettledToCelebrate => SETTLED_TO_CELEBRATE_FRAMES[index],
            Self::WatchSettledToCelebrateBig => SETTLED_TO_CELEBRATE_BIG_FRAMES[index],
            Self::WatchSettledToInspectError => SETTLED_TO_INSPECT_FRAMES[index],
            Self::WatchSettledToSitNearError => SETTLED_TO_SIT_FRAMES[index],
            Self::WatchSettledToRestAfterPush => SETTLED_TO_REST_FRAMES[index],
            Self::WatchCommandToCelebrate => WATCH_TO_CELEBRATE_FRAMES[index],
            Self::WatchCommandToCelebrateBig => WATCH_TO_CELEBRATE_BIG_FRAMES[index],
            Self::WatchCommandToInspectError => WATCH_TO_INSPECT_FRAMES[index],
            Self::WatchCommandToSitNearError => WATCH_TO_SIT_FRAMES[index],
            Self::WatchCommandToRestAfterPush => WATCH_TO_REST_FRAMES[index],
            Self::WatchAgentToCelebrate => WATCH_AGENT_TO_CELEBRATE_FRAMES[index],
            Self::WatchAgentToInspectError => WATCH_AGENT_TO_INSPECT_FRAMES[index],
            Self::WatchAgentToSitNearError => WATCH_AGENT_TO_SIT_FRAMES[index],
            Self::WatchAgentToRestAfterPush => WATCH_AGENT_TO_REST_FRAMES[index],
            Self::CelebrateToGuardRecovery => CELEBRATE_TO_RECOVERY_FRAMES[index],
            Self::CelebrateToGuardCautious => CELEBRATE_TO_CAUTIOUS_FRAMES[index],
            Self::CelebrateToGuardFailure => CELEBRATE_TO_FAILURE_FRAMES[index],
            Self::CelebrateToGuardStuck => CELEBRATE_TO_STUCK_FRAMES[index],
            Self::CelebrateBigToGuardRecovery => CELEBRATE_BIG_TO_RECOVERY_FRAMES[index],
            Self::CelebrateBigToGuardCautious => CELEBRATE_BIG_TO_CAUTIOUS_FRAMES[index],
            Self::CelebrateBigToGuardFailure => CELEBRATE_BIG_TO_FAILURE_FRAMES[index],
            Self::CelebrateBigToGuardStuck => CELEBRATE_BIG_TO_STUCK_FRAMES[index],
            Self::GuardRecoveryToGuardFailure => RECOVERY_TO_FAILURE_FRAMES[index],
            Self::GuardRecoveryToGuardStuck => RECOVERY_TO_STUCK_FRAMES[index],
            Self::GuardRecoveryToGuardCautious => RECOVERY_TO_CAUTIOUS_FRAMES[index],
            Self::GuardCautiousToGuardFailure => CAUTIOUS_TO_FAILURE_FRAMES[index],
            Self::GuardCautiousToGuardStuck => CAUTIOUS_TO_STUCK_FRAMES[index],
            Self::GuardCautiousToGuardRecovery => CAUTIOUS_TO_RECOVERY_FRAMES[index],
            Self::GuardRecoveryToRestAfterPush => RECOVERY_TO_REST_FRAMES[index],
            Self::GuardCautiousToRestAfterPush => CAUTIOUS_TO_REST_FRAMES[index],
            Self::GuardFailureToRestAfterPush => FAILURE_TO_REST_FRAMES[index],
            Self::GuardStuckToRestAfterPush => STUCK_TO_REST_FRAMES[index],
            Self::InspectErrorToCelebrate => INSPECT_TO_CELEBRATE_FRAMES[index],
            Self::InspectErrorToCelebrateBig => INSPECT_TO_CELEBRATE_BIG_FRAMES[index],
            Self::InspectErrorToSitNearError => INSPECT_TO_SIT_FRAMES[index],
            Self::InspectErrorToUnknownOutcome => INSPECT_TO_UNKNOWN_FRAMES[index],
            Self::SitNearErrorToCelebrate => SIT_TO_CELEBRATE_FRAMES[index],
            Self::SitNearErrorToCelebrateBig => SIT_TO_CELEBRATE_BIG_FRAMES[index],
            Self::SitNearErrorToUnknownOutcome => SIT_TO_UNKNOWN_FRAMES[index],
            Self::CelebrateToRestAfterPush => CELEBRATE_TO_REST_FRAMES[index],
            Self::CelebrateBigToRestAfterPush => CELEBRATE_BIG_TO_REST_FRAMES[index],
            Self::CelebrateToIdle => CELEBRATE_TO_IDLE_FRAMES[index],
            Self::CelebrateBigToIdle => CELEBRATE_BIG_TO_IDLE_FRAMES[index],
            Self::RestAfterPushToIdle => REST_TO_IDLE_FRAMES[index],
            Self::UnknownOutcomeToIdle => UNKNOWN_TO_IDLE_FRAMES[index],
            Self::UnknownOutcomeToInspectError => UNKNOWN_TO_INSPECT_FRAMES[index],
            Self::UnknownOutcomeToCelebrate => UNKNOWN_TO_CELEBRATE_FRAMES[index],
            Self::UnknownOutcomeToCelebrateBig => UNKNOWN_TO_CELEBRATE_BIG_FRAMES[index],
            Self::UnknownOutcomeToSitNearError => UNKNOWN_TO_SIT_FRAMES[index],
            Self::UnknownOutcomeToGuardFailure => UNKNOWN_TO_GUARD_FAILURE_FRAMES[index],
            Self::UnknownOutcomeToGuardStuck => UNKNOWN_TO_GUARD_STUCK_FRAMES[index],
            Self::UnknownOutcomeToGuardRecovery => UNKNOWN_TO_GUARD_RECOVERY_FRAMES[index],
            Self::UnknownOutcomeToGuardCautious => UNKNOWN_TO_GUARD_CAUTIOUS_FRAMES[index],
            Self::InspectErrorToIdle => INSPECT_TO_IDLE_FRAMES[index],
            Self::SitNearErrorToIdle => SIT_TO_IDLE_FRAMES[index],
            Self::GuardFailureToIdle => FAILURE_TO_IDLE_FRAMES[index],
            Self::GuardStuckToIdle => STUCK_TO_IDLE_FRAMES[index],
            Self::GuardRecoveryToIdle => RECOVERY_TO_IDLE_FRAMES[index],
            Self::GuardCautiousToIdle => CAUTIOUS_TO_IDLE_FRAMES[index],
            Self::InspectErrorToRestAfterPush => INSPECT_TO_REST_FRAMES[index],
            Self::SitNearErrorToRestAfterPush => SIT_TO_REST_FRAMES[index],
            Self::UnknownOutcomeToRestAfterPush => UNKNOWN_TO_REST_FRAMES[index],
            Self::WatchCommandToIdle => WATCH_TO_IDLE_FRAMES[index],
            Self::WatchAgentToIdle => WATCH_AGENT_TO_IDLE_FRAMES[index],
            Self::WatchSettledToIdle => SETTLED_TO_IDLE_FRAMES[index],
            Self::CelebrateToInspectError => CELEBRATE_TO_INSPECT_FRAMES[index],
            Self::CelebrateToSitNearError => CELEBRATE_TO_SIT_FRAMES[index],
            Self::CelebrateToUnknownOutcome => CELEBRATE_TO_UNKNOWN_FRAMES[index],
            Self::CelebrateBigToInspectError => CELEBRATE_BIG_TO_INSPECT_FRAMES[index],
            Self::CelebrateBigToSitNearError => CELEBRATE_BIG_TO_SIT_FRAMES[index],
            Self::CelebrateBigToUnknownOutcome => CELEBRATE_BIG_TO_UNKNOWN_FRAMES[index],
            Self::RestAfterPushToInspectError => REST_TO_INSPECT_FRAMES[index],
            Self::RestAfterPushToSitNearError => REST_TO_SIT_FRAMES[index],
            Self::RestAfterPushToUnknownOutcome => REST_TO_UNKNOWN_FRAMES[index],
            Self::RestAfterPushToCelebrate => REST_TO_CELEBRATE_FRAMES[index],
            Self::RestAfterPushToCelebrateBig => REST_TO_CELEBRATE_BIG_FRAMES[index],
            Self::GuardRecoveryToInspectError => RECOVERY_TO_INSPECT_FRAMES[index],
            Self::GuardRecoveryToSitNearError => RECOVERY_TO_SIT_FRAMES[index],
            Self::GuardRecoveryToUnknownOutcome => RECOVERY_TO_UNKNOWN_FRAMES[index],
        }
    }
}

/// All orthogonal visual inputs for one render. Event semantics stay in
/// `behavior`; body language, lifetime appearance, output rhythm, and an
/// optional one-shot bridge merely choose how that state is drawn.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RenderContext {
    pub behavior: Behavior,
    pub body_language: BodyLanguage,
    pub walking: bool,
    pub growth_stage: VisualGrowthStage,
    pub watch_rhythm: WatchRhythm,
    pub transition: Option<VisualTransition>,
}

impl RenderContext {
    /// Backwards-compatible visual defaults: adult, steady cadence, and no
    /// semantic bridge.
    pub const fn new(behavior: Behavior, body_language: BodyLanguage, walking: bool) -> Self {
        Self {
            behavior,
            body_language,
            walking,
            growth_stage: VisualGrowthStage::Adult,
            watch_rhythm: WatchRhythm::Steady,
            transition: None,
        }
    }

    pub const fn with_growth_stage(mut self, growth_stage: VisualGrowthStage) -> Self {
        self.growth_stage = growth_stage;
        self
    }

    pub const fn with_watch_rhythm(mut self, watch_rhythm: WatchRhythm) -> Self {
        self.watch_rhythm = watch_rhythm;
        self
    }

    pub const fn with_transition(mut self, transition: Option<VisualTransition>) -> Self {
        self.transition = transition;
        self
    }
}

/// Pick the live-body sprite for this animation frame, on the same
/// half-second beat the sticky header uses. The full body adds short, weighted
/// micro-actions between longer resting poses; frame zero remains canonical
/// for Calm/Static hosts. Sampling never advances life or an event timer.
pub fn sprite_frame(
    behavior: Behavior,
    language: BodyLanguage,
    walking: bool,
    frame: u64,
) -> &'static str {
    live_sprite_frame(RenderContext::new(behavior, language, walking), frame)
}

/// Render all composable appearance inputs. The returned `Cow` stays borrowed
/// for the adult stage and allocates only when the five-character maturity
/// grammar needs to be overlaid on a canonical frame.
pub fn sprite_frame_with_context(context: RenderContext, frame: u64) -> Cow<'static, str> {
    let sprite = if let Some(transition) = context.transition {
        transition.sprite_frame(frame)
    } else {
        live_sprite_frame(context, frame)
    };
    apply_sprite_growth(sprite, context.growth_stage)
}

fn live_sprite_frame(context: RenderContext, frame: u64) -> &'static str {
    let cadence = render_cadence(context);
    animation::sprite(context, frame, cadence).unwrap_or_else(|| {
        base_sprite_frame(
            context.behavior,
            context.body_language,
            context.walking,
            context.watch_rhythm,
            frame / cadence,
        )
    })
}

fn render_cadence(context: RenderContext) -> u64 {
    let base = match context.growth_stage {
        VisualGrowthStage::Juvenile => 4,
        VisualGrowthStage::Adult => 5,
        VisualGrowthStage::Seasoned => 8,
    };
    if !matches!(
        context.behavior,
        Behavior::WatchCommand | Behavior::WatchAgent | Behavior::WatchSettled
    ) {
        return base;
    }
    match context.watch_rhythm {
        WatchRhythm::Steady => base,
        WatchRhythm::Busy | WatchRhythm::Resumed => (base / 2).max(1),
        WatchRhythm::Waiting => base * 2,
    }
}

fn base_sprite_frame(
    behavior: Behavior,
    language: BodyLanguage,
    walking: bool,
    watch_rhythm: WatchRhythm,
    beat: u64,
) -> &'static str {
    let alt = usize::from(beat % 2 == 1);
    match behavior {
        Behavior::Idle if language.drowsy => DOZE_FRAMES[alt],
        Behavior::Idle if walking && language.tense => GAIT_TENSE_FRAMES[alt],
        Behavior::Idle if walking => GAIT_FRAMES[alt],
        Behavior::Idle if language.listless && beat % 12 == 11 => YAWN_FRAME,
        Behavior::Idle if language.tense => IDLE_TENSE,
        Behavior::Idle => IDLE_FRAMES[usize::from(beat % 8 == 7)],
        Behavior::WatchCommand => match (watch_rhythm, language.tense) {
            (WatchRhythm::Busy, true) => WATCH_BUSY_TENSE_FRAMES[alt],
            (WatchRhythm::Busy, false) => WATCH_BUSY_FRAMES[alt],
            (WatchRhythm::Waiting, true) => WATCH_WAITING_TENSE_FRAMES[alt],
            (WatchRhythm::Waiting, false) => WATCH_WAITING_FRAMES[alt],
            (WatchRhythm::Resumed, true) => WATCH_RESUMED_TENSE_FRAMES[alt],
            (WatchRhythm::Resumed, false) => WATCH_RESUMED_FRAMES[alt],
            (WatchRhythm::Steady, true) => WATCH_TENSE_FRAMES[alt],
            (WatchRhythm::Steady, false) => WATCH_FRAMES[alt],
        },
        Behavior::SitNearError => SIT_FRAMES[alt],
        Behavior::Celebrate => CELE_FRAMES[alt],
        Behavior::CelebrateBig => BIG_FRAMES[alt],
        Behavior::RestAfterPush => REST_FRAMES[alt],
        Behavior::GlanceAside => GLANCE_ASIDE_FRAMES[alt],
        Behavior::Sleep => SLEEP_FRAMES[alt],
        // Step only while actually moving; scanning happens while seated.
        Behavior::Explore if walking => GAIT_FRAMES[alt],
        Behavior::Explore => EXPLORE_FRAMES[alt],
        Behavior::Approach => APPROACH_FRAMES[alt],
        Behavior::WatchAgent => match watch_rhythm {
            WatchRhythm::Steady => WATCH_AGENT_FRAMES[alt],
            WatchRhythm::Busy => WATCH_AGENT_BUSY_FRAMES[alt],
            WatchRhythm::Waiting => WATCH_AGENT_WAITING_FRAMES[alt],
            WatchRhythm::Resumed => WATCH_AGENT_RESUMED_FRAMES[alt],
        },
        Behavior::WatchSettled => match watch_rhythm {
            WatchRhythm::Steady => WATCH_SETTLED_FRAMES[alt],
            WatchRhythm::Busy => WATCH_SETTLED_BUSY_FRAMES[alt],
            WatchRhythm::Waiting => WATCH_SETTLED_WAITING_FRAMES[alt],
            WatchRhythm::Resumed => WATCH_SETTLED_RESUMED_FRAMES[alt],
        },
        Behavior::GuardFailure => GUARD_FAILURE_FRAMES[alt],
        Behavior::GuardStuck => GUARD_STUCK_FRAMES[alt],
        Behavior::GuardRecovery => GUARD_RECOVERY_FRAMES[alt],
        Behavior::GuardCautious => GUARD_CAUTIOUS_FRAMES[alt],
        Behavior::InspectError | Behavior::UnknownOutcome => behavior.sprite(),
    }
}

fn apply_sprite_growth(sprite: &'static str, growth_stage: VisualGrowthStage) -> Cow<'static, str> {
    if growth_stage == VisualGrowthStage::Adult {
        return Cow::Borrowed(sprite);
    }
    // All growth substitutions are equal-width ASCII. Copy the frame once,
    // then edit its bytes in place: chained String::replace used to allocate
    // up to eleven temporary strings for every juvenile animation sample.
    let mut evolved = sprite.as_bytes().to_vec();
    match growth_stage {
        VisualGrowthStage::Juvenile => {
            // Rounded ears, larger open eyes, and a short tail. Replacements
            // are ASCII and exactly width-preserving.
            for (from, to) in [
                ("/\\_/\\", "(\\_/)"),
                ("=\\_/=", "(\\_/)"),
                (" o.o ", " O.O "),
                (" o_o ", " O_O "),
                (" -.o ", " -.O "),
                (" o.- ", " O.- "),
                (" ?.o ", " ?.O "),
                (" ^o^ ", " ^O^ "),
                (" >o< ", " >O< "),
                (">~^ <", "> ^ <"),
            ] {
                replace_ascii_in_place(&mut evolved, from.as_bytes(), to.as_bytes());
            }
        }
        VisualGrowthStage::Seasoned => {
            // The right ear has a small notch and neutral open eyes settle to
            // a half-lidded gaze. Its animation cadence is slowed separately.
            for (from, to) in [
                ("/\\_/\\", "/\\_/|"),
                ("=\\_/=", "=\\_/|"),
                (" o.o ", " -.o "),
                (" O.O ", " -.O "),
            ] {
                replace_ascii_in_place(&mut evolved, from.as_bytes(), to.as_bytes());
            }
        }
        VisualGrowthStage::Adult => unreachable!("adult frame returned borrowed above"),
    }
    Cow::Owned(String::from_utf8(evolved).expect("growth frames are fixed ASCII"))
}

fn replace_ascii_in_place(bytes: &mut [u8], from: &[u8], to: &[u8]) {
    debug_assert!(!from.is_empty() && from.len() == to.len());
    let mut at = 0;
    while at + from.len() <= bytes.len() {
        if &bytes[at..at + from.len()] == from {
            bytes[at..at + to.len()].copy_from_slice(to);
            at += from.len();
        } else {
            at += 1;
        }
    }
}

/// Ambient disposition of a genuinely idle body — no command, no reaction
/// hold, no recent typing. Usually utility-selected by [`AmbientMind`]; repo
/// vigils are durable work intentions supplied by the reducer.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AmbientBehavior {
    Idle,
    Sleep,
    Explore,
    Approach,
    /// One or two unresolved build failures: keep the work in sight without
    /// turning a completed error reaction into permanent alarm.
    GuardFailure,
    /// Three or more unresolved failures: a lower, quieter debugging vigil.
    GuardStuck,
    /// A durable, repo-scoped intention supplied by the reducer rather than a
    /// random utility candidate: keep the recovered work company until push.
    GuardRecovery,
    /// Repeated failure/success flips make this recovery worth one more check.
    GuardCautious,
}

impl AmbientBehavior {
    pub const fn display(self) -> Behavior {
        match self {
            Self::Idle => Behavior::Idle,
            Self::Sleep => Behavior::Sleep,
            Self::Explore => Behavior::Explore,
            Self::Approach => Behavior::Approach,
            Self::GuardFailure => Behavior::GuardFailure,
            Self::GuardStuck => Behavior::GuardStuck,
            Self::GuardRecovery => Behavior::GuardRecovery,
            Self::GuardCautious => Behavior::GuardCautious,
        }
    }

    /// Once chosen, a disposition is held before rescoring so behavior does
    /// not reroll every frame — the prototype's behavior_hold_for timers.
    const fn hold_secs(self) -> f32 {
        match self {
            Self::Sleep => 2.5,
            Self::Explore => 1.4,
            Self::Approach => 1.8,
            Self::GuardFailure | Self::GuardStuck | Self::GuardRecovery | Self::GuardCautious => {
                2.0
            }
            Self::Idle => 1.0,
        }
    }

    const fn is_repo_vigil(self) -> bool {
        matches!(
            self,
            Self::GuardFailure | Self::GuardStuck | Self::GuardRecovery | Self::GuardCautious
        )
    }
}

/// Utility-scored ambient behavior selection, ported from the prototype's
/// `choose_utility_behavior`: candidates are scored from the continuous
/// state, the incumbent gets a small inertia bonus, deterministic xorshift
/// jitter keeps ties from freezing, and the winner is held for its own
/// timer. Exhaustion below the private forced-rest energy floor overrides the
/// scores, so the sleep-regenerate loop closes: a drained mind curls up,
/// energy climbs, and another disposition eventually outscores sleep.
#[derive(Debug)]
pub struct AmbientMind {
    current: AmbientBehavior,
    hold_for: f32,
    seed: u64,
}

impl Default for AmbientMind {
    fn default() -> Self {
        Self {
            current: AmbientBehavior::Idle,
            hold_for: 0.0,
            seed: 0x9E37_79B9_7F4A_7C15,
        }
    }
}

impl AmbientMind {
    /// A per-body seed so split-window bodies do not nap and pace in perfect
    /// lockstep. Any seed works; zero is displaced so xorshift never sticks.
    pub fn seeded(seed: u64) -> Self {
        Self {
            seed: (seed | 1).wrapping_mul(0x9E37_79B9_7F4A_7C15),
            ..Self::default()
        }
    }

    pub fn current(&self) -> AmbientBehavior {
        self.current
    }

    /// Reset to plain idle when the body leaves ambient display (typing,
    /// watching, reacting), so a stale disposition never resumes later.
    pub fn interrupt(&mut self) {
        self.current = AmbientBehavior::Idle;
        self.hold_for = 0.0;
    }

    /// Advance the hold timer by `dt` seconds and rescore once it expires.
    /// `idle_for` is how long the terminal has been completely quiet.
    pub fn step(
        &mut self,
        state: LifeState,
        idle_for: f32,
        dt: f32,
        vigil: RepoVigil,
    ) -> AmbientBehavior {
        let dt = if dt.is_finite() {
            dt.clamp(0.0, 1.0)
        } else {
            0.0
        };

        // An unfinished repo loop is an intention, not another noisy utility
        // roll. Its phase picks a stable guard immediately, while genuine
        // exhaustion still wins so the homeostatic sleep loop can close.
        if vigil.is_active() {
            let guard = match vigil {
                RepoVigil::Failure => AmbientBehavior::GuardFailure,
                RepoVigil::Stuck => AmbientBehavior::GuardStuck,
                RepoVigil::Recovery => AmbientBehavior::GuardRecovery,
                RepoVigil::CautiousRecovery => AmbientBehavior::GuardCautious,
                RepoVigil::None => unreachable!("an active vigil has a guard pose"),
            };
            let sleeping_through_vigil =
                self.current == AmbientBehavior::Sleep && state.energy < REPO_VIGIL_WAKE_ENERGY;
            let next = if state.energy < FORCED_REST_ENERGY || sleeping_through_vigil {
                AmbientBehavior::Sleep
            } else {
                guard
            };
            if self.current != next {
                self.current = next;
                self.hold_for = self.current.hold_secs();
            } else {
                self.hold_for = (self.hold_for - dt).max(0.0);
            }
            return self.current;
        }
        if self.current.is_repo_vigil() {
            self.current = AmbientBehavior::Idle;
            self.hold_for = 0.0;
        }
        self.hold_for -= dt;
        if self.hold_for > 0.0 {
            return self.current;
        }
        if state.energy < FORCED_REST_ENERGY {
            self.current = AmbientBehavior::Sleep;
        } else {
            let idle_for = if idle_for.is_finite() {
                idle_for.max(0.0)
            } else {
                0.0
            };
            let candidates = [
                (AmbientBehavior::Idle, 0.30 + state.mood * 0.10),
                (
                    AmbientBehavior::Sleep,
                    (1.0 - state.energy) * 1.15 + idle_for.min(60.0) / 180.0,
                ),
                (
                    AmbientBehavior::Explore,
                    state.boredom * 0.72 + state.curiosity * 0.30,
                ),
                (
                    AmbientBehavior::Approach,
                    state.social_need * 0.72 + state.attachment * 0.12,
                ),
            ];
            let mut best = (AmbientBehavior::Idle, f32::MIN);
            for (candidate, base) in candidates {
                let inertia = if candidate == self.current { 0.08 } else { 0.0 };
                let score = base + inertia + self.jitter();
                if score > best.1 {
                    best = (candidate, score);
                }
            }
            self.current = best.0;
        }
        self.hold_for = self.current.hold_secs();
        self.current
    }

    /// Deterministic xorshift64* noise in [0, 0.08).
    fn jitter(&mut self) -> f32 {
        let mut x = self.seed;
        x ^= x >> 12;
        x ^= x << 25;
        x ^= x >> 27;
        self.seed = x;
        let unit = (x.wrapping_mul(0x2545_F491_4F6C_DD1D) >> 40) as f32 / (1u64 << 24) as f32;
        unit * 0.08
    }
}

/// Select the sticky-header micro-pose for the current animation frame. The
/// cadence is deliberately slow: reacting poses alternate every half second
/// (five 100ms frames), while the idle pose only flicks its tail on one beat
/// in twelve so a quiet header stays quiet. A drowsy mind dozes in the header
/// too.
pub fn sticky_glyph(behavior: Behavior, language: BodyLanguage, frame: u64) -> &'static str {
    base_sticky_glyph(behavior, language, WatchRhythm::Steady, frame / 5)
}

/// Context-aware sticky form. Semantic transitions intentionally remain a
/// property of the one spatial body; the scrollback header keeps the target
/// behavior legible while sharing growth and output rhythm.
pub fn sticky_glyph_with_context(context: RenderContext, frame: u64) -> Cow<'static, str> {
    let beat = frame / render_cadence(context);
    let glyph = base_sticky_glyph(
        context.behavior,
        context.body_language,
        context.watch_rhythm,
        beat,
    );
    apply_glyph_growth(glyph, context.growth_stage)
}

fn base_sticky_glyph(
    behavior: Behavior,
    language: BodyLanguage,
    watch_rhythm: WatchRhythm,
    beat: u64,
) -> &'static str {
    // Flat-eared doze, distinct from RestAfterPush's perked-ear rest glyph.
    if behavior == Behavior::Idle && language.drowsy {
        return if beat % 2 == 1 { "=\\_/=" } else { "=\\z/=" };
    }
    let frames = match (behavior, watch_rhythm) {
        (
            Behavior::WatchCommand | Behavior::WatchAgent | Behavior::WatchSettled,
            WatchRhythm::Busy,
        ) => ["/\\>/\\", "/\\</\\"],
        (Behavior::WatchCommand | Behavior::WatchAgent, WatchRhythm::Waiting) => {
            ["/\\-/\\", "/\\_/\\"]
        }
        (Behavior::WatchSettled, WatchRhythm::Waiting) => ["=\\-/=", "=\\_/="],
        (
            Behavior::WatchCommand | Behavior::WatchAgent | Behavior::WatchSettled,
            WatchRhythm::Resumed,
        ) => ["/\\O/\\", "/\\o/\\"],
        _ => behavior.sticky_frames(),
    };
    let alternate = match behavior {
        Behavior::Idle => beat % 12 == 11,
        _ => beat % 2 == 1,
    };
    frames[usize::from(alternate)]
}

fn apply_glyph_growth(glyph: &'static str, growth_stage: VisualGrowthStage) -> Cow<'static, str> {
    if growth_stage == VisualGrowthStage::Adult {
        return Cow::Borrowed(glyph);
    }
    debug_assert!(glyph.is_ascii());
    debug_assert_eq!(glyph.len(), 5);
    let mut evolved = glyph.as_bytes().to_vec();
    match growth_stage {
        VisualGrowthStage::Juvenile => {
            // Rounded outer ears preserve the center behavior mark.
            evolved[0] = b'(';
            evolved[4] = b')';
            if evolved[2] == b'o' {
                evolved[2] = b'O';
            }
        }
        VisualGrowthStage::Seasoned => {
            // A clipped right ear leaves the behavior mark untouched.
            evolved[4] = b'|';
        }
        VisualGrowthStage::Adult => unreachable!("adult glyph returned borrowed above"),
    }
    Cow::Owned(String::from_utf8(evolved).expect("sticky glyphs are fixed ASCII"))
}

/// Coarse, content-free phases of the Shell Agent lifecycle. Only the phase
/// kind ever crosses the organism boundary — never proposals, commands,
/// model output, or error text.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum AgentPulse {
    /// The session is thinking or running an approved command.
    Working,
    /// A proposal is waiting for the human's review.
    AskingReview,
    /// The task completed (or hit its turn limit).
    Finished,
    /// The session was cancelled or went away.
    Gone,
}

/// Map the shared Agent activity to an ambient pulse. Transport work takes
/// precedence while a request is in flight; idle sessions stay silent.
pub fn agent_state_pulse(state: crate::agent::AgentState, busy: bool) -> Option<AgentPulse> {
    use crate::agent::AgentActivity;
    let activity = if busy {
        Some(AgentActivity::Working)
    } else {
        state.activity()
    };
    activity.map(|activity| match activity {
        AgentActivity::Working => AgentPulse::Working,
        AgentActivity::AskingReview => AgentPulse::AskingReview,
        AgentActivity::Finished => AgentPulse::Finished,
        AgentActivity::Gone => AgentPulse::Gone,
    })
}

/// Fold one Agent lifecycle phase into the shared life state. The Agent
/// occupying the human's attention slowly feeds the organism's social need,
/// which is what finally gives the Approach disposition a genuine niche:
/// when the Agent leaves, the cat comes looking for its human.
pub fn agent_pulse(mut state: LifeState, pulse: AgentPulse) -> LifeState {
    match pulse {
        AgentPulse::Working => {
            state.curiosity += 0.03;
            state.social_need += 0.015;
        }
        AgentPulse::AskingReview => {
            state.curiosity += 0.04;
            state.social_need += 0.02;
        }
        AgentPulse::Finished => {
            state.mood += 0.04;
            state.attachment += 0.02;
            state.social_need += 0.03;
        }
        AgentPulse::Gone => {
            state.social_need += 0.05;
        }
    }
    state.clamp();
    state
}

/// Content-free pulse from the command-correction card: the user accepted the
/// proposed fix. Carries only the fact of acceptance — never the command or
/// correction text.
pub fn correction_accepted(mut state: LifeState) -> LifeState {
    state.confidence += 0.02;
    state.attachment += 0.02;
    state.social_need -= 0.02;
    state.clamp();
    state
}

/// Content-free pulse: the user closed or dismissed a correction card.
/// Repeated dismissals teach the organism to stay quieter — boredom rises and
/// curiosity falls a little more each consecutive time, bounded by clamping.
pub fn correction_dismissed(mut state: LifeState, consecutive: u32) -> LifeState {
    let weight = consecutive.clamp(1, 4) as f32;
    state.boredom += 0.03 * weight;
    state.curiosity -= 0.02 * weight;
    state.social_need -= 0.01;
    state.clamp();
    state
}

/// How well the persistent memory knows the repository a command runs in,
/// derived from the number of remembered per-day records. Content-free: it
/// carries no path or command data, only a coarse familiarity bucket.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RepoArrival {
    Unfamiliar,
    Known,
    Home,
}

impl RepoArrival {
    pub fn from_familiarity(days_remembered: u32) -> Self {
        match days_remembered {
            0 => Self::Unfamiliar,
            1..=6 => Self::Known,
            _ => Self::Home,
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Tone {
    Quiet,
    Active,
    Success,
    Error,
    Warning,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Reaction {
    pub behavior: Behavior,
    pub tone: Tone,
    pub description: String,
    pub speech: Option<&'static str>,
}

impl Reaction {
    /// Maximum native presentation hold for a completed-command reaction.
    /// This is shared semantic policy, not an animation or scheduling request:
    /// input, new work, disabled/hidden hosts, and reduced-motion preferences
    /// retain their native priority. Hosts must not queue expired reactions.
    pub const fn hold_duration(&self) -> Duration {
        let millis = match self.behavior {
            Behavior::Idle => 1_500,
            Behavior::Celebrate if matches!(self.tone, Tone::Quiet) => 1_800,
            Behavior::Celebrate => 2_500,
            Behavior::InspectError => 5_000,
            Behavior::SitNearError => 10_000,
            Behavior::CelebrateBig => 7_000,
            Behavior::RestAfterPush => 5_000,
            Behavior::UnknownOutcome => 4_500,
            // Live-only today; preserve the same bounded fallback if a host
            // ever wraps the cross-pane glance in a Reaction.
            Behavior::GlanceAside => 1_400,
            Behavior::WatchCommand
            | Behavior::Sleep
            | Behavior::Explore
            | Behavior::Approach
            | Behavior::WatchAgent
            | Behavior::WatchSettled
            | Behavior::GuardFailure
            | Behavior::GuardStuck
            | Behavior::GuardRecovery
            | Behavior::GuardCautious => 2_500,
        };
        Duration::from_millis(millis)
    }
}

// Match the existing long-command vigil boundary. Only an authoritative
// completion duration counts; silence, a local clock, or output volume cannot
// turn an ordinary success into a sustained-work acknowledgment.
const SUSTAINED_COMMAND_MS: u64 = 60_000;

#[derive(Debug, Clone, Copy)]
pub struct LifeState {
    pub energy: f32,
    pub mood: f32,
    pub curiosity: f32,
    pub boredom: f32,
    pub stress: f32,
    pub social_need: f32,
    pub attachment: f32,
    pub confidence: f32,
}

/// Coarse, content-free relation between local wall time and the organism's
/// learned working-hours profile. `Unlearned` preserves the original energy
/// drift exactly until enough prior days exist to infer a stable rhythm.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Default)]
pub enum CircadianPhase {
    #[default]
    Unlearned,
    InHours,
    OffHours,
}

impl Default for LifeState {
    fn default() -> Self {
        Self {
            energy: 0.72,
            mood: 0.62,
            curiosity: 0.68,
            boredom: 0.22,
            stress: 0.14,
            social_need: 0.35,
            attachment: 0.30,
            confidence: 0.58,
        }
    }
}

impl LifeState {
    /// Continuous homeostasis between semantic events, ported from the
    /// prototype life engine (`prototypes/ascii-organism/src/life.rs`). `dt`
    /// is seconds; slices are clamped to [0, 1] and non-finite time is
    /// ignored. `resting` is the native stand-in for the prototype's sleep: a
    /// terminal left quiet long enough lets energy recover. Before a rhythm is
    /// learned, waking work keeps the original slow drain; afterwards energy
    /// eases toward a higher in-hours target and a lower off-hours target.
    /// Drives nothing by itself — event reactions remain authoritative.
    pub fn tick(&mut self, dt: f32, user_active: bool, resting: bool, circadian: CircadianPhase) {
        let dt = if dt.is_finite() {
            dt.clamp(0.0, 1.0)
        } else {
            0.0
        };

        // Exhaustion forces micro-rest even in a busy terminal, mirroring the
        // prototype's forced sleep below this energy level: the mind
        // self-regulates near the floor instead of pinning at zero while it
        // watches a long-lived command.
        let resting = resting || self.energy < FORCED_REST_ENERGY;

        if resting {
            self.energy += 0.030 * dt;
        } else {
            match circadian {
                CircadianPhase::Unlearned => self.energy -= 0.002 * dt,
                CircadianPhase::InHours => {
                    self.energy = move_toward(self.energy, 0.65, 0.002 * dt);
                }
                CircadianPhase::OffHours => {
                    self.energy = move_toward(self.energy, 0.35, 0.002 * dt);
                }
            }
        }

        if user_active {
            self.boredom -= 0.010 * dt;
            self.curiosity += 0.003 * dt;
            self.social_need -= 0.006 * dt;
        } else {
            self.boredom += 0.004 * dt;
            self.social_need += 0.001 * dt;
        }

        self.stress -= 0.003 * dt;
        let target_mood = (self.energy + self.confidence) * 0.5 - self.stress * 0.35;
        self.mood += (target_mood - self.mood) * 0.08 * dt;
        self.clamp();
    }

    fn clamp(&mut self) {
        self.energy = bounded(self.energy);
        self.mood = bounded(self.mood);
        self.curiosity = bounded(self.curiosity);
        self.boredom = bounded(self.boredom);
        self.stress = bounded(self.stress);
        self.social_need = bounded(self.social_need);
        self.attachment = bounded(self.attachment);
        self.confidence = bounded(self.confidence);
    }

    #[cfg(test)]
    fn values(self) -> [f32; 8] {
        [
            self.energy,
            self.mood,
            self.curiosity,
            self.boredom,
            self.stress,
            self.social_need,
            self.attachment,
            self.confidence,
        ]
    }
}

fn move_toward(current: f32, target: f32, max_step: f32) -> f32 {
    if !current.is_finite() || !target.is_finite() || !max_step.is_finite() {
        return 0.5;
    }
    let step = max_step.max(0.0);
    if current < target {
        (current + step).min(target)
    } else {
        (current - step).max(target)
    }
}

fn bounded(value: f32) -> f32 {
    if value.is_finite() {
        value.clamp(0.0, 1.0)
    } else {
        0.5
    }
}

/// Below this energy the tick rests regardless of terminal activity — the
/// prototype's forced-sleep threshold, keeping exhaustion self-limiting.
const FORCED_REST_ENERGY: f32 = 0.15;
/// Once a repo vigil has actually fallen asleep, let it refill beyond the
/// forced-rest edge before resuming. This hysteresis prevents a one-frame
/// sleep/guard oscillation around [`FORCED_REST_ENERGY`].
const REPO_VIGIL_WAKE_ENERGY: f32 = 0.25;
/// First failure after this many clean passes today reads as a broken streak
/// and reacts with amplified stress instead of the routine inspection.
const SENSITIZATION_CLEAN_RUNS: u32 = 5;
/// Any-command consecutive non-zero exits before the organism visibly wearies.
const ROUGH_STREAK_THRESHOLD: u32 = 3;

#[derive(Debug, Default)]
pub struct NativeOrganism {
    state: LifeState,
    build_failures: u32,
    active_kind: Option<CommandKind>,
    recovered_build: bool,
    /// Same-day failure→success episodes remembered for this repo. It does not
    /// claim a particular test is flaky; the third flip only makes a pending
    /// recovery visibly cautious until push.
    failure_success_flips: u32,
    /// Today's build/test successes in the active repo context. Habituation:
    /// each additional clean pass lands with 1/(1+prior/4) of the excitement,
    /// where `prior` is this count before the pass is recorded.
    successes_today: u32,
    /// Today's build/test failures in the active repo context, for the
    /// sensitized first-crack-after-a-clean-run reaction.
    failures_today: u32,
    /// Session-local consecutive non-zero exits across every command kind.
    /// Never persisted; the durable memory keeps observing only build/push.
    rough_streak: u32,
    pending_arrival: Option<RepoArrival>,
    /// The active command directly followed an accepted correction card.
    assisted: bool,
    /// The active command was submitted by the Shell Agent, not typed by the
    /// human. Content-free: only the fact, never the proposal or command.
    agent_driven: bool,
}

impl NativeOrganism {
    pub fn from_persisted_state(mut state: LifeState) -> Self {
        state.clamp();
        Self {
            state,
            ..Self::default()
        }
    }

    pub fn state(&self) -> LifeState {
        self.state
    }

    /// Whether this repo/day has a recovered build that memory has not yet
    /// seen followed by a successful push. This is a content-free intention:
    /// it carries neither the command nor repository identity.
    pub fn guarding_recovery(&self) -> bool {
        self.recovered_build
    }

    pub fn repo_work_state(&self) -> RepoWorkState {
        RepoWorkState::new(
            self.build_failures,
            self.recovered_build,
            self.failure_success_flips,
        )
    }

    pub fn repo_vigil(&self) -> RepoVigil {
        self.repo_work_state().vigil()
    }

    /// Reconcile the pane-local intention with the memory layer's ordered
    /// repo/day replay. Returns whether any visible work fact changed.
    pub fn sync_repo_work_state(&mut self, work: RepoWorkState) -> bool {
        let work = RepoWorkState::new(
            work.open_failures,
            work.recovered_pending_push,
            work.failure_success_flips,
        );
        if self.repo_work_state() == work {
            return false;
        }
        self.build_failures = work.open_failures;
        self.recovered_build = work.recovered_pending_push;
        self.failure_success_flips = work.failure_success_flips;
        true
    }

    /// Restore the unfinished build streak for the exact repo/day selected by
    /// the memory layer. Switching repositories calls this again, so failures
    /// can never leak into another checkout's celebration level.
    pub fn restore_build_failures(&mut self, failures: u32) {
        self.build_failures = failures;
        self.recovered_build = false;
        self.failure_success_flips = 0;
    }

    pub fn restore_repo_context(
        &mut self,
        failures: u32,
        recovered_build: bool,
        successes_today: u32,
        failures_today: u32,
    ) {
        self.restore_repo_work_context(
            RepoWorkState::new(failures, recovered_build, 0),
            successes_today,
            failures_today,
        );
    }

    pub fn restore_repo_work_context(
        &mut self,
        work: RepoWorkState,
        successes_today: u32,
        failures_today: u32,
    ) {
        self.sync_repo_work_state(work);
        self.successes_today = successes_today;
        self.failures_today = failures_today;
    }

    /// Note that the next command runs in a repository the memory layer just
    /// switched to. Consumed by the next `command_started` reduction.
    pub fn note_repo_arrival(&mut self, arrival: RepoArrival) {
        self.pending_arrival = Some(arrival);
    }

    /// The pane genuinely left the repository before a queued human greeting
    /// could be consumed (for example, an Agent entered it first). Never let
    /// that repo-specific attachment leak into an unrelated cwd.
    pub fn clear_repo_arrival(&mut self) {
        self.pending_arrival = None;
    }

    /// Note that the active command directly followed an accepted correction
    /// card. Consumed by the next `command_finished` reduction.
    pub fn note_assisted_command(&mut self) {
        self.assisted = true;
    }

    /// Record whether the active command was submitted by the Shell Agent.
    /// Set unconditionally at every command start (so a stale flag can never
    /// outlive a lost command), consumed by the next `command_finished`
    /// reduction: the organism watches from a little apart and keeps its big
    /// celebrations — and its debugging empathy — for commands the human
    /// typed themself.
    pub fn set_agent_command(&mut self, agent_driven: bool) {
        self.agent_driven = agent_driven;
    }

    /// Retire an unfinished command's transient attribution without inferring
    /// an outcome. Disabling a host observer may prevent its eventual finish
    /// from being observed; that command's assist and ownership must not carry
    /// into the next one. Life, repository work, and pending arrivals stay put.
    pub fn discard_active_command(&mut self) {
        self.active_kind = None;
        self.assisted = false;
        self.agent_driven = false;
    }

    /// The Agent's approved command ended without its authoritative end
    /// marker. React with restrained caution, never with celebration.
    pub fn agent_execution_lost(&mut self) -> Reaction {
        self.agent_driven = false;
        self.active_kind = None;
        self.state.curiosity += 0.04;
        self.state.stress += 0.05;
        self.state.clamp();
        Reaction {
            behavior: Behavior::UnknownOutcome,
            tone: Tone::Warning,
            description: "the Agent's command ended without its end marker".to_string(),
            speech: None,
        }
    }

    /// A local calendar boundary passed while this pane stayed alive. Today's
    /// habituation/sensitization counters and unfinished repo intentions
    /// restart; repo-backed contexts are re-seeded from the day-scoped memory
    /// on the next build anyway.
    pub fn roll_over_day(&mut self) {
        self.build_failures = 0;
        self.recovered_build = false;
        self.failure_success_flips = 0;
        self.successes_today = 0;
        self.failures_today = 0;
    }

    /// Pull the latest window-shared continuous state into this pane-local
    /// behavior context before reducing an event.
    pub fn sync_state(&mut self, mut state: LifeState) {
        state.clamp();
        self.state = state;
    }

    pub fn idle_reaction(&self) -> Reaction {
        match self.repo_vigil() {
            RepoVigil::Failure => Reaction {
                behavior: Behavior::GuardFailure,
                tone: Tone::Quiet,
                description: format!(
                    "keeping build failure {} in sight · waiting for another build/test",
                    self.build_failures
                ),
                speech: None,
            },
            RepoVigil::Stuck => Reaction {
                behavior: Behavior::GuardStuck,
                // More failures lower the posture; they do not make the
                // durable card louder than the first unresolved failure.
                tone: Tone::Quiet,
                description: format!(
                    "quiet beside {} unresolved build failures · waiting without nagging",
                    self.build_failures
                ),
                speech: None,
            },
            RepoVigil::Recovery => Reaction {
                behavior: Behavior::GuardRecovery,
                tone: Tone::Quiet,
                description: "keeping watch over recovered work · waiting for git push".to_string(),
                speech: None,
            },
            RepoVigil::CautiousRecovery => Reaction {
                behavior: Behavior::GuardCautious,
                tone: Tone::Warning,
                description:
                    "recovered work has flipped repeatedly today · checking once more before git push"
                        .to_string(),
                speech: None,
            },
            RepoVigil::None => Reaction {
                behavior: Behavior::Idle,
                tone: Tone::Quiet,
                description: "quiet · waiting for a real Block event".to_string(),
                speech: None,
            },
        }
    }

    pub fn command_started(&mut self, kind: CommandKind) -> Reaction {
        self.active_kind = Some(kind);
        self.state.energy -= 0.01;
        self.state.curiosity += if kind == CommandKind::BuildOrTest {
            0.10
        } else {
            0.04
        };
        self.state.boredom -= 0.08;

        if self.agent_driven {
            // Crouch a little apart: the Agent is working, not the human. A
            // pending repo greeting stays queued for the human's own first
            // command instead of being spent on the Agent's.
            self.state.clamp();
            return Reaction {
                behavior: Behavior::WatchAgent,
                tone: Tone::Quiet,
                description: format!("watching the Agent run a {} command", kind.label()),
                speech: None,
            };
        }

        let arrival = self.pending_arrival.take();
        match arrival {
            Some(RepoArrival::Unfamiliar) => {
                // Shy in a checkout it has never remembered: less sure of
                // itself, more curious, and deliberately quiet.
                self.state.confidence -= 0.06;
                self.state.attachment -= 0.02;
                self.state.stress += 0.03;
                self.state.curiosity += 0.08;
            }
            Some(RepoArrival::Known) => self.state.attachment += 0.02,
            Some(RepoArrival::Home) => {
                self.state.attachment += 0.05;
                self.state.mood += 0.03;
                self.state.social_need -= 0.02;
            }
            None => {}
        }
        self.state.clamp();
        match arrival {
            Some(RepoArrival::Unfamiliar) => Reaction {
                behavior: Behavior::WatchCommand,
                tone: Tone::Quiet,
                description: format!(
                    "watching real {} event · first day in this repo",
                    kind.label()
                ),
                speech: None,
            },
            Some(RepoArrival::Home) => Reaction {
                behavior: Behavior::WatchCommand,
                tone: Tone::Active,
                description: format!("watching real {} event · well-known repo", kind.label()),
                speech: Some("回来了。"),
            },
            _ => Reaction {
                behavior: Behavior::WatchCommand,
                tone: Tone::Active,
                description: format!("watching real {} event", kind.label()),
                speech: None,
            },
        }
    }

    pub fn command_finished(
        &mut self,
        classified: CommandKind,
        exit_code: Option<i32>,
        duration_ms: Option<u64>,
    ) -> Reaction {
        let kind = if classified == CommandKind::Other {
            self.active_kind.unwrap_or(classified)
        } else {
            classified
        };
        self.active_kind = None;
        let assisted = std::mem::take(&mut self.assisted);
        let agent_driven = std::mem::take(&mut self.agent_driven);

        let duration = duration_label(duration_ms);
        let Some(exit_code) = exit_code else {
            self.state.curiosity += 0.03;
            self.state.clamp();
            return Reaction {
                behavior: Behavior::UnknownOutcome,
                tone: Tone::Warning,
                description: format!("{} finished · status unknown{duration}", kind.label()),
                speech: None,
            };
        };

        if exit_code != 0 {
            self.rough_streak = self.rough_streak.saturating_add(1);
            // The first crack after a clean run of passes stings more than one
            // more failure in an already rough day. An Agent's failure is the
            // Agent's problem: softer stress, and the human's confidence and
            // clean-run pride are untouched.
            let sensitized = !agent_driven
                && kind == CommandKind::BuildOrTest
                && self.failures_today == 0
                && self.successes_today >= SENSITIZATION_CLEAN_RUNS;
            self.state.mood -= if agent_driven { 0.04 } else { 0.08 };
            self.state.stress += if agent_driven {
                0.06
            } else if sensitized {
                0.20
            } else {
                0.12
            };
            if !agent_driven {
                self.state.confidence -= if sensitized { 0.06 } else { 0.04 };
            }
            self.state.curiosity += 0.05;
            self.state.clamp();

            let failures = if kind == CommandKind::BuildOrTest {
                self.failures_today = self.failures_today.saturating_add(1);
                self.build_failures = self.build_failures.saturating_add(1);
                self.recovered_build = false;
                self.build_failures
            } else {
                0
            };
            let rough = failures == 0 && self.rough_streak >= ROUGH_STREAK_THRESHOLD;
            let mut description = if sensitized {
                format!(
                    "exit {exit_code}{duration} · first crack after {} clean run(s)",
                    self.successes_today
                )
            } else if rough {
                format!(
                    "exit {exit_code}{duration} · {} rough commands in a row",
                    self.rough_streak
                )
            } else if failures == 0 {
                format!("exit {exit_code}{duration} · inspecting the finished Block")
            } else {
                format!("exit {exit_code}{duration} · build failure {failures}")
            };
            if agent_driven {
                description.push_str(" · agent-driven");
            }
            return Reaction {
                behavior: if failures >= 2 || rough {
                    Behavior::SitNearError
                } else {
                    Behavior::InspectError
                },
                tone: Tone::Error,
                description,
                speech: if agent_driven {
                    // The human is not debugging yet; pointing would nag.
                    None
                } else if failures > 0 {
                    (failures <= 1).then_some("这里。")
                } else {
                    // Speak up on the first stumble; a continuing rough streak
                    // sits nearby in silence instead of nagging.
                    (self.rough_streak <= 1).then_some("这里。")
                },
            };
        }

        self.rough_streak = 0;
        if assisted {
            self.state.confidence += 0.04;
            self.state.attachment += 0.03;
        }
        match kind {
            CommandKind::BuildOrTest => {
                let failures = std::mem::take(&mut self.build_failures);
                if failures > 0 {
                    self.failure_success_flips = self.failure_success_flips.saturating_add(1);
                }
                // A later clean build must not forget an earlier recovery that
                // is still waiting for push. Memory preserves this flag until
                // a new build failure or a successful push; mirror it here.
                self.recovered_build |= failures > 0;
                // Habituation: excitement scales by 1/(1+prior/4), where
                // `prior` counts the clean passes already seen today, so the
                // day's first pass lands at full strength. Recoveries always
                // keep full strength — big celebrations stay reserved for
                // genuinely rare moments.
                let habituation = if failures == 0 {
                    self.successes_today
                } else {
                    0
                };
                let damp = 1.0 / (1.0 + habituation as f32 / 4.0);
                self.successes_today = self.successes_today.saturating_add(1);
                // An Agent-driven pass earns half the glow and none of the
                // human's confidence — they didn't type it.
                let ownership = if agent_driven { 0.5 } else { 1.0 };
                self.state.mood += (0.10 + failures.min(5) as f32 * 0.025) * damp * ownership;
                self.state.stress -= 0.12;
                self.state.confidence += 0.08 * damp * ownership;
                self.state.attachment += 0.025;
                self.state.clamp();
                let (behavior, tone, speech) = if agent_driven {
                    // A quiet nod: big celebrations and words stay reserved
                    // for commands the human typed themself.
                    (Behavior::Celebrate, Tone::Success, None)
                } else if failures == 0 {
                    match habituation {
                        0..=2 => (Behavior::Celebrate, Tone::Success, Some("过了。")),
                        3..=5 => (Behavior::Celebrate, Tone::Success, None),
                        _ => (Behavior::Celebrate, Tone::Quiet, None),
                    }
                } else if failures <= 2 {
                    (Behavior::Celebrate, Tone::Success, Some("好了。"))
                } else {
                    (Behavior::CelebrateBig, Tone::Success, Some("终于。"))
                };
                let mut description = if failures == 0 && habituation >= 3 {
                    format!(
                        "build/test passed{duration} · pass {} today",
                        habituation.saturating_add(1)
                    )
                } else {
                    format!("build/test passed after {failures} failure(s){duration}")
                };
                if agent_driven {
                    description.push_str(" · agent-driven");
                }
                Reaction {
                    behavior,
                    tone,
                    description,
                    speech,
                }
            }
            CommandKind::GitPush => {
                self.state.energy -= 0.02;
                self.state.mood += 0.06;
                self.state.stress -= 0.08;
                self.state.attachment += if agent_driven { 0.02 } else { 0.04 };
                self.state.clamp();
                let recovered = std::mem::take(&mut self.recovered_build);
                Reaction {
                    behavior: Behavior::RestAfterPush,
                    tone: Tone::Success,
                    description: if agent_driven {
                        format!("git push completed{duration} · agent-driven")
                    } else {
                        format!("git push completed{duration}")
                    },
                    speech: (recovered && !agent_driven).then_some("收好了。"),
                }
            }
            CommandKind::Other => {
                self.state.mood += 0.01;
                self.state.stress -= 0.02;
                self.state.boredom -= 0.02;
                self.state.clamp();
                if assisted {
                    // Acknowledge accepted help with a small nod, never a big
                    // celebration and never a word.
                    Reaction {
                        behavior: Behavior::Celebrate,
                        tone: Tone::Success,
                        description: format!("corrected command worked{duration}"),
                        speech: None,
                    }
                } else {
                    // A successful long wait deserves a quiet acknowledgment
                    // even when it was not a recognized build or test. Reuse
                    // the small success pose without speech, stronger life
                    // rewards, or changing the repository's work intention.
                    let sustained = duration_ms.is_some_and(|ms| ms >= SUSTAINED_COMMAND_MS);
                    Reaction {
                        behavior: if sustained {
                            Behavior::Celebrate
                        } else {
                            Behavior::Idle
                        },
                        tone: Tone::Quiet,
                        description: format!("command finished cleanly{duration}"),
                        speech: None,
                    }
                }
            }
        }
    }
}

fn duration_label(duration_ms: Option<u64>) -> String {
    match duration_ms {
        Some(ms) if ms >= 1_000 => format!(" · {:.1}s", ms as f64 / 1_000.0),
        Some(ms) => format!(" · {ms}ms"),
        None => String::new(),
    }
}

pub fn classify_command(command: &str) -> CommandKind {
    const MAX_CLASSIFIER_TOKENS: usize = 16;
    const MAX_WRAPPER_DEPTH: usize = 8;

    let mut raw_tokens = command.split_whitespace();
    let Some(bounded_tokens) = raw_tokens
        .by_ref()
        .take(MAX_CLASSIFIER_TOKENS)
        .map(normalize_token)
        .collect::<Option<Vec<_>>>()
    else {
        // A shortened token can hide a dry-run flag or change the program
        // identity. Keep the allocation ceiling without interpreting a prefix
        // as the complete command.
        return CommandKind::Other;
    };
    // Classification stays bounded, but a truncated push can hide a trailing
    // `--dry-run`. Such a command must fail closed instead of publishing the
    // recovery intention on incomplete evidence.
    let truncated = raw_tokens.next().is_some();
    let mut tokens = bounded_tokens
        .into_iter()
        .filter(|token| !token.is_empty())
        .peekable();

    while tokens
        .peek()
        .is_some_and(|token| is_environment_assignment(token))
    {
        tokens.next();
    }

    let mut program = tokens.next().unwrap_or_default();
    for _ in 0..MAX_WRAPPER_DEPTH {
        let wrapper = program.rsplit('/').next().unwrap_or(program.as_str());
        match wrapper {
            "command" | "builtin" => skip_wrapper_options(&mut tokens, &[]),
            "exec" => skip_wrapper_options(&mut tokens, &["-a", "--argv0"]),
            "env" => {
                skip_wrapper_options(
                    &mut tokens,
                    &["-u", "--unset", "-c", "--chdir", "-s", "--split-string"],
                );
                while tokens
                    .peek()
                    .is_some_and(|token| is_environment_assignment(token))
                {
                    tokens.next();
                }
            }
            "sudo" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-u",
                    "--user",
                    "-g",
                    "--group",
                    "-h",
                    "--host",
                    "-p",
                    "--prompt",
                    "-c",
                    "--close-from",
                    "-r",
                    "--chroot",
                    "-t",
                    "--command-timeout",
                    "--role",
                    "--type",
                ],
            ),
            "time" => skip_wrapper_options(&mut tokens, &["-f", "--format", "-o", "--output"]),
            "nohup" => skip_wrapper_options(&mut tokens, &[]),
            "nice" => skip_wrapper_options(&mut tokens, &["-n", "--adjustment"]),
            "timeout" => {
                skip_wrapper_options(&mut tokens, &["-s", "--signal", "-k", "--kill-after"]);
                // Duration positional before PROGRAM (`timeout 5 cargo test`).
                if tokens
                    .peek()
                    .is_some_and(|token| token.chars().all(|c| c.is_ascii_digit() || c == '.'))
                {
                    tokens.next();
                }
            }
            "stdbuf" => skip_wrapper_options(
                &mut tokens,
                &["-i", "--input", "-o", "--output", "-e", "--error"],
            ),
            "eatmydata" => skip_wrapper_options(&mut tokens, &[]),
            "chronic" => skip_wrapper_options(&mut tokens, &[]),
            "annotate-output" => {
                // Optional +FORMAT date stamp before PROGRAM (devscripts).
                if tokens.peek().is_some_and(|token| token.starts_with('+')) {
                    tokens.next();
                }
                skip_wrapper_options(&mut tokens, &[]);
            }
            "numactl" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-i",
                    "--interleave",
                    "-N",
                    "--cpunodebind",
                    "-C",
                    "--physcpubind",
                    "-m",
                    "--membind",
                    "-p",
                    "--preferred",
                ],
            ),
            "flock" => {
                skip_wrapper_options(
                    &mut tokens,
                    &["-w", "--timeout", "-E", "--conflict-exit-code"],
                );
                // FILE positional before CMD (FD-only forms have no child).
                if let Some(file) = tokens.peek() {
                    if !file.starts_with('-') && !file.bytes().all(|b| b.is_ascii_digit()) {
                        let mut lookahead = tokens.clone();
                        lookahead.next();
                        if lookahead.peek().is_some() {
                            tokens.next();
                            if tokens.peek().is_some_and(|token| token == "--") {
                                tokens.next();
                            }
                        }
                    }
                }
            }
            "softlimit" => skip_wrapper_options(
                &mut tokens,
                &["-m", "-d", "-s", "-a", "-c", "-n", "-f", "-r", "-o", "-p"],
            ),
            "chpst" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-u", "-U", "-e", "-b", "-n", "-m", "-d", "-o", "-p", "-f", "-c",
                ],
            ),
            "setuidgid" | "s6-setuidgid" => {
                // Optional `--` then USER positional (`s6-setuidgid -- nobody
                // cargo test`). No option table; dashed help stays a flag so
                // skip_wrapper_options does not eat the account word.
                skip_wrapper_options(&mut tokens, &[]);
                skip_wrapper_positional(&mut tokens);
            }
            "setlock" => {
                skip_wrapper_options(&mut tokens, &[]);
                skip_wrapper_positional(&mut tokens);
            }
            "daemonize" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-c",
                    "--chdir",
                    "-e",
                    "--err",
                    "--stderr",
                    "-E",
                    "--env",
                    "-o",
                    "--out",
                    "--stdout",
                    "-p",
                    "--pidfile",
                    "-u",
                    "--user",
                    "-l",
                    "--lockfile",
                    // `-a` / `-v` / `--verbose` are flag-only (append/verbose);
                    // they must not sit in this list or they eat the child path.
                ],
            ),
            "envdir" => {
                // DIR positional before CMD (`envdir /env cargo test`).
                if let Some(dir) = tokens.peek() {
                    if !dir.starts_with('-') {
                        let mut lookahead = tokens.clone();
                        lookahead.next();
                        if lookahead.peek().is_some() {
                            tokens.next();
                        }
                    }
                }
            }
            "rlwrap" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-f",
                    "--file",
                    "-H",
                    "--history-filename",
                    "-s",
                    "--histsize",
                    "-S",
                    "-p",
                    "--prompt",
                    "-P",
                    "--password-prompt",
                    "-z",
                    "--filter",
                ],
            ),
            "fakeroot" => skip_wrapper_options(&mut tokens, &[]),
            "proot" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-r", "--rootfs", "-b", "--bind", "-w", "--pwd", "--cwd", "-q", "--qemu", "-S",
                ],
            ),
            "firejail" => skip_wrapper_options(
                &mut tokens,
                &[
                    "--private-home",
                    "--net",
                    "--profile",
                    "--name",
                    "--hostname",
                    "--join",
                    "--whitelist",
                    "--blacklist",
                    "--read-only",
                    "--read-write",
                    "--tmpfs",
                    "--bind",
                    "--shell",
                    "--dns",
                    "--chroot",
                    "--env",
                    "--rmenv",
                ],
            ),
            "cgexec" => skip_wrapper_options(&mut tokens, &["-g"]),
            "schedtool" => skip_wrapper_options(&mut tokens, &["-a", "-p", "-n", "-M"]),
            "torsocks" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-u",
                    "--user",
                    "-p",
                    "--pass",
                    "-a",
                    "--address",
                    "-P",
                    "--port",
                ],
            ),
            "proxychains" | "proxychains3" | "proxychains4" => {
                skip_wrapper_options(&mut tokens, &["-f"])
            }
            "dbus-run-session" => {
                skip_wrapper_options(&mut tokens, &["--dbus-daemon", "--config-file"])
            }
            "runcon" => {
                // Option form (`-t TYPE CMD`) vs CONTEXT form (`CONTEXT CMD`).
                // Only the latter has a positional meta operand to skip.
                let option_form = tokens.peek().is_some_and(|token| token.starts_with('-'));
                skip_wrapper_options(
                    &mut tokens,
                    &[
                        "-u", "--user", "-r", "--role", "-t", "--type", "-l", "--range",
                    ],
                );
                if !option_form {
                    if let Some(context) = tokens.peek() {
                        if !context.starts_with('-') {
                            let mut lookahead = tokens.clone();
                            lookahead.next();
                            if lookahead.peek().is_some() {
                                tokens.next();
                            }
                        }
                    }
                }
            }
            "xvfb-run" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-e",
                    "--error-file",
                    "-f",
                    "--auth-file",
                    "-n",
                    "--server-num",
                    "-p",
                    "--xauth-protocol",
                    "-s",
                    "--server-args",
                ],
            ),
            "strace" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-e",
                    "--trace",
                    "-p",
                    "--attach",
                    "-o",
                    "--output",
                    "-s",
                    "--string-limit",
                    "-S",
                    "--summary-sort-by",
                    "-u",
                    "--user",
                    "-E",
                    "--env",
                    "-P",
                    "--trace-path",
                    "-b",
                    "--detach-on",
                    "-I",
                    "--interruptible",
                    "-O",
                    "--summary-syscall-overhead",
                    "-a",
                    "--columns",
                    "-X",
                    "--const-print-style",
                    "-U",
                    "--summary-columns",
                    "--syscall-limit",
                ],
            ),
            "scriptlive" => {
                // `scriptlive [options] typescript [command…]` — peel known
                // meta; `-c` stays visible; skip typescript only when -I/-B
                // did not already name it.
                let mut saw_typescript_opt = false;
                while let Some(option) = tokens.peek().cloned() {
                    if option == "--" {
                        tokens.next();
                        break;
                    }
                    if option == "-" {
                        return CommandKind::Other;
                    }
                    if !option.starts_with('-') {
                        break;
                    }
                    tokens.next();
                    let (name, attached) = if let Some(long) = option.strip_prefix("--") {
                        long.split_once('=')
                            .map_or((long, None), |(n, v)| (n, Some(v)))
                    } else {
                        let short = option.trim_start_matches('-');
                        let flag = short.chars().next().unwrap_or('\0');
                        let rest = &short[flag.len_utf8()..];
                        (
                            match flag {
                                't' => "timing",
                                'T' => "log-timing",
                                'I' => "log-in",
                                'B' => "log-io",
                                'd' => "divisor",
                                'm' => "maxdelay",
                                'c' => "command",
                                _ => "",
                            },
                            (!rest.is_empty()).then_some(rest),
                        )
                    };
                    if name.is_empty() || name == "command" {
                        // Unknown short cluster or `-c`: stop so CMD stays.
                        break;
                    }
                    if matches!(name, "log-in" | "log-io") {
                        saw_typescript_opt = true;
                    }
                    if attached.is_none()
                        && matches!(
                            name,
                            "timing" | "log-timing" | "log-in" | "log-io" | "divisor" | "maxdelay"
                        )
                    {
                        tokens.next();
                    }
                }
                if !saw_typescript_opt {
                    if let Some(file) = tokens.peek() {
                        if !file.starts_with('-') {
                            let mut lookahead = tokens.clone();
                            lookahead.next();
                            if lookahead.peek().is_some() {
                                tokens.next();
                                if tokens.peek().is_some_and(|token| token == "--") {
                                    tokens.next();
                                }
                            }
                        }
                    }
                }
            }
            "systemd-cat" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-t",
                    "--identifier",
                    "-p",
                    "--priority",
                    "--stderr-priority",
                    "--level-prefix",
                ],
            ),
            "gnome-session-inhibit" => {
                skip_wrapper_options(&mut tokens, &["--app-id", "--reason", "--inhibit"])
            }
            "systemd-inhibit" => {
                skip_wrapper_options(&mut tokens, &["--what", "--who", "--why", "--mode"])
            }
            "systemd-socket-activate" => skip_wrapper_options(
                &mut tokens,
                &["-l", "--listen", "-E", "--setenv", "--fdname"],
            ),
            "aa-exec" => {
                skip_wrapper_options(&mut tokens, &["-p", "--profile", "-n", "--namespace"])
            }
            // Privilege dispatchers already in STAGE_PREFIXES; peel so the
            // organism work loop still sees cargo/git behind them.
            "doas" | "sudoedit" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-u",
                    "--user",
                    "-g",
                    "--group",
                    "-h",
                    "--host",
                    "-p",
                    "--prompt",
                    "-C",
                    "--close-from",
                    "-D",
                    "--chdir",
                    "-R",
                    "--chroot",
                    "-T",
                    "--command-timeout",
                    "-r",
                    "--role",
                    "-t",
                    "--type",
                ],
            ),
            "pkexec" | "run0" => skip_wrapper_options(
                &mut tokens,
                &["-u", "--user", "-g", "--group", "--userspec"],
            ),
            "runuser" => {
                // Option form (`-u root -- CMD`) vs USER form (`USER CMD`).
                let option_form = tokens.peek().is_some_and(|token| token.starts_with('-'));
                skip_wrapper_options(
                    &mut tokens,
                    &["-u", "--user", "-g", "--group", "--userspec", "-G"],
                );
                if !option_form {
                    skip_wrapper_positional(&mut tokens);
                }
            }
            "gosu" | "su-exec" => {
                // USER positional before CMD (`gosu root cargo test`).
                skip_wrapper_options(
                    &mut tokens,
                    &["-u", "--user", "-g", "--group", "--userspec", "-G"],
                );
                skip_wrapper_positional(&mut tokens);
            }
            "su" => {
                // `-c`/`-s` leave the payload word visible (not meta). Group
                // meta only — do not guess a USER positional (ambiguous with
                // PROGRAM after `su -- CMD` / `su -g root -- CMD`).
                skip_wrapper_options(&mut tokens, &["-g", "--group", "-G"]);
            }
            // util-linux / scheduling wrappers already in STAGE_PREFIXES.
            "chroot" => {
                skip_wrapper_options(&mut tokens, &["--groups", "--userspec", "--skip-chdir"]);
                skip_wrapper_positional(&mut tokens);
            }
            "chrt" => {
                skip_wrapper_options(
                    &mut tokens,
                    &[
                        "-T",
                        "--sched-runtime",
                        "-P",
                        "--sched-period",
                        "-D",
                        "--sched-deadline",
                    ],
                );
                // Priority is a bare number before PROGRAM (`chrt 1 cargo`).
                if tokens
                    .peek()
                    .is_some_and(|token| token.chars().all(|c| c.is_ascii_digit()))
                {
                    let mut lookahead = tokens.clone();
                    lookahead.next();
                    if lookahead.peek().is_some() {
                        tokens.next();
                    }
                }
            }
            "taskset" | "setarch" => {
                // Mask / personality operand before PROGRAM.
                skip_wrapper_options(&mut tokens, &["-B", "--base-offset"]);
                skip_wrapper_positional(&mut tokens);
            }
            "setsid" => skip_wrapper_options(&mut tokens, &[]),
            // kbd openvt: `-c`/`--console` take a VT number before COMMAND.
            "openvt" => skip_wrapper_options(&mut tokens, &["-c", "--console"]),
            "setpriv" => skip_wrapper_options(
                &mut tokens,
                &[
                    "--ambient-caps",
                    "--inh-caps",
                    "--bounding-set",
                    "--ruid",
                    "--euid",
                    "--rgid",
                    "--egid",
                    "--reuid",
                    "--regid",
                    "--groups",
                    "--securebits",
                    "--pdeathsig",
                    "--selinux-label",
                    "--apparmor-profile",
                ],
            ),
            "ionice" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-c",
                    "--class",
                    "-n",
                    "--classdata",
                    "-p",
                    "--pid",
                    "-P",
                    "--pgid",
                ],
            ),
            "choom" => skip_wrapper_options(&mut tokens, &["-n", "--adjust", "-p", "--pid"]),
            "uclampset" => skip_wrapper_options(&mut tokens, &["-m", "-M", "-p", "--pid"]),
            "gamemoderun" => skip_wrapper_options(&mut tokens, &[]),
            "prlimit" => skip_wrapper_options(&mut tokens, &["-p", "--pid", "-o", "--output"]),
            // Remaining STAGE_PREFIXES already peeled above this arm.
            "capsh" => skip_wrapper_options(
                &mut tokens,
                &["--gid", "--groups", "--user", "--uid", "--caps"],
            ),
            "dumb-init" => skip_wrapper_options(&mut tokens, &[]),
            "tini" => skip_wrapper_options(
                &mut tokens,
                &["-p", "--kill-after", "-g", "--group-add", "-e", "--env"],
            ),
            "start-stop-daemon" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-p",
                    "--pidfile",
                    "-c",
                    "--chuid",
                    "-u",
                    "--user",
                    "-n",
                    "--name",
                    "-d",
                    "--chdir",
                ],
            ),
            "systemd-run" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-p",
                    "--property",
                    "-u",
                    "--unit",
                    "-E",
                    "--setenv",
                    "--working-directory",
                    "--uid",
                    "--gid",
                    "-d",
                    "--description",
                ],
            ),
            "unbuffer" => skip_wrapper_options(&mut tokens, &[]),
            "watch" => skip_wrapper_options(&mut tokens, &["-n", "--interval", "-q", "--equexit"]),
            "xargs" => skip_wrapper_options(
                &mut tokens,
                &[
                    "-n",
                    "--max-args",
                    "-I",
                    "-i",
                    "--replace",
                    "-E",
                    "-e",
                    "--eof",
                    "-L",
                    "-l",
                    "--max-lines",
                    "-P",
                    "--max-procs",
                    "-s",
                    "--max-chars",
                    "-a",
                    "--arg-file",
                    "-d",
                    "--delimiter",
                    "--process-slot-var",
                    "-J",
                    "-R",
                    "-S",
                    "-O",
                ],
            ),
            "bwrap" | "bubblewrap" => {
                // Two-arg bind/setenv forms plus common one-value meta. Stop
                // on unknown dashes so a truncated peel does not mis-eat the
                // child program word (organism fails closed to Other).
                while let Some(option) = tokens.peek().cloned() {
                    if option == "--" {
                        tokens.next();
                        break;
                    }
                    if !option.starts_with('-') {
                        break;
                    }
                    let two_arg = matches!(
                        option.as_str(),
                        "--setenv"
                            | "--bind"
                            | "--bind-try"
                            | "--dev-bind"
                            | "--dev-bind-try"
                            | "--ro-bind"
                            | "--ro-bind-try"
                            | "--bind-fd"
                            | "--ro-bind-fd"
                            | "--file"
                            | "--bind-data"
                            | "--ro-bind-data"
                            | "--symlink"
                            | "--chmod"
                    );
                    let one_arg = matches!(
                        option.as_str(),
                        "--args"
                            | "--argv0"
                            | "--userns"
                            | "--userns2"
                            | "--pidns"
                            | "--uid"
                            | "--gid"
                            | "--hostname"
                            | "--chdir"
                            | "--unsetenv"
                            | "--lock-file"
                            | "--sync-fd"
                            | "--remount-ro"
                            | "--exec-label"
                            | "--file-label"
                            | "--proc"
                            | "--dev"
                            | "--tmpfs"
                            | "--mqueue"
                            | "--dir"
                            | "--seccomp"
                            | "--add-seccomp-fd"
                            | "--block-fd"
                            | "--userns-block-fd"
                            | "--info-fd"
                            | "--json-status-fd"
                            | "--cap-add"
                            | "--cap-drop"
                            | "--perms"
                            | "--size"
                    );
                    if !two_arg
                        && !one_arg
                        && option != "--unshare-user"
                        && option != "--unshare-pid"
                        && option != "--unshare-ipc"
                        && option != "--unshare-net"
                        && option != "--unshare-uts"
                        && option != "--unshare-cgroup"
                        && option != "--die-with-parent"
                        && option != "--as-pid-1"
                        && option != "--new-session"
                    {
                        // Unknown option: stop peeling; leave option+child.
                        break;
                    }
                    tokens.next();
                    if two_arg {
                        tokens.next();
                        tokens.next();
                    } else if one_arg {
                        tokens.next();
                    }
                }
            }
            _ => break,
        }
        program = tokens.next().unwrap_or_default();
    }

    let program = program.rsplit('/').next().unwrap_or(program.as_str());
    let args: Vec<String> = tokens.collect();
    match program {
        "git"
            if git_push_args(&args)
                .is_some_and(|push_args| !truncated && !git_push_is_dry_run(push_args)) =>
        {
            CommandKind::GitPush
        }
        "cargo"
            if args.first().is_some_and(|arg| {
                matches!(arg.as_str(), "build" | "check" | "clippy" | "test")
            }) || matches!(args.as_slice(), [nextest, run, ..] if nextest == "nextest" && run == "run") =>
        {
            CommandKind::BuildOrTest
        }
        "make" | "ninja" | "pytest" | "ctest" => CommandKind::BuildOrTest,
        "go" if args.first().is_some_and(|arg| arg == "test") => CommandKind::BuildOrTest,
        "cmake" if args.first().is_some_and(|arg| arg == "--build") => CommandKind::BuildOrTest,
        "npm" | "pnpm" | "yarn"
            if args.first().is_some_and(|arg| arg == "test")
                || args
                    .windows(2)
                    .any(|pair| pair[0] == "run" && pair[1] == "test") =>
        {
            CommandKind::BuildOrTest
        }
        _ => CommandKind::Other,
    }
}

/// Find a real `push` after a bounded, identity-preserving Git global-option
/// prefix. Options such as `-C`, `--git-dir`, and `--work-tree` deliberately
/// fail closed: the UI resolved repo identity from the terminal cwd, so a Git
/// invocation that redirects discovery must not close that repo's work loop.
fn git_push_args(args: &[String]) -> Option<&[String]> {
    let mut index = 0;
    while let Some(argument) = args.get(index) {
        match argument.as_str() {
            "push" => return Some(&args[index..]),
            "--no-pager"
            | "--paginate"
            | "-p"
            | "--no-replace-objects"
            | "--no-optional-locks"
            | "--no-lazy-fetch"
            | "--literal-pathspecs"
            | "--glob-pathspecs"
            | "--noglob-pathspecs"
            | "--icase-pathspecs" => index += 1,
            "-c" | "--config-env" => {
                args.get(index + 1)?;
                index += 2;
            }
            argument
                if (argument.starts_with("-c") && argument.len() > 2)
                    || argument.starts_with("--config-env=") =>
            {
                index += 1;
            }
            _ => return None,
        }
    }
    None
}

/// Consume one wrapper's bounded option prefix. Exact options in
/// `takes_value` consume the following token; attached/`--name=value` forms
/// are already self-contained. `--` ends wrapper option parsing.
fn skip_wrapper_options<I>(tokens: &mut std::iter::Peekable<I>, takes_value: &[&str])
where
    I: Iterator<Item = String>,
{
    while let Some(option) = tokens.peek() {
        if option == "--" {
            tokens.next();
            break;
        }
        if option == "-" || !option.starts_with('-') {
            break;
        }
        let consumes_value = takes_value.contains(&option.as_str());
        tokens.next();
        if consumes_value {
            tokens.next();
        }
    }
}

/// Skip one non-option positional meta operand when a following program word
/// remains (`gosu root cargo`, `chroot / cargo`, `taskset ff cargo`).
fn skip_wrapper_positional<I>(tokens: &mut std::iter::Peekable<I>)
where
    I: Iterator<Item = String> + Clone,
{
    if let Some(operand) = tokens.peek() {
        if !operand.starts_with('-') {
            let mut lookahead = tokens.clone();
            lookahead.next();
            if lookahead.peek().is_some() {
                tokens.next();
                if tokens.peek().is_some_and(|token| token == "--") {
                    tokens.next();
                }
            }
        }
    }
}

/// A dry-run proves reachability but does not close a recovered-work loop.
/// Parse only the bounded normalized argument prefix and stop recognizing
/// options after `--`, matching Git's usual option boundary.
fn git_push_is_dry_run(args: &[String]) -> bool {
    let mut options = true;
    for argument in args.iter().skip(1) {
        if argument == "--" {
            options = false;
            continue;
        }
        if !options {
            continue;
        }
        if argument == "--dry-run"
            || argument.starts_with("--dry-run=")
            || (argument.starts_with('-')
                && !argument.starts_with("--")
                && argument[1..].contains('n'))
        {
            return true;
        }
    }
    false
}

fn normalize_token(token: &str) -> Option<String> {
    let mut characters = token
        .trim_matches(|character| matches!(character, '\'' | '"'))
        .chars();
    let normalized = characters.by_ref().take(96).collect();
    characters.next().is_none().then_some(normalized)
}

fn is_environment_assignment(token: &str) -> bool {
    let Some((name, _)) = token.split_once('=') else {
        return false;
    };
    !name.is_empty()
        && name
            .bytes()
            .all(|byte| byte == b'_' || byte.is_ascii_alphanumeric())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn agent_state_pulse_preserves_idle_and_transport_precedence() {
        use crate::agent::AgentState;
        let proposal_id = serde_json::from_str::<crate::agent::ProposalId>("1").unwrap();
        let cases = [
            (AgentState::Ready, None),
            (AgentState::AwaitingModel, Some(AgentPulse::Working)),
            (
                AgentState::AwaitingObservation { proposal_id },
                Some(AgentPulse::Working),
            ),
            (
                AgentState::AwaitingApproval { proposal_id },
                Some(AgentPulse::AskingReview),
            ),
            (AgentState::Completed, Some(AgentPulse::Finished)),
            (AgentState::TurnLimitReached, Some(AgentPulse::Finished)),
            (AgentState::Cancelled, Some(AgentPulse::Gone)),
        ];
        for (state, expected) in cases {
            assert_eq!(agent_state_pulse(state, false), expected);
            assert_eq!(agent_state_pulse(state, true), Some(AgentPulse::Working));
        }
    }

    #[test]
    fn scriptlive_bare_dash_fails_closed_without_panicking() {
        for command in [
            "scriptlive -",
            "scriptlive - cargo test",
            "scriptlive - git push",
        ] {
            assert_eq!(classify_command(command), CommandKind::Other);
        }
    }

    #[test]
    fn truncated_tokens_cannot_hide_a_push_dry_run() {
        let command = format!("git push -{}n", "v".repeat(95));
        assert_eq!(classify_command(&command), CommandKind::Other);
        // A token at the supported boundary is still fully understood.
        let command = format!("git push -{}n", "v".repeat(94));
        assert_eq!(classify_command(&command), CommandKind::Other);
        let command = format!("git push origin {}", "x".repeat(97));
        assert_eq!(classify_command(&command), CommandKind::Other);
        let command = format!("git push origin {}", "x".repeat(96));
        assert_eq!(classify_command(&command), CommandKind::GitPush);
    }

    #[test]
    fn classifies_common_real_commands_without_treating_every_success_as_a_build() {
        assert_eq!(
            classify_command("cargo test --all"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("MODE=release env RUST_LOG=info cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("sudo -n /usr/bin/git push"),
            CommandKind::GitPush
        );
        for command in [
            "git --no-pager push",
            "git -c color.ui=false push",
            "git -ccolor.ui=false push",
        ] {
            assert_eq!(
                classify_command(command),
                CommandKind::GitPush,
                "{command} keeps cwd-derived repo identity"
            );
        }
        for command in [
            "git --no-pager push --dry-run",
            "git -C /tmp push",
            "git -C/tmp push",
            "git --git-dir=/tmp/repo.git push",
            "git --work-tree /tmp push",
        ] {
            assert_eq!(
                classify_command(command),
                CommandKind::Other,
                "{command} must not close cwd-derived recovered work"
            );
        }
        assert_eq!(
            classify_command("time -p cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nohup cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("time sudo -n cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nohup env CI_SMOKE=1 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("env -u OLD sudo -u root time -p cargo check"),
            CommandKind::BuildOrTest
        );
        for command in [
            "nice -n 5 cargo test",
            "timeout 30 cargo test",
            "timeout -k 5 30 cargo check",
            "stdbuf -oL cargo test",
            "eatmydata cargo test",
            "chronic cargo test",
            "annotate-output cargo test",
            "annotate-output +%H:%M:%S cargo check",
            "annotate-output -- cargo nextest run",
            "numactl --cpunodebind=0 cargo test",
            "numactl -C 0 -- cargo nextest run",
            "flock /tmp/lock cargo test",
            "flock -n /var/lock/x -- cargo check",
            "nice timeout 10 flock /tmp/l cargo test",
            "softlimit -m 1000000 cargo test",
            "chpst -u nobody cargo test",
            "setuidgid nobody cargo check",
            "s6-setuidgid nobody cargo test",
            "setlock /tmp/x.lock cargo test",
            "setlock -n /var/lock/x -- cargo check",
            "daemonize cargo test",
            "daemonize -p /run/x.pid cargo check",
            "daemonize --pidfile=/run/x.pid -- cargo nextest run",
            "daemonize -a -v cargo test",
            "daemonize --verbose -- cargo check",
            "daemonize -c /tmp -u nobody cargo nextest run",
            "s6-setuidgid -- nobody cargo test",
            "envdir /var/service/x/env cargo test",
            "rlwrap cargo test",
            "rlwrap -a cargo nextest run",
            "softlimit -c 0 chpst -u daemon envdir /env cargo test",
            "fakeroot cargo test",
            "fakeroot -- cargo check",
            "proot -r /tmp/root cargo test",
            "proot --bind /home:/home -w /tmp -- cargo nextest run",
            "proot -S /tmp/root cargo check",
            "firejail --noprofile cargo test",
            "firejail --private cargo check",
            "firejail --net=none --whitelist=/tmp cargo test",
            "fakeroot proot -r / firejail --noprofile cargo test",
            "cgexec -g cpu:group1 cargo test",
            "cgexec --sticky -g *:box cargo check",
            "schedtool -B -e cargo test",
            "schedtool -a 0x1 -n 5 -e cargo nextest run",
            "cgexec -g cpu:g schedtool -B -e cargo test",
            "torsocks cargo test",
            "torsocks -i cargo check",
            "torsocks --isolate -- cargo nextest run",
            "torsocks -a 127.0.0.1 -P 9050 cargo test",
            "proxychains cargo test",
            "proxychains4 -q cargo check",
            "proxychains3 -f /etc/proxychains.conf cargo nextest run",
            "torsocks proxychains4 -q cargo test",
            "dbus-run-session cargo test",
            "dbus-run-session -- cargo check",
            "dbus-run-session --config-file=/tmp/session.conf cargo nextest run",
            "runcon unconfined_t cargo test",
            "runcon -t unconfined_t cargo check",
            "runcon --type=unconfined_t -- cargo nextest run",
            "xvfb-run cargo test",
            "xvfb-run -a cargo check",
            "xvfb-run --auto-servernum -- cargo nextest run",
            "dbus-run-session runcon unconfined_t xvfb-run -a cargo test",
            "strace cargo test",
            "strace -f cargo check",
            "strace -e trace=file -- cargo nextest run",
            "scriptlive typescript cargo test",
            "scriptlive -t timing -I typescript -- cargo check",
            "strace -f scriptlive typescript cargo test",
            "systemd-cat cargo test",
            "systemd-cat -t unit cargo check",
            "systemd-cat --identifier=unit -- cargo nextest run",
            "gnome-session-inhibit cargo test",
            "gnome-session-inhibit --inhibit idle cargo check",
            "gnome-session-inhibit --app-id x --reason y --inhibit idle -- cargo nextest run",
            "systemd-inhibit cargo test",
            "systemd-inhibit --what=idle cargo check",
            "systemd-inhibit --what idle --who x -- cargo nextest run",
            "systemd-socket-activate cargo test",
            "systemd-socket-activate -l 2000 cargo check",
            "systemd-socket-activate --listen=127.0.0.1:9 --inetd -a -- cargo nextest run",
            "aa-exec cargo test",
            "aa-exec -p unconfined cargo check",
            "aa-exec --profile=unconfined -- cargo nextest run",
            "bwrap --ro-bind / / -- cargo test",
            "bubblewrap --ro-bind / / -- cargo check",
            "bwrap --dev /dev --uid 0 -- cargo nextest run",
            "systemd-cat -t x aa-exec -p unconfined cargo test",
            "systemd-inhibit --what=idle systemd-cat -t x cargo test",
            "doas cargo test",
            "doas -u root cargo check",
            "sudoedit -- cargo nextest run",
            "pkexec cargo test",
            "pkexec --user root -- cargo check",
            "run0 cargo test",
            "run0 -u root -- cargo nextest run",
            "runuser -u root -- cargo test",
            "gosu root cargo check",
            "su-exec nobody cargo test",
            "su -- cargo nextest run",
            "doas gosu root cargo test",
            "chroot / cargo test",
            "chroot --userspec=root:root / -- cargo check",
            "chrt 1 cargo test",
            "chrt -f 1 cargo check",
            "taskset ff cargo test",
            "taskset -c 0 -- cargo nextest run",
            "setarch x86_64 cargo test",
            "setsid cargo check",
            "setpriv --reuid 0 -- cargo test",
            "ionice -c3 cargo test",
            "ionice -c 2 -n 5 -- cargo check",
            "choom -n 1000 cargo test",
            "uclampset -m 512 cargo test",
            "uclampset -m 0 -M 1024 -- cargo check",
            "gamemoderun cargo test",
            "gamemoderun -- cargo nextest run",
            "prlimit --nofile=1024 cargo check",
            "prlimit -p 1 -- cargo nextest run",
            "capsh -- cargo test",
            "capsh --user=root -- cargo check",
            "dumb-init -- cargo test",
            "tini -- cargo check",
            "tini -e TERM -- cargo nextest run",
            "start-stop-daemon --start -- cargo test",
            "start-stop-daemon --start --chdir /tmp -- cargo check",
            "systemd-run cargo test",
            "systemd-run -u unit -- cargo check",
            "unbuffer cargo test",
            "watch --exec cargo test",
            "watch -n 1 --exec cargo check",
            "xargs cargo test",
            "xargs -n 1 -- cargo nextest run",
            "capsh -- unbuffer setsid cargo test",
            // Nested STAGE wrappers: depth loop must peel strace then timeout
            // before classifying the cargo child.
            "strace -f timeout --signal=TERM 10 cargo test",
            "timeout 5 strace -e trace=file cargo check",
            "strace timeout 5 systemd-cat -t unit cargo nextest run",
        ] {
            assert_eq!(
                classify_command(command),
                CommandKind::BuildOrTest,
                "{command} must see through scheduling/lock wrappers"
            );
        }
        for command in [
            "git push --dry-run",
            "git push origin main -n",
            "git push -vn origin main",
        ] {
            assert_eq!(
                classify_command(command),
                CommandKind::Other,
                "{command} must not claim to have published recovered work"
            );
        }
        assert_eq!(
            classify_command("git push -- --dry-run"),
            CommandKind::GitPush,
            "an option-shaped refspec after -- is not a dry-run flag"
        );
        let hidden_dry_run = format!(
            "git push {} --dry-run",
            (0..14)
                .map(|index| format!("--push-option=guard-{index}"))
                .collect::<Vec<_>>()
                .join(" ")
        );
        assert_eq!(
            classify_command(&hidden_dry_run),
            CommandKind::Other,
            "a bounded classifier must not publish when later options were truncated"
        );
        assert_eq!(classify_command("printf done"), CommandKind::Other);
    }

    /// Nested STAGE wrappers must consume depth slots so the child still
    /// classifies (`strace timeout rm` → Other, not opaque strace).
    #[test]
    fn classify_command_peels_nested_strace_timeout_wrappers() {
        assert_eq!(
            classify_command("strace timeout 5 rm -rf /"),
            CommandKind::Other,
            "nested strace+timeout must still classify the rm child"
        );
        assert_eq!(
            classify_command("timeout 5 strace rm -rf /tmp/x"),
            CommandKind::Other,
            "nested timeout+strace must still classify the rm child"
        );
        assert_eq!(
            classify_command("strace -f timeout --signal=TERM 10 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("strace timeout 5 systemd-cat -t unit cargo nextest run"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_nested_daemonize_setlock_wrappers() {
        assert_eq!(
            classify_command("daemonize setlock /tmp/x.lock cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("setlock -n /tmp/x.lock s6-setuidgid nobody cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("daemonize -p /run/x.pid setlock /tmp/x.lock rm -rf /"),
            CommandKind::Other
        );
        assert_eq!(
            classify_command("daemonize -a setlock -n /tmp/x.lock s6-setuidgid nobody cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("s6-setuidgid -- nobody cargo check"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_daemonize_setlock() {
        assert_eq!(
            classify_command("timeout 5 daemonize cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 setlock /tmp/x.lock cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 s6-setuidgid nobody cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 daemonize cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command(
                "nice -n 10 timeout 5 setlock -n /tmp/x.lock s6-setuidgid nobody cargo test"
            ),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("daemonize timeout 5 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 daemonize setlock /tmp/x.lock cargo test"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_gnome_session_inhibit() {
        assert_eq!(
            classify_command("timeout 5 gnome-session-inhibit cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 gnome-session-inhibit --inhibit idle cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command(
                "timeout 5 gnome-session-inhibit --app-id x --reason y --inhibit idle -- cargo nextest run"
            ),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("gnome-session-inhibit timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 gnome-session-inhibit cargo check"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_uclampset_and_gamemoderun() {
        assert_eq!(
            classify_command("timeout 5 uclampset -m 512 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 uclampset -m 0 -M 1024 -- cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("uclampset -m 100 timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 gamemoderun cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 gamemoderun -- cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("gamemoderun timeout 5 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 uclampset -m 512 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 gamemoderun cargo check"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_systemd_cat_and_inhibit() {
        assert_eq!(
            classify_command("timeout 5 systemd-inhibit cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 systemd-inhibit --what=idle cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command(
                "timeout 5 systemd-inhibit --who burner --why burn --mode block -- cargo nextest run"
            ),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("systemd-inhibit timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 systemd-cat -t unit cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 systemd-cat --priority warning cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("systemd-cat timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 systemd-inhibit cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 systemd-cat -t unit cargo test"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_openvt() {
        assert_eq!(
            classify_command("timeout 5 openvt cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 openvt -f cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 openvt -c 3 -- cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("openvt timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 openvt cargo check"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_aa_exec() {
        assert_eq!(
            classify_command("timeout 5 aa-exec cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 aa-exec -p unconfined cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 aa-exec --profile=unconfined -- cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("aa-exec timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 aa-exec cargo check"),
            CommandKind::BuildOrTest
        );
        // Namespace meta stays BuildOrTest beside profile peels (arity deepen
        // parity with openvt nest classify). Busybox applet carriers remain
        // stage_interpreter-only — classify does not peel busybox itself.
        assert_eq!(
            classify_command("aa-exec -n apparmorfs cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 aa-exec --namespace=apparmorfs -- cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 aa-exec -p unconfined -n apparmorfs cargo nextest run"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_systemd_socket_activate() {
        assert_eq!(
            classify_command("timeout 5 systemd-socket-activate cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 systemd-socket-activate -l 2000 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 systemd-socket-activate -a -- cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("systemd-socket-activate timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 systemd-socket-activate cargo check"),
            CommandKind::BuildOrTest
        );
        // setenv/fdname meta stays BuildOrTest beside listen peels (arity
        // deepen parity with openvt nest classify). Busybox applet carriers
        // remain stage_interpreter-only — classify does not peel busybox.
        assert_eq!(
            classify_command("systemd-socket-activate -E FOO=1 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 systemd-socket-activate --setenv=BAR=2 -- cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 systemd-socket-activate --fdname=conn cargo nextest run"),
            CommandKind::BuildOrTest
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_choom_prlimit_taskset() {
        assert_eq!(
            classify_command("timeout 5 taskset ff cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 taskset -c 0-3 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("taskset ff timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 choom -n 0 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 choom --adjust=0 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("choom -n 0 timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 prlimit --nofile=1024 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 prlimit --core=0 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("prlimit --nproc=1 timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 taskset ff cargo check"),
            CommandKind::BuildOrTest
        );
        // Busybox applet carriers remain stage_interpreter-only — classify
        // does not peel busybox itself (parity with setsid nest classify).
        assert_ne!(
            classify_command("busybox taskset ff cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_chrt_and_ionice() {
        assert_eq!(
            classify_command("timeout 5 chrt 1 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 chrt -r 1 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("chrt 1 timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 ionice -c 3 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 ionice -c 2 -n 5 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("ionice -c3 timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 chrt 1 cargo check"),
            CommandKind::BuildOrTest
        );
        // timeout+nice double nest around ionice — parity with setsid/chrt nests.
        assert_eq!(
            classify_command("timeout 5 nice -n 5 ionice -c 3 cargo check"),
            CommandKind::BuildOrTest
        );
        // Busybox applet carriers remain stage_interpreter-only — classify
        // does not peel busybox itself (parity with taskset nest classify).
        assert_ne!(
            classify_command("busybox ionice -c 3 cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
        assert_ne!(
            classify_command("busybox chrt 1 cargo test"),
            CommandKind::BuildOrTest,
            "busybox has no chrt applet; carrier stays stage_interpreter-only"
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_numactl_and_schedtool() {
        assert_eq!(
            classify_command("timeout 5 numactl --cpunodebind=0 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 numactl -C 0 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("numactl --localalloc timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 schedtool -B -e cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 schedtool -a 0x1 -n 5 -e cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("schedtool -N -e timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 numactl --cpunodebind=0 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 schedtool -B -e cargo check"),
            CommandKind::BuildOrTest
        );
        // Busybox has neither applet — classify does not peel busybox itself.
        assert_ne!(
            classify_command("busybox numactl --cpunodebind=0 cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
        assert_ne!(
            classify_command("busybox schedtool -B -e cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_softlimit_and_cgexec() {
        assert_eq!(
            classify_command("timeout 5 softlimit -m 1000000 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 softlimit -c 0 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("softlimit -n 64 timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 cgexec -g cpu:group1 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 cgexec --sticky -g *:box cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("cgexec -g cpu:g timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 softlimit -m 1000000 cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 cgexec -g cpu:g cargo check"),
            CommandKind::BuildOrTest
        );
        // Busybox has neither applet — classify does not peel busybox itself.
        assert_ne!(
            classify_command("busybox softlimit -m 1000000 cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
        assert_ne!(
            classify_command("busybox cgexec -g cpu:g cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_chpst_envdir_and_setuidgid() {
        assert_eq!(
            classify_command("timeout 5 chpst -u nobody cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 chpst -e /env cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("chpst -u daemon timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 envdir /var/service/x/env cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 envdir ./env cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("envdir /env timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 setuidgid nobody cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 setuidgid -- root cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("setuidgid daemon timeout 5 cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 chpst -u nobody cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 envdir /env cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 setuidgid nobody cargo check"),
            CommandKind::BuildOrTest
        );
        // Busybox has none of these applets — classify does not peel busybox.
        assert_ne!(
            classify_command("busybox chpst -u nobody cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
        assert_ne!(
            classify_command("busybox envdir /env cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
        assert_ne!(
            classify_command("busybox setuidgid nobody cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
    }

    #[test]
    fn classify_command_peels_timeout_nice_around_setsid() {
        assert_eq!(
            classify_command("timeout 5 setsid cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 setsid -f cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 setsid -fw -- cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("setsid timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 nice -n 5 setsid cargo check"),
            CommandKind::BuildOrTest
        );
        // -c/--ctty and -w/--wait stay BuildOrTest beside fork peels (arity
        // deepen parity with openvt/aa-exec nest classify). Busybox applet
        // carriers remain stage_interpreter-only — classify does not peel
        // busybox itself.
        assert_eq!(
            classify_command("setsid -c cargo test"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("timeout 5 setsid --ctty -- cargo check"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("nice -n 5 setsid -w cargo nextest run"),
            CommandKind::BuildOrTest
        );
        assert_eq!(
            classify_command("setsid --wait timeout 5 cargo test"),
            CommandKind::BuildOrTest
        );
        assert_ne!(
            classify_command("busybox setsid cargo test"),
            CommandKind::BuildOrTest,
            "busybox carrier stays stage_interpreter-only under classify"
        );
    }

    #[test]
    fn repeated_real_failures_escalate_then_success_celebrates() {
        let mut organism = NativeOrganism::default();
        organism.command_started(CommandKind::BuildOrTest);
        let first = organism.command_finished(CommandKind::BuildOrTest, Some(101), Some(900));
        organism.command_started(CommandKind::BuildOrTest);
        let second = organism.command_finished(CommandKind::BuildOrTest, Some(101), Some(800));
        organism.command_started(CommandKind::BuildOrTest);
        let third = organism.command_finished(CommandKind::BuildOrTest, Some(101), Some(700));
        organism.command_started(CommandKind::BuildOrTest);
        let success = organism.command_finished(CommandKind::BuildOrTest, Some(0), Some(600));

        assert_eq!(first.behavior, Behavior::InspectError);
        assert_eq!(second.behavior, Behavior::SitNearError);
        assert_eq!(third.behavior, Behavior::SitNearError);
        assert_eq!(success.behavior, Behavior::CelebrateBig);
        assert_eq!(success.speech, Some("终于。"));
    }

    #[test]
    fn unknown_exit_status_is_never_presented_as_success() {
        let mut organism = NativeOrganism::default();
        organism.command_started(CommandKind::BuildOrTest);
        let reaction = organism.command_finished(CommandKind::BuildOrTest, None, None);
        assert_eq!(reaction.behavior, Behavior::UnknownOutcome);
        assert_eq!(reaction.tone, Tone::Warning);
        assert_eq!(reaction.speech, None);
    }

    #[test]
    fn unrelated_success_does_not_erase_a_build_debugging_streak() {
        let mut organism = NativeOrganism::default();
        organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        organism.command_finished(CommandKind::Other, Some(0), None);
        let success = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(success.speech, Some("好了。"));
    }

    #[test]
    fn every_state_dimension_stays_finite_and_bounded() {
        let mut organism = NativeOrganism::default();
        for index in 0..10_000 {
            organism.command_started(CommandKind::BuildOrTest);
            let status = if index % 3 == 0 { 0 } else { 101 };
            organism.command_finished(CommandKind::BuildOrTest, Some(status), Some(index));
        }
        assert!(organism
            .state()
            .values()
            .into_iter()
            .all(|value| value.is_finite() && (0.0..=1.0).contains(&value)));
    }

    #[test]
    fn tick_drains_waking_energy_and_restores_it_at_rest() {
        let mut waking = LifeState::default();
        let mut resting = LifeState::default();
        for _ in 0..120 {
            waking.tick(1.0, false, false, CircadianPhase::Unlearned);
            resting.tick(1.0, false, true, CircadianPhase::Unlearned);
        }
        assert!(waking.energy < LifeState::default().energy);
        assert!(resting.energy > waking.energy);
        assert_eq!(resting.energy, 1.0);
    }

    #[test]
    fn learned_hours_shape_energy_without_jumping_at_boundaries() {
        let mut in_hours = LifeState {
            energy: 0.50,
            ..LifeState::default()
        };
        let mut off_hours = in_hours;
        in_hours.tick(1.0, false, false, CircadianPhase::InHours);
        off_hours.tick(1.0, false, false, CircadianPhase::OffHours);
        assert_eq!(in_hours.energy.to_bits(), 0.502_f32.to_bits());
        assert_eq!(off_hours.energy.to_bits(), 0.498_f32.to_bits());

        for _ in 0..500 {
            in_hours.tick(1.0, false, false, CircadianPhase::InHours);
            off_hours.tick(1.0, false, false, CircadianPhase::OffHours);
        }
        assert_eq!(in_hours.energy, 0.65);
        assert_eq!(off_hours.energy, 0.35);

        let mut resting_in = LifeState {
            energy: 0.50,
            ..LifeState::default()
        };
        let mut resting_off = resting_in;
        resting_in.tick(1.0, false, true, CircadianPhase::InHours);
        resting_off.tick(1.0, false, true, CircadianPhase::OffHours);
        assert_eq!(resting_in.energy, resting_off.energy);
        assert!(resting_in.energy > 0.50);
    }

    #[test]
    fn unlearned_circadian_phase_preserves_the_original_energy_drift() {
        let mut state = LifeState::default();
        let before = state.energy;
        state.tick(1.0, false, false, CircadianPhase::Unlearned);
        assert_eq!(state.energy.to_bits(), (before - 0.002).to_bits());
    }

    #[test]
    fn exhaustion_forces_micro_rest_so_energy_never_pins_at_zero() {
        let mut state = LifeState::default();
        for _ in 0..3_600 {
            state.tick(1.0, false, false, CircadianPhase::Unlearned);
        }
        assert!(state.energy > 0.10);
        assert!(state.energy < 0.30);
    }

    #[test]
    fn a_single_time_slice_simulates_at_most_one_second() {
        let mut long_slice = LifeState::default();
        let mut capped = LifeState::default();
        long_slice.tick(3600.0, true, false, CircadianPhase::Unlearned);
        capped.tick(1.0, true, false, CircadianPhase::Unlearned);
        assert_eq!(long_slice.values(), capped.values());
    }

    #[test]
    fn tick_moves_boredom_and_social_need_with_user_activity() {
        let mut engaged = LifeState::default();
        let mut ignored = LifeState::default();
        for _ in 0..60 {
            engaged.tick(1.0, true, false, CircadianPhase::Unlearned);
            ignored.tick(1.0, false, false, CircadianPhase::Unlearned);
        }
        assert!(engaged.boredom < ignored.boredom);
        assert!(engaged.social_need < ignored.social_need);
        assert!(engaged.curiosity > ignored.curiosity);
    }

    #[test]
    fn tick_eases_mood_toward_its_homeostatic_target() {
        let mut stressed = LifeState {
            stress: 1.0,
            mood: 0.9,
            ..LifeState::default()
        };
        let before = stressed.mood;
        for _ in 0..30 {
            stressed.tick(1.0, false, false, CircadianPhase::Unlearned);
        }
        assert!(stressed.mood < before);
    }

    #[test]
    fn tick_survives_hostile_time_slices_and_stays_bounded() {
        let mut state = LifeState::default();
        for (index, dt) in [f32::NAN, f32::INFINITY, -5.0, 3600.0, 0.1]
            .into_iter()
            .cycle()
            .take(10_000)
            .enumerate()
        {
            state.tick(
                dt,
                index % 2 == 0,
                index % 3 == 0,
                CircadianPhase::Unlearned,
            );
        }
        assert!(state
            .values()
            .into_iter()
            .all(|value| value.is_finite() && (0.0..=1.0).contains(&value)));
    }

    #[test]
    fn clean_passes_habituate_but_recoveries_celebrate_at_full_strength() {
        let mut organism = NativeOrganism::default();
        let first = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(first.speech, Some("过了。"));
        assert_eq!(first.tone, Tone::Success);

        organism.restore_repo_context(0, false, 4, 0);
        let fifth = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(fifth.speech, None);
        assert_eq!(fifth.tone, Tone::Success);

        organism.restore_repo_context(0, false, 9, 0);
        let tenth = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(tenth.behavior, Behavior::Celebrate);
        assert_eq!(tenth.tone, Tone::Quiet);
        assert_eq!(tenth.speech, None);
        assert!(tenth.description.contains("pass 10 today"));

        // A recovery after real failures is never dampened by today's count.
        organism.restore_repo_context(3, false, 9, 3);
        let recovery = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(recovery.behavior, Behavior::CelebrateBig);
        assert_eq!(recovery.speech, Some("终于。"));
    }

    #[test]
    fn state_increments_shrink_as_the_day_of_passes_grows() {
        let mut fresh = NativeOrganism::default();
        let fresh_before = fresh.state().mood;
        fresh.command_finished(CommandKind::BuildOrTest, Some(0), None);
        let fresh_delta = fresh.state().mood - fresh_before;

        let mut jaded = NativeOrganism::default();
        jaded.restore_repo_context(0, false, 8, 0);
        let jaded_before = jaded.state().mood;
        jaded.command_finished(CommandKind::BuildOrTest, Some(0), None);
        let jaded_delta = jaded.state().mood - jaded_before;
        assert!(jaded_delta < fresh_delta);
    }

    #[test]
    fn first_failure_after_a_clean_run_is_sensitized() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_context(0, false, 5, 0);
        let stress_before = organism.state().stress;
        let reaction = organism.command_finished(CommandKind::BuildOrTest, Some(101), None);
        assert!(reaction
            .description
            .contains("first crack after 5 clean run(s)"));
        assert_eq!(reaction.speech, Some("这里。"));
        assert!(organism.state().stress - stress_before > 0.15);

        let ordinary = organism.command_finished(CommandKind::BuildOrTest, Some(101), None);
        assert!(!ordinary.description.contains("first crack"));
    }

    #[test]
    fn any_command_streak_wearies_and_any_success_clears_it() {
        let mut organism = NativeOrganism::default();
        let first = organism.command_finished(CommandKind::Other, Some(255), None);
        assert_eq!(first.behavior, Behavior::InspectError);
        assert_eq!(first.speech, Some("这里。"));
        let second = organism.command_finished(CommandKind::Other, Some(255), None);
        assert_eq!(second.behavior, Behavior::InspectError);
        assert_eq!(second.speech, None);
        let third = organism.command_finished(CommandKind::Other, Some(255), None);
        assert_eq!(third.behavior, Behavior::SitNearError);
        assert!(third.description.contains("3 rough commands in a row"));
        assert_eq!(third.speech, None);

        organism.command_finished(CommandKind::Other, Some(0), None);
        let after_reset = organism.command_finished(CommandKind::Other, Some(255), None);
        assert_eq!(after_reset.behavior, Behavior::InspectError);
        assert_eq!(after_reset.speech, Some("这里。"));
    }

    #[test]
    fn unknown_exit_neither_extends_nor_clears_the_rough_streak() {
        let mut organism = NativeOrganism::default();
        organism.command_finished(CommandKind::Other, Some(255), None);
        organism.command_finished(CommandKind::Other, Some(255), None);
        organism.command_finished(CommandKind::Other, None, None);
        let third = organism.command_finished(CommandKind::Other, Some(255), None);
        assert_eq!(third.behavior, Behavior::SitNearError);
        assert!(third.description.contains("3 rough commands in a row"));
    }

    #[test]
    fn context_reset_and_day_rollover_restart_todays_rhythm() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_context(0, false, 9, 2);
        organism.restore_repo_context(0, false, 0, 0);
        let pass = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(pass.speech, Some("过了。"));

        let mut overnight = NativeOrganism::default();
        overnight.restore_repo_context(0, false, 9, 2);
        overnight.roll_over_day();
        let fresh = overnight.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(fresh.speech, Some("过了。"));
        assert_eq!(fresh.tone, Tone::Success);
    }

    #[test]
    fn recovered_work_is_guarded_until_successful_push_or_context_boundary() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_context(2, false, 0, 2);
        organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert!(organism.guarding_recovery());
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardRecovery);

        // Rechecking green work and unrelated commands do not erase the open
        // loop. A failed push does not close it either.
        organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        organism.command_finished(CommandKind::Other, Some(0), None);
        organism.command_finished(CommandKind::GitPush, Some(1), None);
        assert!(organism.guarding_recovery());

        let pushed = organism.command_finished(CommandKind::GitPush, Some(0), None);
        assert_eq!(pushed.speech, Some("收好了。"));
        assert!(!organism.guarding_recovery());
        assert_eq!(organism.idle_reaction().behavior, Behavior::Idle);

        organism.restore_repo_context(0, true, 1, 1);
        organism.roll_over_day();
        assert!(!organism.guarding_recovery());
        organism.restore_repo_context(0, true, 1, 1);
        organism.restore_repo_context(0, false, 0, 0);
        assert!(!organism.guarding_recovery());
    }

    #[test]
    fn unresolved_builds_progress_from_failure_to_stuck_then_recovery() {
        let mut organism = NativeOrganism::default();

        for expected in [Behavior::GuardFailure, Behavior::GuardFailure] {
            organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
            assert_eq!(organism.idle_reaction().behavior, expected);
        }
        organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        let stuck = organism.idle_reaction();
        assert_eq!(stuck.behavior, Behavior::GuardStuck);
        assert_eq!(stuck.tone, Tone::Quiet);

        // Unknown outcomes, unrelated commands, and a failed push cannot
        // erase a repo/day debugging loop they did not resolve.
        organism.command_finished(CommandKind::BuildOrTest, None, None);
        organism.command_finished(CommandKind::Other, Some(0), None);
        organism.command_finished(CommandKind::GitPush, Some(1), None);
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardStuck);

        organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardRecovery);

        // A relapse starts a fresh open streak; the day's flip count does not
        // falsely make one unresolved failure look like the fourth failure.
        organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardFailure);
    }

    #[test]
    fn authoritative_work_state_normalizes_and_can_downgrade_a_stale_pane() {
        assert_eq!(
            RepoWorkState::new(1, true, u32::MAX),
            RepoWorkState {
                open_failures: 1,
                recovered_pending_push: false,
                failure_success_flips: u32::MAX,
            }
        );

        let mut organism = NativeOrganism::default();
        organism.restore_repo_context(3, false, 0, 3);
        assert_eq!(organism.repo_vigil(), RepoVigil::Stuck);
        assert!(organism.sync_repo_work_state(RepoWorkState::new(1, false, 0)));
        assert_eq!(organism.repo_vigil(), RepoVigil::Failure);
        assert!(!organism.sync_repo_work_state(RepoWorkState::new(1, false, 0)));
    }

    #[test]
    fn the_third_same_day_flip_makes_pending_recovery_cautious_until_push() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_work_context(RepoWorkState::new(1, false, 2), 2, 3);

        organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(organism.repo_vigil(), RepoVigil::CautiousRecovery);
        let guard = organism.idle_reaction();
        assert_eq!(guard.behavior, Behavior::GuardCautious);
        assert!(!guard.description.contains("flaky"));

        organism.command_finished(CommandKind::GitPush, Some(0), None);
        assert_eq!(organism.repo_vigil(), RepoVigil::None);
    }

    #[test]
    fn a_successful_push_dry_run_never_closes_recovered_work() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_context(0, true, 1, 1);
        let kind = classify_command("git push --dry-run origin main");
        organism.command_started(kind);
        let reaction = organism.command_finished(kind, Some(0), None);
        assert_eq!(reaction.behavior, Behavior::Idle);
        assert_eq!(reaction.speech, None);
        assert!(organism.guarding_recovery());
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardRecovery);
    }

    #[test]
    fn repo_arrival_shapes_the_next_command_start_only() {
        assert_eq!(RepoArrival::from_familiarity(0), RepoArrival::Unfamiliar);
        assert_eq!(RepoArrival::from_familiarity(3), RepoArrival::Known);
        assert_eq!(RepoArrival::from_familiarity(7), RepoArrival::Home);

        let mut organism = NativeOrganism::default();
        organism.note_repo_arrival(RepoArrival::Unfamiliar);
        let confidence_before = organism.state().confidence;
        let shy = organism.command_started(CommandKind::BuildOrTest);
        assert_eq!(shy.tone, Tone::Quiet);
        assert!(shy.description.contains("first day in this repo"));
        assert_eq!(shy.speech, None);
        assert!(organism.state().confidence < confidence_before);

        let plain = organism.command_started(CommandKind::BuildOrTest);
        assert_eq!(plain.tone, Tone::Active);
        assert!(!plain.description.contains("first day"));

        organism.note_repo_arrival(RepoArrival::Home);
        let home = organism.command_started(CommandKind::BuildOrTest);
        assert_eq!(home.speech, Some("回来了。"));
    }

    #[test]
    fn discarded_command_cannot_lend_its_assist_to_the_next_success() {
        let mut organism = NativeOrganism::default();
        organism.note_assisted_command();
        organism.set_agent_command(true);
        organism.command_started(CommandKind::BuildOrTest);
        let before = organism.state();

        organism.discard_active_command();
        assert!(organism.active_kind.is_none());
        assert!(!organism.assisted);
        assert!(!organism.agent_driven);
        assert_eq!(format!("{:?}", organism.state()), format!("{before:?}"));

        let mut control = NativeOrganism::from_persisted_state(before);
        organism.command_started(CommandKind::Other);
        control.command_started(CommandKind::Other);
        let actual = organism.command_finished(CommandKind::Other, Some(0), None);
        let expected = control.command_finished(CommandKind::Other, Some(0), None);
        assert_eq!(actual.behavior, Behavior::Idle);
        assert_eq!(actual.description, "command finished cleanly");
        assert_eq!(actual.behavior, expected.behavior);
        assert_eq!(actual.tone, expected.tone);
        assert_eq!(actual.speech, expected.speech);
        assert_eq!(
            format!("{:?}", organism.state()),
            format!("{:?}", control.state())
        );
    }

    #[test]
    fn discarding_a_command_is_idempotent_and_preserves_completed_context() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_work_context(RepoWorkState::new(2, false, 3), 7, 8);
        organism.rough_streak = 4;
        organism.note_repo_arrival(RepoArrival::Home);
        organism.note_assisted_command();
        organism.set_agent_command(true);
        // Agent starts intentionally leave the human's repo arrival pending.
        organism.command_started(CommandKind::BuildOrTest);
        let before = organism.state();
        let work = organism.repo_work_state();

        for _ in 0..2 {
            organism.discard_active_command();
            assert!(organism.active_kind.is_none());
            assert!(!organism.assisted);
            assert!(!organism.agent_driven);
            assert_eq!(organism.repo_work_state(), work);
            assert_eq!(organism.successes_today, 7);
            assert_eq!(organism.failures_today, 8);
            assert_eq!(organism.rough_streak, 4);
            assert_eq!(organism.pending_arrival, Some(RepoArrival::Home));
            assert_eq!(format!("{:?}", organism.state()), format!("{before:?}"));
        }
    }

    #[test]
    fn accepted_correction_gets_a_small_nod_on_the_next_success_only() {
        let mut organism = NativeOrganism::default();
        organism.note_assisted_command();
        let success = organism.command_finished(CommandKind::Other, Some(0), None);
        assert_eq!(success.behavior, Behavior::Celebrate);
        assert_eq!(success.tone, Tone::Success);
        assert!(success.description.contains("corrected command worked"));
        assert_eq!(success.speech, None);

        let ordinary = organism.command_finished(CommandKind::Other, Some(0), None);
        assert_eq!(ordinary.behavior, Behavior::Idle);

        // A failed assisted command earns no celebration, and the assist does
        // not carry over to the next command.
        organism.note_assisted_command();
        let failed = organism.command_finished(CommandKind::Other, Some(1), None);
        assert_eq!(failed.behavior, Behavior::InspectError);
        let following = organism.command_finished(CommandKind::Other, Some(0), None);
        assert_eq!(following.behavior, Behavior::Idle);
    }

    #[test]
    fn sticky_glyphs_stay_five_ascii_characters_and_animate_slowly() {
        for behavior in [
            Behavior::Idle,
            Behavior::WatchCommand,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::RestAfterPush,
            Behavior::UnknownOutcome,
            Behavior::GlanceAside,
            Behavior::Sleep,
            Behavior::Explore,
            Behavior::Approach,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
        ] {
            for frame in [0, 4, 5, 54, 55, 59, u64::MAX] {
                for drowsy in [false, true] {
                    let language = BodyLanguage {
                        drowsy,
                        ..Default::default()
                    };
                    let glyph = sticky_glyph(behavior, language, frame);
                    assert_eq!(glyph.chars().count(), 5);
                    assert!(glyph.is_ascii());
                }
            }
        }
        // Watching alternates every five frames; idle almost never moves.
        let calm = BodyLanguage::default();
        assert_ne!(
            sticky_glyph(Behavior::WatchCommand, calm, 0),
            sticky_glyph(Behavior::WatchCommand, calm, 5)
        );
        assert_eq!(
            sticky_glyph(Behavior::Idle, calm, 0),
            sticky_glyph(Behavior::Idle, calm, 5)
        );
        assert_ne!(
            sticky_glyph(Behavior::Idle, calm, 55),
            sticky_glyph(Behavior::Idle, calm, 0)
        );
    }

    fn bounding_box_of(sprite: &str) -> (usize, usize) {
        (
            sprite.lines().count(),
            sprite
                .lines()
                .map(|line| line.chars().count())
                .max()
                .unwrap_or(0),
        )
    }

    #[test]
    fn every_sprite_frame_keeps_its_behaviors_bounding_box_stable() {
        let languages = [
            BodyLanguage::default(),
            BodyLanguage {
                drowsy: true,
                ..Default::default()
            },
            BodyLanguage {
                tense: true,
                ..Default::default()
            },
            BodyLanguage {
                listless: true,
                ..Default::default()
            },
            BodyLanguage {
                drowsy: true,
                tense: true,
                listless: true,
            },
        ];
        for behavior in [
            Behavior::Idle,
            Behavior::WatchCommand,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::RestAfterPush,
            Behavior::UnknownOutcome,
            Behavior::GlanceAside,
            Behavior::Sleep,
            Behavior::Explore,
            Behavior::Approach,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
        ] {
            let reference = bounding_box_of(behavior.sprite());
            for language in languages {
                for walking in [false, true] {
                    for frame in 0..130 {
                        let frame_box =
                            bounding_box_of(sprite_frame(behavior, language, walking, frame));
                        assert_eq!(
                            frame_box, reference,
                            "{behavior:?} {language:?} walking={walking} frame={frame}"
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn adult_steady_render_context_is_byte_for_byte_backwards_compatible() {
        let languages = [
            BodyLanguage::default(),
            BodyLanguage {
                drowsy: true,
                tense: true,
                listless: true,
            },
        ];
        for behavior in [
            Behavior::Idle,
            Behavior::WatchCommand,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::RestAfterPush,
            Behavior::UnknownOutcome,
            Behavior::GlanceAside,
            Behavior::Sleep,
            Behavior::Explore,
            Behavior::Approach,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
        ] {
            for language in languages {
                for walking in [false, true] {
                    let context = RenderContext::new(behavior, language, walking);
                    for frame in 0..130 {
                        assert_eq!(
                            sprite_frame_with_context(context, frame).as_ref(),
                            sprite_frame(behavior, language, walking, frame)
                        );
                        assert_eq!(
                            sticky_glyph_with_context(context, frame).as_ref(),
                            sticky_glyph(behavior, language, frame)
                        );
                    }
                }
            }
        }
    }

    #[test]
    fn growth_is_visible_width_preserving_and_keeps_behavior_marks() {
        let adult = RenderContext::new(Behavior::WatchCommand, BodyLanguage::default(), false);
        let juvenile = adult.with_growth_stage(VisualGrowthStage::Juvenile);
        let seasoned = adult.with_growth_stage(VisualGrowthStage::Seasoned);
        let adult_sprite = sprite_frame_with_context(adult, 0);
        let juvenile_sprite = sprite_frame_with_context(juvenile, 0);
        let seasoned_sprite = sprite_frame_with_context(seasoned, 0);

        assert_ne!(juvenile_sprite, adult_sprite);
        assert_ne!(seasoned_sprite, adult_sprite);
        assert!(juvenile_sprite.contains("(\\_/)") && juvenile_sprite.contains("O.O"));
        assert!(seasoned_sprite.contains("/\\_/|") && seasoned_sprite.contains("-.o"));
        assert_eq!(
            bounding_box_of(&juvenile_sprite),
            bounding_box_of(&adult_sprite)
        );
        assert_eq!(
            bounding_box_of(&seasoned_sprite),
            bounding_box_of(&adult_sprite)
        );

        let juvenile_glyph = sticky_glyph_with_context(juvenile, 0);
        let adult_glyph = sticky_glyph_with_context(adult, 0);
        let seasoned_glyph = sticky_glyph_with_context(seasoned, 0);
        assert_eq!(juvenile_glyph.chars().count(), 5);
        assert_eq!(seasoned_glyph.chars().count(), 5);
        assert_ne!(juvenile_glyph, adult_glyph);
        assert_ne!(seasoned_glyph, adult_glyph);

        // Maturity never erases an event marker in the compact form.
        for stage in [
            VisualGrowthStage::Juvenile,
            VisualGrowthStage::Adult,
            VisualGrowthStage::Seasoned,
        ] {
            let glyph = sticky_glyph_with_context(
                RenderContext::new(Behavior::GuardFailure, BodyLanguage::default(), false)
                    .with_growth_stage(stage),
                0,
            );
            assert_eq!(glyph.as_bytes()[2], b'!');
        }

        // Seasoned motion holds the first tail pose longer; juvenile motion
        // reaches the alternate pose sooner. Adult remains the old cadence.
        let juvenile_agent =
            RenderContext::new(Behavior::WatchAgent, BodyLanguage::default(), false)
                .with_growth_stage(VisualGrowthStage::Juvenile);
        assert_ne!(
            sprite_frame_with_context(juvenile_agent, 0),
            sprite_frame_with_context(juvenile_agent, 4)
        );
        assert_ne!(
            sprite_frame_with_context(adult, 0),
            sprite_frame_with_context(adult, 5)
        );
        assert_eq!(
            sprite_frame_with_context(seasoned, 0),
            sprite_frame_with_context(seasoned, 5)
        );
    }

    #[test]
    fn every_growth_layer_preserves_every_pose_family_envelope() {
        let behaviors = [
            Behavior::Idle,
            Behavior::WatchCommand,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::RestAfterPush,
            Behavior::UnknownOutcome,
            Behavior::GlanceAside,
            Behavior::Sleep,
            Behavior::Explore,
            Behavior::Approach,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
        ];
        let languages = [
            BodyLanguage::default(),
            BodyLanguage {
                drowsy: true,
                tense: true,
                listless: true,
            },
        ];
        for behavior in behaviors {
            for language in languages {
                for walking in [false, true] {
                    for rhythm in [
                        WatchRhythm::Steady,
                        WatchRhythm::Busy,
                        WatchRhythm::Waiting,
                        WatchRhythm::Resumed,
                    ] {
                        for frame in 0..130 {
                            let adult = RenderContext::new(behavior, language, walking)
                                .with_watch_rhythm(rhythm);
                            let reference =
                                bounding_box_of(&sprite_frame_with_context(adult, frame));
                            for stage in [
                                VisualGrowthStage::Juvenile,
                                VisualGrowthStage::Adult,
                                VisualGrowthStage::Seasoned,
                            ] {
                                let context = adult.with_growth_stage(stage);
                                assert_eq!(
                                    bounding_box_of(&sprite_frame_with_context(context, frame)),
                                    reference,
                                    "{behavior:?} {language:?} walking={walking} {rhythm:?} {stage:?} frame={frame}"
                                );
                                assert_eq!(
                                    sticky_glyph_with_context(context, frame).chars().count(),
                                    5
                                );
                            }
                        }
                    }
                }
            }
        }
    }

    #[test]
    fn watch_rhythms_are_content_free_distinct_and_box_stable() {
        for behavior in [
            Behavior::WatchCommand,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
        ] {
            let reference = bounding_box_of(behavior.sprite());
            let mut sprites = Vec::new();
            let mut glyphs = Vec::new();
            for rhythm in [
                WatchRhythm::Steady,
                WatchRhythm::Busy,
                WatchRhythm::Waiting,
                WatchRhythm::Resumed,
            ] {
                let context = RenderContext::new(behavior, BodyLanguage::default(), false)
                    .with_watch_rhythm(rhythm);
                let sprite = sprite_frame_with_context(context, 0);
                assert_eq!(
                    bounding_box_of(&sprite),
                    reference,
                    "{behavior:?} {rhythm:?}"
                );
                let glyph = sticky_glyph_with_context(context, 0);
                assert_eq!(glyph.chars().count(), 5);
                assert!(glyph.is_ascii());
                sprites.push(sprite.into_owned());
                glyphs.push(glyph.into_owned());
            }
            sprites.sort();
            sprites.dedup();
            glyphs.sort();
            glyphs.dedup();
            assert_eq!(sprites.len(), 4, "{behavior:?} live rhythms collapsed");
            assert_eq!(glyphs.len(), 4, "{behavior:?} sticky rhythms collapsed");
        }

        // A rhythm is ignored outside a watching behavior.
        let idle = RenderContext::new(Behavior::Idle, BodyLanguage::default(), false);
        assert_eq!(
            sprite_frame_with_context(idle, 20),
            sprite_frame_with_context(idle.with_watch_rhythm(WatchRhythm::Busy), 20)
        );
    }

    #[test]
    fn semantic_transitions_are_bounded_one_shot_arcs() {
        let transitions = [
            VisualTransition::InspectErrorToGuardFailure,
            VisualTransition::InspectErrorToGuardRecovery,
            VisualTransition::InspectErrorToGuardCautious,
            VisualTransition::InspectErrorToGuardStuck,
            VisualTransition::SitNearErrorToGuardFailure,
            VisualTransition::SitNearErrorToGuardStuck,
            VisualTransition::SitNearErrorToGuardRecovery,
            VisualTransition::SitNearErrorToGuardCautious,
            VisualTransition::GuardFailureToGuardStuck,
            VisualTransition::GuardFailureToGuardRecovery,
            VisualTransition::GuardFailureToGuardCautious,
            VisualTransition::GuardStuckToGuardFailure,
            VisualTransition::GuardStuckToGuardRecovery,
            VisualTransition::GuardStuckToGuardCautious,
            VisualTransition::WatchSettledToCelebrate,
            VisualTransition::WatchSettledToCelebrateBig,
            VisualTransition::WatchSettledToInspectError,
            VisualTransition::WatchSettledToSitNearError,
            VisualTransition::WatchSettledToRestAfterPush,
            VisualTransition::WatchCommandToCelebrate,
            VisualTransition::WatchCommandToCelebrateBig,
            VisualTransition::WatchCommandToInspectError,
            VisualTransition::WatchCommandToSitNearError,
            VisualTransition::WatchCommandToRestAfterPush,
            VisualTransition::WatchAgentToCelebrate,
            VisualTransition::WatchAgentToInspectError,
            VisualTransition::WatchAgentToSitNearError,
            VisualTransition::WatchAgentToRestAfterPush,
            VisualTransition::CelebrateToGuardRecovery,
            VisualTransition::CelebrateToGuardCautious,
            VisualTransition::CelebrateToGuardFailure,
            VisualTransition::CelebrateToGuardStuck,
            VisualTransition::CelebrateBigToGuardRecovery,
            VisualTransition::CelebrateBigToGuardCautious,
            VisualTransition::CelebrateBigToGuardFailure,
            VisualTransition::CelebrateBigToGuardStuck,
            VisualTransition::GuardRecoveryToGuardFailure,
            VisualTransition::GuardRecoveryToGuardStuck,
            VisualTransition::GuardRecoveryToGuardCautious,
            VisualTransition::GuardCautiousToGuardFailure,
            VisualTransition::GuardCautiousToGuardStuck,
            VisualTransition::GuardCautiousToGuardRecovery,
            VisualTransition::GuardRecoveryToRestAfterPush,
            VisualTransition::GuardCautiousToRestAfterPush,
            VisualTransition::GuardFailureToRestAfterPush,
            VisualTransition::GuardStuckToRestAfterPush,
            VisualTransition::InspectErrorToCelebrate,
            VisualTransition::InspectErrorToCelebrateBig,
            VisualTransition::InspectErrorToSitNearError,
            VisualTransition::InspectErrorToUnknownOutcome,
            VisualTransition::SitNearErrorToCelebrate,
            VisualTransition::SitNearErrorToCelebrateBig,
            VisualTransition::SitNearErrorToUnknownOutcome,
            VisualTransition::CelebrateToRestAfterPush,
            VisualTransition::CelebrateBigToRestAfterPush,
            VisualTransition::CelebrateToIdle,
            VisualTransition::CelebrateBigToIdle,
            VisualTransition::RestAfterPushToIdle,
            VisualTransition::UnknownOutcomeToIdle,
            VisualTransition::UnknownOutcomeToInspectError,
            VisualTransition::UnknownOutcomeToCelebrate,
            VisualTransition::UnknownOutcomeToCelebrateBig,
            VisualTransition::UnknownOutcomeToSitNearError,
            VisualTransition::UnknownOutcomeToGuardFailure,
            VisualTransition::UnknownOutcomeToGuardStuck,
            VisualTransition::UnknownOutcomeToGuardRecovery,
            VisualTransition::UnknownOutcomeToGuardCautious,
            VisualTransition::InspectErrorToIdle,
            VisualTransition::SitNearErrorToIdle,
            VisualTransition::GuardFailureToIdle,
            VisualTransition::GuardStuckToIdle,
            VisualTransition::GuardRecoveryToIdle,
            VisualTransition::GuardCautiousToIdle,
            VisualTransition::InspectErrorToRestAfterPush,
            VisualTransition::SitNearErrorToRestAfterPush,
            VisualTransition::UnknownOutcomeToRestAfterPush,
            VisualTransition::WatchCommandToIdle,
            VisualTransition::WatchAgentToIdle,
            VisualTransition::WatchSettledToIdle,
            VisualTransition::CelebrateToInspectError,
            VisualTransition::CelebrateToSitNearError,
            VisualTransition::CelebrateToUnknownOutcome,
            VisualTransition::CelebrateBigToInspectError,
            VisualTransition::CelebrateBigToSitNearError,
            VisualTransition::CelebrateBigToUnknownOutcome,
            VisualTransition::RestAfterPushToInspectError,
            VisualTransition::RestAfterPushToSitNearError,
            VisualTransition::RestAfterPushToUnknownOutcome,
            VisualTransition::RestAfterPushToCelebrate,
            VisualTransition::RestAfterPushToCelebrateBig,
            VisualTransition::GuardRecoveryToInspectError,
            VisualTransition::GuardRecoveryToSitNearError,
            VisualTransition::GuardRecoveryToUnknownOutcome,
        ];
        for transition in transitions {
            assert_eq!(
                VisualTransition::between(transition.source(), transition.target()),
                Some(transition)
            );
            assert_eq!(transition.frame_count(), 4);
            let reference = bounding_box_of(transition.sprite_frame(0));
            for frame in 0..transition.frame_count() {
                assert_eq!(
                    bounding_box_of(transition.sprite_frame(frame)),
                    reference,
                    "{transition:?} frame {frame}"
                );
            }
            assert_eq!(
                transition.sprite_frame(u64::MAX),
                transition.sprite_frame(transition.frame_count() - 1)
            );

            for stage in [
                VisualGrowthStage::Juvenile,
                VisualGrowthStage::Adult,
                VisualGrowthStage::Seasoned,
            ] {
                let context =
                    RenderContext::new(transition.target(), BodyLanguage::default(), false)
                        .with_growth_stage(stage)
                        .with_transition(Some(transition));
                for frame in 0..transition.frame_count() {
                    assert_eq!(
                        bounding_box_of(&sprite_frame_with_context(context, frame)),
                        reference,
                        "{transition:?} {stage:?} frame {frame}"
                    );
                }
            }
        }
        assert_eq!(
            VisualTransition::between(Behavior::Idle, Behavior::Celebrate),
            None
        );
    }

    #[test]
    fn second_open_failure_settle_has_a_full_motion_bridge() {
        // One failure inspects then settles to GuardFailure (already bridged).
        // Two failures sit nearby then settle to the same GuardFailure tier —
        // that middle settle must not snap while its neighbors animate.
        let mut organism = NativeOrganism::default();
        organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        let first = organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(first.behavior, Behavior::SitNearError);
        let idle = organism.idle_reaction();
        assert_eq!(idle.behavior, Behavior::GuardFailure);
        assert_eq!(
            VisualTransition::between(first.behavior, idle.behavior),
            Some(VisualTransition::SitNearErrorToGuardFailure)
        );

        // Idle escalation from Failure → Stuck (third open failure via sync
        // or a later settle) and Recovery → Cautious are also intentional arcs.
        assert_eq!(
            VisualTransition::between(Behavior::GuardFailure, Behavior::GuardStuck),
            Some(VisualTransition::GuardFailureToGuardStuck)
        );
        assert_eq!(
            VisualTransition::between(Behavior::GuardRecovery, Behavior::GuardCautious),
            Some(VisualTransition::GuardRecoveryToGuardCautious)
        );
    }

    #[test]
    fn idle_vigil_relapse_has_full_motion_bridges() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_work_context(RepoWorkState::new(0, true, 1), 1, 1);
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardRecovery);

        assert!(organism.sync_repo_work_state(RepoWorkState::new(1, false, 1)));
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardFailure);
        assert_eq!(
            VisualTransition::between(Behavior::GuardRecovery, Behavior::GuardFailure),
            Some(VisualTransition::GuardRecoveryToGuardFailure)
        );

        organism.restore_repo_work_context(RepoWorkState::new(0, true, 3), 1, 1);
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardCautious);
        assert!(organism.sync_repo_work_state(RepoWorkState::new(3, false, 3)));
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardStuck);
        assert_eq!(
            VisualTransition::between(Behavior::GuardCautious, Behavior::GuardStuck),
            Some(VisualTransition::GuardCautiousToGuardStuck)
        );

        // Stuck can also downgrade to Failure when open work shrinks.
        assert_eq!(
            VisualTransition::between(Behavior::GuardStuck, Behavior::GuardFailure),
            Some(VisualTransition::GuardStuckToGuardFailure)
        );
        assert_eq!(
            VisualTransition::between(Behavior::GuardRecovery, Behavior::GuardStuck),
            Some(VisualTransition::GuardRecoveryToGuardStuck)
        );
        assert_eq!(
            VisualTransition::between(Behavior::GuardCautious, Behavior::GuardFailure),
            Some(VisualTransition::GuardCautiousToGuardFailure)
        );
    }

    #[test]
    fn celebrate_hold_relapse_settle_has_full_motion_bridges() {
        let mut organism = NativeOrganism::default();
        organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        let cele = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(cele.behavior, Behavior::Celebrate);
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardRecovery);

        assert!(organism.sync_repo_work_state(RepoWorkState::new(1, false, 1)));
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardFailure);
        assert_eq!(
            VisualTransition::between(cele.behavior, Behavior::GuardFailure),
            Some(VisualTransition::CelebrateToGuardFailure)
        );
        assert_eq!(
            VisualTransition::between(Behavior::Celebrate, Behavior::GuardStuck),
            Some(VisualTransition::CelebrateToGuardStuck)
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::GuardFailure),
            Some(VisualTransition::CelebrateBigToGuardFailure)
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::GuardStuck),
            Some(VisualTransition::CelebrateBigToGuardStuck)
        );
    }

    #[test]
    fn failure_vigil_push_has_full_motion_bridges() {
        let mut organism = NativeOrganism::default();
        organism.restore_repo_work_context(RepoWorkState::new(1, false, 0), 1, 1);
        assert_eq!(organism.idle_reaction().behavior, Behavior::GuardFailure);
        let push = organism.command_finished(CommandKind::GitPush, Some(0), None);
        assert_eq!(push.behavior, Behavior::RestAfterPush);
        assert_eq!(
            VisualTransition::between(Behavior::GuardFailure, push.behavior),
            Some(VisualTransition::GuardFailureToRestAfterPush)
        );
        assert_eq!(
            VisualTransition::between(Behavior::GuardStuck, Behavior::RestAfterPush),
            Some(VisualTransition::GuardStuckToRestAfterPush)
        );
    }

    #[test]
    fn inspect_hold_second_failure_has_full_motion_bridge() {
        // Finish-overwrite without Watch: first open failure Inspect, second
        // SitNear — same hold class as Unknown→SitNear / Celebrate→SitNear.
        let mut organism = NativeOrganism::default();
        let inspect = organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        let sit = organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(sit.behavior, Behavior::SitNearError);
        assert_eq!(
            VisualTransition::between(inspect.behavior, sit.behavior),
            Some(VisualTransition::InspectErrorToSitNearError)
        );
    }

    /// Error hold still showing when a missing-exit finish lands: Celebrate/
    /// Rest/Recovery→Unknown already animate; Inspect/SitNear must not snap.
    #[test]
    fn error_hold_unknown_overwrites_have_full_motion_bridges() {
        let mut inspect_hold = NativeOrganism::default();
        let inspect = inspect_hold.command_finished(CommandKind::Other, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        let unknown = inspect_hold.command_finished(CommandKind::Other, None, None);
        assert_eq!(unknown.behavior, Behavior::UnknownOutcome);
        assert_eq!(
            VisualTransition::between(inspect.behavior, unknown.behavior),
            Some(VisualTransition::InspectErrorToUnknownOutcome)
        );

        let mut sit_hold = NativeOrganism::default();
        sit_hold.command_finished(CommandKind::BuildOrTest, Some(1), None);
        let sit = sit_hold.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(sit.behavior, Behavior::SitNearError);
        let unknown = sit_hold.command_finished(CommandKind::Other, None, None);
        assert_eq!(unknown.behavior, Behavior::UnknownOutcome);
        assert_eq!(
            VisualTransition::between(sit.behavior, unknown.behavior),
            Some(VisualTransition::SitNearErrorToUnknownOutcome)
        );
    }

    #[test]
    fn error_hold_success_has_full_motion_bridges() {
        let mut organism = NativeOrganism::default();
        let inspect = organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        let pass = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(pass.behavior, Behavior::Celebrate);
        assert_eq!(
            VisualTransition::between(inspect.behavior, pass.behavior),
            Some(VisualTransition::InspectErrorToCelebrate)
        );
        assert_eq!(
            VisualTransition::between(Behavior::InspectError, Behavior::CelebrateBig),
            Some(VisualTransition::InspectErrorToCelebrateBig)
        );
        assert_eq!(
            VisualTransition::between(Behavior::SitNearError, Behavior::Celebrate),
            Some(VisualTransition::SitNearErrorToCelebrate)
        );
        assert_eq!(
            VisualTransition::between(Behavior::SitNearError, Behavior::CelebrateBig),
            Some(VisualTransition::SitNearErrorToCelebrateBig)
        );
    }

    #[test]
    fn celebrate_hold_push_has_full_motion_bridges() {
        let mut organism = NativeOrganism::default();
        organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        let cele = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(cele.behavior, Behavior::Celebrate);
        let push = organism.command_finished(CommandKind::GitPush, Some(0), None);
        assert_eq!(push.behavior, Behavior::RestAfterPush);
        assert_eq!(
            VisualTransition::between(cele.behavior, push.behavior),
            Some(VisualTransition::CelebrateToRestAfterPush)
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::RestAfterPush),
            Some(VisualTransition::CelebrateBigToRestAfterPush)
        );
    }

    /// Error/unknown holds still showing when a push lands: Guard*/Watch*/
    /// Celebrate→Rest already animate; Inspect/SitNear/Unknown must not snap.
    #[test]
    fn error_and_unknown_holds_push_have_full_motion_bridges() {
        let mut inspect_hold = NativeOrganism::default();
        let inspect = inspect_hold.command_finished(CommandKind::Other, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        let push = inspect_hold.command_finished(CommandKind::GitPush, Some(0), None);
        assert_eq!(push.behavior, Behavior::RestAfterPush);
        assert_eq!(
            VisualTransition::between(inspect.behavior, push.behavior),
            Some(VisualTransition::InspectErrorToRestAfterPush)
        );
        assert_eq!(
            VisualTransition::between(Behavior::SitNearError, Behavior::RestAfterPush),
            Some(VisualTransition::SitNearErrorToRestAfterPush)
        );
        assert_eq!(
            VisualTransition::between(Behavior::UnknownOutcome, Behavior::RestAfterPush),
            Some(VisualTransition::UnknownOutcomeToRestAfterPush)
        );
    }

    /// Clean Other finishes land on Idle while a watch pose is still showing.
    /// Watch*→Rest already animates for GitPush; Watch* must not snap to Idle.
    #[test]
    fn watch_poses_clean_other_idle_have_full_motion_bridges() {
        for (from, expected) in [
            (Behavior::WatchCommand, VisualTransition::WatchCommandToIdle),
            (Behavior::WatchAgent, VisualTransition::WatchAgentToIdle),
            (Behavior::WatchSettled, VisualTransition::WatchSettledToIdle),
        ] {
            assert_eq!(
                VisualTransition::between(from, Behavior::Idle),
                Some(expected),
                "{from:?}→Idle"
            );
        }
        let mut organism = NativeOrganism::default();
        let watch = organism.command_started(CommandKind::Other);
        assert_eq!(watch.behavior, Behavior::WatchCommand);
        let idle = organism.command_finished(CommandKind::Other, Some(0), None);
        assert_eq!(idle.behavior, Behavior::Idle);
        assert_eq!(
            VisualTransition::between(watch.behavior, idle.behavior),
            Some(VisualTransition::WatchCommandToIdle)
        );
    }

    /// Celebrate hold still showing when another finish lands: Guard*/Idle/Rest
    /// already animate; Inspect/SitNear/Unknown must not snap.
    #[test]
    fn celebrate_hold_finish_overwrites_have_full_motion_bridges() {
        let mut inspect_hold = NativeOrganism::default();
        let cele = inspect_hold.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(cele.behavior, Behavior::Celebrate);
        let inspect = inspect_hold.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        assert_eq!(
            VisualTransition::between(cele.behavior, inspect.behavior),
            Some(VisualTransition::CelebrateToInspectError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::Celebrate, Behavior::SitNearError),
            Some(VisualTransition::CelebrateToSitNearError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::Celebrate, Behavior::UnknownOutcome),
            Some(VisualTransition::CelebrateToUnknownOutcome)
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::InspectError),
            Some(VisualTransition::CelebrateBigToInspectError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::SitNearError),
            Some(VisualTransition::CelebrateBigToSitNearError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::UnknownOutcome),
            Some(VisualTransition::CelebrateBigToUnknownOutcome)
        );
    }

    /// Rest hold still showing when another finish lands: Rest→Idle already
    /// animates; Celebrate*/Inspect/SitNear/Unknown must not snap.
    #[test]
    fn rest_hold_finish_overwrites_have_full_motion_bridges() {
        let mut rest_hold = NativeOrganism::default();
        let rest = rest_hold.command_finished(CommandKind::GitPush, Some(0), None);
        assert_eq!(rest.behavior, Behavior::RestAfterPush);
        let inspect = rest_hold.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        assert_eq!(
            VisualTransition::between(rest.behavior, inspect.behavior),
            Some(VisualTransition::RestAfterPushToInspectError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::RestAfterPush, Behavior::SitNearError),
            Some(VisualTransition::RestAfterPushToSitNearError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::RestAfterPush, Behavior::UnknownOutcome),
            Some(VisualTransition::RestAfterPushToUnknownOutcome)
        );
        assert_eq!(
            VisualTransition::between(Behavior::RestAfterPush, Behavior::Celebrate),
            Some(VisualTransition::RestAfterPushToCelebrate)
        );
        assert_eq!(
            VisualTransition::between(Behavior::RestAfterPush, Behavior::CelebrateBig),
            Some(VisualTransition::RestAfterPushToCelebrateBig)
        );
    }

    /// Recovery vigil still showing when a finish lands without Watch:
    /// Idle/Rest already animate; Inspect/SitNear/Unknown must not snap.
    #[test]
    fn guard_recovery_finish_overwrites_have_full_motion_bridges() {
        let mut recovered = NativeOrganism::default();
        recovered.command_finished(CommandKind::BuildOrTest, Some(1), None);
        recovered.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(recovered.idle_reaction().behavior, Behavior::GuardRecovery);
        let inspect = recovered.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        assert_eq!(
            VisualTransition::between(Behavior::GuardRecovery, inspect.behavior),
            Some(VisualTransition::GuardRecoveryToInspectError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::GuardRecovery, Behavior::SitNearError),
            Some(VisualTransition::GuardRecoveryToSitNearError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::GuardRecovery, Behavior::UnknownOutcome),
            Some(VisualTransition::GuardRecoveryToUnknownOutcome)
        );
    }

    #[test]
    fn watch_settled_failure_has_full_motion_bridges() {
        assert_eq!(
            VisualTransition::between(Behavior::WatchSettled, Behavior::InspectError),
            Some(VisualTransition::WatchSettledToInspectError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchSettled, Behavior::SitNearError),
            Some(VisualTransition::WatchSettledToSitNearError)
        );
    }

    /// Long-watch finish table: every reducer-reachable leave from WatchSettled
    /// animates under Full motion (pass/fail/rest/idle). Unknown stays an
    /// intentional snap (`watch_settled_never_bridges_to_unknown_outcome`).
    /// Celebrate was previously only covered inside CelebrateBig's inbound list.
    #[test]
    fn watch_settled_finish_arcs_cover_pass_fail_rest_and_idle() {
        let arcs = [
            (
                Behavior::Celebrate,
                VisualTransition::WatchSettledToCelebrate,
            ),
            (
                Behavior::CelebrateBig,
                VisualTransition::WatchSettledToCelebrateBig,
            ),
            (
                Behavior::InspectError,
                VisualTransition::WatchSettledToInspectError,
            ),
            (
                Behavior::SitNearError,
                VisualTransition::WatchSettledToSitNearError,
            ),
            (
                Behavior::RestAfterPush,
                VisualTransition::WatchSettledToRestAfterPush,
            ),
            (Behavior::Idle, VisualTransition::WatchSettledToIdle),
        ];
        for (to, expected) in arcs {
            assert_eq!(
                VisualTransition::between(Behavior::WatchSettled, to),
                Some(expected),
                "WatchSettled→{to:?}"
            );
        }
        assert_eq!(
            arcs.len(),
            6,
            "WatchSettled finish-arc table is six Some bridges"
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchSettled, Behavior::UnknownOutcome),
            None,
            "missing-exit Unknown still snaps (no bridge frames)"
        );
    }

    #[test]
    fn watch_command_and_agent_finish_have_full_motion_bridges() {
        assert_eq!(
            VisualTransition::between(Behavior::WatchCommand, Behavior::Celebrate),
            Some(VisualTransition::WatchCommandToCelebrate)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchCommand, Behavior::CelebrateBig),
            Some(VisualTransition::WatchCommandToCelebrateBig)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchCommand, Behavior::InspectError),
            Some(VisualTransition::WatchCommandToInspectError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchCommand, Behavior::SitNearError),
            Some(VisualTransition::WatchCommandToSitNearError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchCommand, Behavior::RestAfterPush),
            Some(VisualTransition::WatchCommandToRestAfterPush)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchAgent, Behavior::Celebrate),
            Some(VisualTransition::WatchAgentToCelebrate)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchAgent, Behavior::InspectError),
            Some(VisualTransition::WatchAgentToInspectError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchAgent, Behavior::SitNearError),
            Some(VisualTransition::WatchAgentToSitNearError)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchAgent, Behavior::RestAfterPush),
            Some(VisualTransition::WatchAgentToRestAfterPush)
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchSettled, Behavior::RestAfterPush),
            Some(VisualTransition::WatchSettledToRestAfterPush)
        );
    }

    /// Agent-driven passes celebrate quietly (`Celebrate`); `CelebrateBig` is
    /// reserved for human-driven wins. Pin `None` so a future bridge cannot
    /// land silently inside the WatchAgent finish table.
    #[test]
    fn watch_agent_never_bridges_to_celebrate_big() {
        assert_eq!(
            VisualTransition::between(Behavior::WatchAgent, Behavior::CelebrateBig),
            None
        );
    }

    /// WatchAgent finishes resolve to Celebrate/Inspect/Sit/Rest — never to the
    /// unknown-hold pose. Pin `None` so a WatchAgent→UnknownOutcome bridge
    /// cannot appear without an explicit reducer story.
    #[test]
    fn watch_agent_never_bridges_to_unknown_outcome() {
        assert_eq!(
            VisualTransition::between(Behavior::WatchAgent, Behavior::UnknownOutcome),
            None
        );
    }

    /// Human watch with a missing exit status lands on UnknownOutcome via the
    /// reducer, but Full motion still snaps (no bridge frames). Pin `None` so
    /// a WatchCommand→UnknownOutcome arc cannot appear beside the WatchAgent
    /// None pin without an explicit story.
    #[test]
    fn watch_command_never_bridges_to_unknown_outcome() {
        assert_eq!(
            VisualTransition::between(Behavior::WatchCommand, Behavior::UnknownOutcome),
            None
        );
    }

    /// Long-watch vigil is a display pose; a missing exit status still lands on
    /// UnknownOutcome via the reducer and Full motion snaps (no bridge frames).
    /// Pin `None` beside the WatchCommand/WatchAgent UnknownOutcome pins.
    #[test]
    fn watch_settled_never_bridges_to_unknown_outcome() {
        assert_eq!(
            VisualTransition::between(Behavior::WatchSettled, Behavior::UnknownOutcome),
            None
        );
    }

    /// Watch finishes resolve to Celebrate/Inspect/Sit/Rest (or Unknown snap) —
    /// never skip straight into a repo vigil pose. Pin `None` so a Watch*→Guard*
    /// bridge cannot land silently beside Celebrate→Guard*.
    #[test]
    fn watch_poses_never_bridge_to_repo_vigil_guards() {
        for from in [
            Behavior::WatchCommand,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
        ] {
            for to in [
                Behavior::GuardFailure,
                Behavior::GuardStuck,
                Behavior::GuardRecovery,
                Behavior::GuardCautious,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None"
                );
            }
        }
    }

    /// Survey leftover beside WatchSettled finish arcs (6 Some inside between()
    /// 93): live watches never invent bridges into ambient utility poses —
    /// Explore/Sleep/Approach arrive from ambient mind rescoring, not from a
    /// Watch* finish. Pin `None` so Watch*→ambient cannot land beside the
    /// ambient→Watch* Nones already covered.
    #[test]
    fn watch_poses_never_bridge_to_ambient_utility() {
        for from in [
            Behavior::WatchCommand,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
        ] {
            for to in [Behavior::Explore, Behavior::Sleep, Behavior::Approach] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None (ambient via mind, not Watch*)"
                );
            }
        }
    }

    /// Repo vigil poses push or escalate among themselves — they do not celebrate.
    /// Celebrations come from command-finish on error holds. Pin `None` so a
    /// Guard*→Celebrate* bridge cannot appear beside Celebrate→Guard*.
    #[test]
    fn repo_vigil_guards_never_bridge_to_celebrate() {
        for from in [
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
        ] {
            for to in [Behavior::Celebrate, Behavior::CelebrateBig] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None"
                );
            }
        }
    }

    /// Celebrate holds settle to Guard*/Idle/Rest — a new command mid-hold snaps
    /// into Watch* without bridge frames. Pin `None` so Celebrate*→Watch* cannot
    /// land silently beside Watch*→Celebrate*.
    #[test]
    fn celebrate_holds_never_bridge_to_watch_poses() {
        for from in [Behavior::Celebrate, Behavior::CelebrateBig] {
            for to in [
                Behavior::WatchCommand,
                Behavior::WatchAgent,
                Behavior::WatchSettled,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None"
                );
            }
        }
    }

    /// Survey leftover beside Watch*→ambient and ambient→hold Nones: celebrate /
    /// error / unknown / rest holds settle through Idle (or Guard*), never invent
    /// bridges into Explore/Sleep/Approach — those arrive from ambient mind
    /// rescoring after clear-vigil. Pin `None` so hold→ambient cannot land
    /// beside ambient→hold. between() stays 93.
    #[test]
    fn hold_and_rest_poses_never_bridge_to_ambient_utility() {
        for from in [
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::UnknownOutcome,
            Behavior::RestAfterPush,
        ] {
            for to in [Behavior::Explore, Behavior::Sleep, Behavior::Approach] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None (ambient via mind, not hold)"
                );
            }
        }
    }

    /// Repo vigil poses push or escalate among themselves — ambient utility
    /// arrives from mind rescoring after clear-vigil Idle, not from a Guard*
    /// finish. Pin `None` so Guard*→Explore/Sleep/Approach cannot land beside
    /// hold→ambient and Watch*→ambient. between() stays 93.
    #[test]
    fn repo_vigil_guards_never_bridge_to_ambient_utility() {
        for from in [
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
        ] {
            for to in [Behavior::Explore, Behavior::Sleep, Behavior::Approach] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None (ambient via mind, not Guard*)"
                );
            }
        }
    }

    /// Watch pose family switches (Command↔Agent↔Settled) are live SurfaceMode
    /// remaps — elapsed-onset settled vigil and agent crouch — not reducer
    /// VisualTransition arcs. Finishes leave Watch* via the Some bridges already
    /// counted in between() 93. Pin `None` so a silent Watch*↔Watch* bridge
    /// cannot land beside Watch*→Idle/Celebrate.
    #[test]
    fn watch_pose_mode_switches_have_no_visual_transition() {
        for (from, to) in [
            (Behavior::WatchCommand, Behavior::WatchAgent),
            (Behavior::WatchCommand, Behavior::WatchSettled),
            (Behavior::WatchAgent, Behavior::WatchCommand),
            (Behavior::WatchAgent, Behavior::WatchSettled),
            (Behavior::WatchSettled, Behavior::WatchCommand),
            (Behavior::WatchSettled, Behavior::WatchAgent),
        ] {
            assert_eq!(
                VisualTransition::between(from, to),
                None,
                "{from:?}→{to:?} must stay None (live remap, not between)"
            );
        }
    }

    /// Idle/Rest clear-vigil settle already animates to Idle; an open repo vigil
    /// appearing from Idle or RestAfterPush snaps (no bridge). Pin `None` so
    /// Idle/Rest→Guard* cannot appear beside UnknownOutcome→Guard*.
    #[test]
    fn idle_and_rest_never_bridge_to_repo_vigil_guards() {
        for from in [Behavior::Idle, Behavior::RestAfterPush] {
            for to in [
                Behavior::GuardFailure,
                Behavior::GuardStuck,
                Behavior::GuardRecovery,
                Behavior::GuardCautious,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None"
                );
            }
        }
    }

    /// New command mid-rest or mid-vigil snaps into Watch* without bridge
    /// frames, same contract as Celebrate*→Watch*. Failure/Stuck/Cautious join
    /// Recovery — idle_reaction shows those poses before command_started.
    #[test]
    fn rest_and_repo_vigil_never_bridge_to_watch_poses() {
        for from in [
            Behavior::RestAfterPush,
            Behavior::GuardRecovery,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardCautious,
        ] {
            for to in [
                Behavior::WatchCommand,
                Behavior::WatchAgent,
                Behavior::WatchSettled,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None"
                );
            }
        }
    }

    /// Failure/Stuck/Cautious vigil still showing when a finish lands: Recovery
    /// animates those overwrites, but the other three vigil poses have no
    /// Inspect/Sit/Unknown story. Pin `None` so they cannot appear beside
    /// GuardRecovery→Inspect.
    #[test]
    fn failure_stuck_cautious_never_bridge_to_error_or_unknown_holds() {
        for from in [
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardCautious,
        ] {
            for to in [
                Behavior::InspectError,
                Behavior::SitNearError,
                Behavior::UnknownOutcome,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None"
                );
            }
        }
    }

    /// Survey (between() 93): GuardFailure/Stuck/Cautious do not animate into
    /// Celebrate* — a success finish reaches Celebrate through Watch*, and the
    /// vigil→Watch snap is already intentional None. Pin so a silent
    /// Guard*→Celebrate bridge cannot land beside Celebrate→Guard*.
    #[test]
    fn failure_stuck_cautious_never_bridge_to_celebrate_holds() {
        for from in [
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardCautious,
        ] {
            for to in [Behavior::Celebrate, Behavior::CelebrateBig] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None (success finishes via Watch*)"
                );
            }
        }
    }

    /// Error / unknown holds settle to Idle/Rest/Celebrate/Guard — a new
    /// command mid-hold snaps into Watch* without bridge frames. Pin `None`
    /// so Inspect/SitNear/Unknown→Watch* cannot land beside Watch*→Inspect.
    #[test]
    fn error_and_unknown_holds_never_bridge_to_watch_poses() {
        for from in [
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::UnknownOutcome,
        ] {
            for to in [
                Behavior::WatchCommand,
                Behavior::WatchAgent,
                Behavior::WatchSettled,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "{from:?}→{to:?} must stay None"
                );
            }
        }
    }

    /// GlanceAside is a live presence cue, not a reducer Behavior source.
    /// Pin the common overwrite targets so a bridge cannot land silently.
    /// Explore/Sleep/Approach join the set so GlanceAside↔ambient cannot invent
    /// arcs beside the UI Full-motion completeness pin (between() stays 93).
    #[test]
    fn glance_aside_never_bridges_as_a_transition_source() {
        for to in [
            Behavior::Idle,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::RestAfterPush,
            Behavior::UnknownOutcome,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
            Behavior::WatchCommand,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
            Behavior::Explore,
            Behavior::Sleep,
            Behavior::Approach,
        ] {
            assert_eq!(
                VisualTransition::between(Behavior::GlanceAside, to),
                None,
                "GlanceAside→{to:?} must stay None"
            );
        }
    }

    /// GlanceAside is also never a bridge target — the live cue overlays without
    /// a VisualTransition arc. Pin common sources so a *→GlanceAside bridge
    /// cannot land silently beside the source-side None pin. Ambient utility
    /// poses join so GlanceAside↔Explore/Sleep/Approach stays intentional None.
    #[test]
    fn glance_aside_never_bridges_as_a_transition_target() {
        for from in [
            Behavior::Idle,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::RestAfterPush,
            Behavior::UnknownOutcome,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
            Behavior::WatchCommand,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
            Behavior::Explore,
            Behavior::Sleep,
            Behavior::Approach,
        ] {
            assert_eq!(
                VisualTransition::between(from, Behavior::GlanceAside),
                None,
                "{from:?}→GlanceAside must stay None"
            );
        }
    }

    /// Inspect→SitNear animates (second open failure overwrite). The reverse
    /// escalation does not happen in the reducer — pin SitNear→Inspect None.
    /// Celebrate↔CelebrateBig likewise has no finish-overwrite story (tier is
    /// chosen once per success finish).
    #[test]
    fn sit_near_and_celebrate_tier_overwrites_stay_none() {
        assert_eq!(
            VisualTransition::between(Behavior::SitNearError, Behavior::InspectError),
            None
        );
        assert_eq!(
            VisualTransition::between(Behavior::Celebrate, Behavior::CelebrateBig),
            None
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::Celebrate),
            None
        );
    }

    /// CelebrateBig finish arcs: every reducer-reachable path that can land on
    /// or leave CelebrateBig must animate under Full motion, matching Celebrate
    /// except WatchAgent (quiet nod — never CelebrateBig). Fifteen Some bridges
    /// plus the intentional WatchAgent / tier-overwrite Nones.
    #[test]
    fn celebrate_big_finish_arcs_mirror_celebrate_except_watch_agent() {
        let inbound = [
            (
                Behavior::WatchSettled,
                VisualTransition::WatchSettledToCelebrateBig,
            ),
            (
                Behavior::WatchCommand,
                VisualTransition::WatchCommandToCelebrateBig,
            ),
            (
                Behavior::InspectError,
                VisualTransition::InspectErrorToCelebrateBig,
            ),
            (
                Behavior::SitNearError,
                VisualTransition::SitNearErrorToCelebrateBig,
            ),
            (
                Behavior::UnknownOutcome,
                VisualTransition::UnknownOutcomeToCelebrateBig,
            ),
            (
                Behavior::RestAfterPush,
                VisualTransition::RestAfterPushToCelebrateBig,
            ),
        ];
        for (from, expected) in inbound {
            assert_eq!(
                VisualTransition::between(from, Behavior::CelebrateBig),
                Some(expected),
                "{from:?}→CelebrateBig"
            );
        }

        let outbound = [
            (
                Behavior::GuardRecovery,
                VisualTransition::CelebrateBigToGuardRecovery,
            ),
            (
                Behavior::GuardCautious,
                VisualTransition::CelebrateBigToGuardCautious,
            ),
            (
                Behavior::GuardFailure,
                VisualTransition::CelebrateBigToGuardFailure,
            ),
            (
                Behavior::GuardStuck,
                VisualTransition::CelebrateBigToGuardStuck,
            ),
            (
                Behavior::RestAfterPush,
                VisualTransition::CelebrateBigToRestAfterPush,
            ),
            (Behavior::Idle, VisualTransition::CelebrateBigToIdle),
            (
                Behavior::InspectError,
                VisualTransition::CelebrateBigToInspectError,
            ),
            (
                Behavior::SitNearError,
                VisualTransition::CelebrateBigToSitNearError,
            ),
            (
                Behavior::UnknownOutcome,
                VisualTransition::CelebrateBigToUnknownOutcome,
            ),
        ];
        for (to, expected) in outbound {
            assert_eq!(
                VisualTransition::between(Behavior::CelebrateBig, to),
                Some(expected),
                "CelebrateBig→{to:?}"
            );
        }

        assert_eq!(
            inbound.len() + outbound.len(),
            15,
            "CelebrateBig finish-arc table is fifteen Some bridges"
        );
        assert_eq!(
            VisualTransition::between(Behavior::WatchAgent, Behavior::CelebrateBig),
            None,
            "agent-driven passes stay Celebrate, never CelebrateBig"
        );
        assert_eq!(
            VisualTransition::between(Behavior::Celebrate, Behavior::CelebrateBig),
            None
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::Celebrate),
            None
        );
    }

    /// Ambient utility dispositions (Idle/Explore/Sleep/Approach) map to the
    /// same-named Behavior poses for display, but disposition *exchanges* are
    /// not VisualTransition arcs — ambient mind rescoring snaps. Typing is a
    /// SurfaceMode that collapses to WatchCommand in the UIs; there is still
    /// no Explore→WatchCommand (or similar) ambient entry bridge here.
    #[test]
    fn ambient_disposition_exchanges_have_no_visual_transition() {
        for (from, to) in [
            (Behavior::Idle, Behavior::Explore),
            (Behavior::Explore, Behavior::Idle),
            (Behavior::Explore, Behavior::Sleep),
            (Behavior::Sleep, Behavior::Explore),
            (Behavior::Sleep, Behavior::Idle),
            (Behavior::Idle, Behavior::Sleep),
            (Behavior::Explore, Behavior::Approach),
            (Behavior::Approach, Behavior::Explore),
            (Behavior::Approach, Behavior::Idle),
            (Behavior::Idle, Behavior::Approach),
            (Behavior::Sleep, Behavior::Approach),
            (Behavior::Approach, Behavior::Sleep),
            // Typing-shaped entry from an ambient pose snaps onto WatchCommand.
            // WatchAgent / WatchSettled entries from ambient stay None the same
            // way — Watch*→Idle animates, Idle/ambient→Watch* never invents a
            // bridge (pairs UI ambient→Watch* pins).
            (Behavior::Explore, Behavior::WatchCommand),
            (Behavior::Sleep, Behavior::WatchCommand),
            (Behavior::Approach, Behavior::WatchCommand),
            (Behavior::Idle, Behavior::WatchCommand),
            (Behavior::Explore, Behavior::WatchAgent),
            (Behavior::Sleep, Behavior::WatchAgent),
            (Behavior::Approach, Behavior::WatchAgent),
            (Behavior::Idle, Behavior::WatchAgent),
            (Behavior::Explore, Behavior::WatchSettled),
            (Behavior::Sleep, Behavior::WatchSettled),
            (Behavior::Approach, Behavior::WatchSettled),
            (Behavior::Idle, Behavior::WatchSettled),
        ] {
            assert_eq!(
                VisualTransition::between(from, to),
                None,
                "ambient/typing {from:?}→{to:?} must stay None"
            );
        }
        // Ambient utility poses also never invent bridges into repo vigil or
        // Celebrate holds — open vigil / success finish land through Watch*
        // (or Idle snap). Idle/Rest→Guard* is pinned elsewhere; pin the other
        // ambient sources so Explore/Sleep/Approach cannot silently gain arcs.
        for from in [Behavior::Explore, Behavior::Sleep, Behavior::Approach] {
            for to in [
                Behavior::GuardFailure,
                Behavior::GuardStuck,
                Behavior::GuardRecovery,
                Behavior::GuardCautious,
                Behavior::Celebrate,
                Behavior::CelebrateBig,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "ambient {from:?}→{to:?} must stay None"
                );
            }
        }
        // Same ambient sources never invent bridges into error / unknown holds
        // or RestAfterPush — those arrive from finish/push reducers, not from
        // Explore/Sleep/Approach disposition. between() stays 93.
        for from in [Behavior::Explore, Behavior::Sleep, Behavior::Approach] {
            for to in [
                Behavior::InspectError,
                Behavior::SitNearError,
                Behavior::UnknownOutcome,
                Behavior::RestAfterPush,
            ] {
                assert_eq!(
                    VisualTransition::between(from, to),
                    None,
                    "ambient {from:?}→{to:?} must stay None (hold/rest)"
                );
            }
        }

        // Idle→hold/cele/rest also stays None: live finishes arrive through
        // Watch* (which already animate). A finish applied from Idle without
        // Watch snaps; pin so Idle cannot silently gain Celebrate/Inspect arcs
        // beside the ambient utility hold/rest Nones.
        for to in [
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::UnknownOutcome,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::RestAfterPush,
        ] {
            assert_eq!(
                VisualTransition::between(Behavior::Idle, to),
                None,
                "Idle→{to:?} must stay None (finish without Watch snaps)"
            );
        }
    }

    #[test]
    fn celebrate_and_rest_settle_to_idle_has_full_motion_bridges() {
        assert_eq!(
            VisualTransition::between(Behavior::Celebrate, Behavior::Idle),
            Some(VisualTransition::CelebrateToIdle)
        );
        assert_eq!(
            VisualTransition::between(Behavior::CelebrateBig, Behavior::Idle),
            Some(VisualTransition::CelebrateBigToIdle)
        );
        assert_eq!(
            VisualTransition::between(Behavior::RestAfterPush, Behavior::Idle),
            Some(VisualTransition::RestAfterPushToIdle)
        );
    }

    #[test]
    fn unknown_outcome_settle_and_overwrite_have_full_motion_bridges() {
        // GlanceAside is live-only (presence cue), not a reducer transition
        // source. UnknownOutcome is: clear-vigil settle → Idle, and a first
        // open failure that overtakes the hold → InspectError.
        let mut organism = NativeOrganism::default();
        organism.command_started(CommandKind::BuildOrTest);
        let unknown = organism.command_finished(CommandKind::BuildOrTest, None, None);
        assert_eq!(unknown.behavior, Behavior::UnknownOutcome);
        let idle = organism.idle_reaction();
        assert_eq!(idle.behavior, Behavior::Idle);
        assert_eq!(
            VisualTransition::between(unknown.behavior, idle.behavior),
            Some(VisualTransition::UnknownOutcomeToIdle)
        );

        let mut overwrite = NativeOrganism::default();
        let held = overwrite.command_finished(CommandKind::Other, None, None);
        assert_eq!(held.behavior, Behavior::UnknownOutcome);
        let inspect = overwrite.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        assert_eq!(
            VisualTransition::between(held.behavior, inspect.behavior),
            Some(VisualTransition::UnknownOutcomeToInspectError)
        );
        // GlanceAside stays out of the bridge table.
        assert_eq!(
            VisualTransition::between(Behavior::GlanceAside, Behavior::InspectError),
            None
        );
        assert_eq!(
            VisualTransition::between(Behavior::GlanceAside, Behavior::SitNearError),
            None
        );
    }

    /// Non-build error holds settle to clear-vigil Idle the same way Unknown
    /// already does. Without these arcs Full motion snaps on hold expiry.
    #[test]
    fn error_hold_clear_idle_settles_have_full_motion_bridges() {
        let mut inspect_hold = NativeOrganism::default();
        let inspect = inspect_hold.command_finished(CommandKind::Other, Some(1), None);
        assert_eq!(inspect.behavior, Behavior::InspectError);
        assert_eq!(inspect_hold.repo_vigil(), RepoVigil::None);
        let idle = inspect_hold.idle_reaction();
        assert_eq!(idle.behavior, Behavior::Idle);
        assert_eq!(
            VisualTransition::between(inspect.behavior, idle.behavior),
            Some(VisualTransition::InspectErrorToIdle)
        );

        let mut sit_hold = NativeOrganism::default();
        sit_hold.command_finished(CommandKind::Other, Some(1), None);
        sit_hold.command_finished(CommandKind::Other, Some(1), None);
        let sit = sit_hold.command_finished(CommandKind::Other, Some(1), None);
        assert_eq!(sit.behavior, Behavior::SitNearError);
        assert_eq!(sit_hold.repo_vigil(), RepoVigil::None);
        let idle = sit_hold.idle_reaction();
        assert_eq!(idle.behavior, Behavior::Idle);
        assert_eq!(
            VisualTransition::between(sit.behavior, idle.behavior),
            Some(VisualTransition::SitNearErrorToIdle)
        );
    }

    /// Repo vigil poses settle to Idle when sibling sync clears the open
    /// vigil. Celebrate/Unknown→Idle already animate; Guard* must not snap.
    #[test]
    fn repo_vigil_clear_idle_settles_have_full_motion_bridges() {
        for (from, expected) in [
            (Behavior::GuardFailure, VisualTransition::GuardFailureToIdle),
            (Behavior::GuardStuck, VisualTransition::GuardStuckToIdle),
            (
                Behavior::GuardRecovery,
                VisualTransition::GuardRecoveryToIdle,
            ),
            (
                Behavior::GuardCautious,
                VisualTransition::GuardCautiousToIdle,
            ),
        ] {
            assert_eq!(
                VisualTransition::between(from, Behavior::Idle),
                Some(expected),
                "{from:?}→Idle"
            );
        }

        let mut cleared = NativeOrganism::default();
        cleared.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(cleared.repo_vigil(), RepoVigil::Failure);
        assert_eq!(cleared.idle_reaction().behavior, Behavior::GuardFailure);
        assert!(cleared.sync_repo_work_state(RepoWorkState::new(0, false, 0)));
        assert_eq!(cleared.repo_vigil(), RepoVigil::None);
        assert_eq!(cleared.idle_reaction().behavior, Behavior::Idle);
        assert_eq!(
            VisualTransition::between(Behavior::GuardFailure, Behavior::Idle),
            Some(VisualTransition::GuardFailureToIdle)
        );
    }

    #[test]
    fn visual_transition_between_recognizes_ninety_three_intentional_arcs() {
        // Recount pin: anvil/forge `semantic_bridges_run_only_in_full_motion`
        // must stay in lockstep with this Some count (93 intentional arcs —
        // Inspect/SitNear→UnknownOutcome error-hold missing-exit overwrites;
        // CelebrateBig finish table + WatchSettled finish arcs (6 Some) stay
        // inside the count — UI lists already name all six WatchSettled→*).
        let mut count = 0usize;
        for from in [
            Behavior::Idle,
            Behavior::WatchCommand,
            Behavior::WatchAgent,
            Behavior::WatchSettled,
            Behavior::InspectError,
            Behavior::SitNearError,
            Behavior::Celebrate,
            Behavior::CelebrateBig,
            Behavior::RestAfterPush,
            Behavior::UnknownOutcome,
            Behavior::GlanceAside,
            Behavior::GuardFailure,
            Behavior::GuardStuck,
            Behavior::GuardRecovery,
            Behavior::GuardCautious,
            Behavior::Sleep,
            Behavior::Explore,
            Behavior::Approach,
        ] {
            for to in [
                Behavior::Idle,
                Behavior::WatchCommand,
                Behavior::WatchAgent,
                Behavior::WatchSettled,
                Behavior::InspectError,
                Behavior::SitNearError,
                Behavior::Celebrate,
                Behavior::CelebrateBig,
                Behavior::RestAfterPush,
                Behavior::UnknownOutcome,
                Behavior::GlanceAside,
                Behavior::GuardFailure,
                Behavior::GuardStuck,
                Behavior::GuardRecovery,
                Behavior::GuardCautious,
                Behavior::Sleep,
                Behavior::Explore,
                Behavior::Approach,
            ] {
                if VisualTransition::between(from, to).is_some() {
                    count += 1;
                }
            }
        }
        assert_eq!(
            count, 93,
            "between() Some count drifted; sync UI contract lists"
        );
    }

    #[test]
    fn unknown_outcome_success_and_sit_overwrites_have_full_motion_bridges() {
        // Unknown hold can also be overtaken by a pass (Celebrate/CelebrateBig)
        // or by a second open failure (SitNearError). Idle/Inspect already
        // animate; these three keep the same hold from snapping.
        let mut pass = NativeOrganism::default();
        let held = pass.command_finished(CommandKind::Other, None, None);
        assert_eq!(held.behavior, Behavior::UnknownOutcome);
        let cele = pass.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(cele.behavior, Behavior::Celebrate);
        assert_eq!(
            VisualTransition::between(held.behavior, cele.behavior),
            Some(VisualTransition::UnknownOutcomeToCelebrate)
        );

        let mut big = NativeOrganism::default();
        big.restore_repo_work_context(RepoWorkState::new(5, false, 0), 0, 0);
        let held_big = big.command_finished(CommandKind::Other, None, None);
        assert_eq!(held_big.behavior, Behavior::UnknownOutcome);
        let cele_big = big.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(cele_big.behavior, Behavior::CelebrateBig);
        assert_eq!(
            VisualTransition::between(held_big.behavior, cele_big.behavior),
            Some(VisualTransition::UnknownOutcomeToCelebrateBig)
        );

        let mut sit_hold = NativeOrganism::default();
        sit_hold.command_finished(CommandKind::BuildOrTest, Some(1), None);
        let held_sit = sit_hold.command_finished(CommandKind::Other, None, None);
        assert_eq!(held_sit.behavior, Behavior::UnknownOutcome);
        let sit = sit_hold.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(sit.behavior, Behavior::SitNearError);
        assert_eq!(
            VisualTransition::between(held_sit.behavior, sit.behavior),
            Some(VisualTransition::UnknownOutcomeToSitNearError)
        );
    }

    #[test]
    fn unknown_outcome_vigil_settles_have_full_motion_bridges() {
        // Unknown hold can settle into an open repo vigil when clear-vigil Idle
        // is not the destination: Failure/Stuck from open failures, and
        // Recovery/Cautious after a heal that still waits for push.
        let mut failure = NativeOrganism::default();
        failure.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(failure.repo_vigil(), RepoVigil::Failure);
        let held = failure.command_finished(CommandKind::Other, None, None);
        assert_eq!(held.behavior, Behavior::UnknownOutcome);
        let idle = failure.idle_reaction();
        assert_eq!(idle.behavior, Behavior::GuardFailure);
        assert_eq!(
            VisualTransition::between(held.behavior, idle.behavior),
            Some(VisualTransition::UnknownOutcomeToGuardFailure)
        );

        let mut stuck = NativeOrganism::default();
        stuck.command_finished(CommandKind::BuildOrTest, Some(1), None);
        stuck.command_finished(CommandKind::BuildOrTest, Some(1), None);
        stuck.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(stuck.repo_vigil(), RepoVigil::Stuck);
        let held = stuck.command_finished(CommandKind::Other, None, None);
        assert_eq!(held.behavior, Behavior::UnknownOutcome);
        let idle = stuck.idle_reaction();
        assert_eq!(idle.behavior, Behavior::GuardStuck);
        assert_eq!(
            VisualTransition::between(held.behavior, idle.behavior),
            Some(VisualTransition::UnknownOutcomeToGuardStuck)
        );

        let mut recovery = NativeOrganism::default();
        recovery.command_finished(CommandKind::BuildOrTest, Some(1), None);
        recovery.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(recovery.repo_vigil(), RepoVigil::Recovery);
        let held = recovery.command_finished(CommandKind::Other, None, None);
        assert_eq!(held.behavior, Behavior::UnknownOutcome);
        let idle = recovery.idle_reaction();
        assert_eq!(idle.behavior, Behavior::GuardRecovery);
        assert_eq!(
            VisualTransition::between(held.behavior, idle.behavior),
            Some(VisualTransition::UnknownOutcomeToGuardRecovery)
        );

        let mut cautious = NativeOrganism::default();
        cautious.restore_repo_work_context(RepoWorkState::new(0, true, 3), 0, 0);
        assert_eq!(cautious.repo_vigil(), RepoVigil::CautiousRecovery);
        let held = cautious.command_finished(CommandKind::Other, None, None);
        assert_eq!(held.behavior, Behavior::UnknownOutcome);
        let idle = cautious.idle_reaction();
        assert_eq!(idle.behavior, Behavior::GuardCautious);
        assert_eq!(
            VisualTransition::between(held.behavior, idle.behavior),
            Some(VisualTransition::UnknownOutcomeToGuardCautious)
        );
    }

    #[test]
    fn error_hold_heal_settle_has_full_motion_bridges() {
        // Two failures → SitNearError; sibling heal during the hold retargets
        // idle vigil to Recovery so settle must bridge SitNearError→Recovery.
        let mut organism = NativeOrganism::default();
        organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        let sit = organism.command_finished(CommandKind::BuildOrTest, Some(1), None);
        assert_eq!(sit.behavior, Behavior::SitNearError);
        assert!(organism.sync_repo_work_state(RepoWorkState::new(0, true, 1)));
        let idle = organism.idle_reaction();
        assert_eq!(idle.behavior, Behavior::GuardRecovery);
        assert_eq!(
            VisualTransition::between(sit.behavior, idle.behavior),
            Some(VisualTransition::SitNearErrorToGuardRecovery)
        );

        // Same hold with enough flips settles to Cautious.
        assert_eq!(
            VisualTransition::between(Behavior::SitNearError, Behavior::GuardCautious),
            Some(VisualTransition::SitNearErrorToGuardCautious)
        );
        // One-failure inspect hold covers Recovery/Cautious/Stuck the same way.
        assert_eq!(
            VisualTransition::between(Behavior::InspectError, Behavior::GuardRecovery),
            Some(VisualTransition::InspectErrorToGuardRecovery)
        );
        assert_eq!(
            VisualTransition::between(Behavior::InspectError, Behavior::GuardCautious),
            Some(VisualTransition::InspectErrorToGuardCautious)
        );
        assert_eq!(
            VisualTransition::between(Behavior::InspectError, Behavior::GuardStuck),
            Some(VisualTransition::InspectErrorToGuardStuck)
        );
        assert_eq!(
            VisualTransition::between(Behavior::GuardCautious, Behavior::GuardRecovery),
            Some(VisualTransition::GuardCautiousToGuardRecovery)
        );
    }

    #[test]
    fn celebrations_keep_the_organisms_cat_silhouette() {
        for behavior in [Behavior::Celebrate, Behavior::CelebrateBig] {
            for frame in 0..10 {
                assert!(
                    sprite_frame(behavior, BodyLanguage::default(), false, frame)
                        .contains("/\\_/\\"),
                    "{behavior:?} frame {frame} lost its ears"
                );
            }
        }
    }

    #[test]
    fn body_language_quantizes_the_continuous_state() {
        assert_eq!(
            BodyLanguage::from_state(LifeState::default()),
            BodyLanguage::default()
        );

        let exhausted = BodyLanguage::from_state(LifeState {
            energy: 0.10,
            boredom: 0.95,
            ..LifeState::default()
        });
        assert!(exhausted.drowsy);
        assert!(!exhausted.listless);

        let wired = BodyLanguage::from_state(LifeState {
            stress: 0.70,
            boredom: 0.90,
            ..LifeState::default()
        });
        assert!(wired.tense);
        assert!(wired.listless);
        assert!(!wired.drowsy);
    }

    #[test]
    fn drowsiness_overrides_walking_and_shows_in_the_sticky_header() {
        let drowsy = BodyLanguage {
            drowsy: true,
            ..Default::default()
        };
        for frame in 0..130 {
            let sprite = sprite_frame(Behavior::Idle, drowsy, true, frame);
            assert!(sprite.contains("zZ"), "dozing cat must not walk");
        }
        assert_eq!(sticky_glyph(Behavior::Idle, drowsy, 0), "=\\z/=");
        assert_ne!(
            sticky_glyph(Behavior::Idle, drowsy, 0),
            sticky_glyph(Behavior::RestAfterPush, BodyLanguage::default(), 0)
        );
        assert_eq!(
            sticky_glyph(Behavior::Idle, BodyLanguage::default(), 0),
            "/\\_/\\"
        );
    }

    #[test]
    fn a_listless_cat_yawns_rarely_and_a_tense_cat_flattens_its_ears() {
        let listless = BodyLanguage {
            listless: true,
            ..Default::default()
        };
        let yawns = (0..600)
            .filter(|frame| sprite_frame(Behavior::Idle, listless, false, *frame) == YAWN_FRAME)
            .count();
        assert!(yawns > 0);
        assert!(yawns * 8 < 600);

        let tense = BodyLanguage {
            tense: true,
            ..Default::default()
        };
        assert!(sprite_frame(Behavior::WatchCommand, tense, false, 0).starts_with(" =\\_/="));
        assert!(sprite_frame(Behavior::Idle, tense, false, 0).starts_with(" =\\_/="));
    }

    #[test]
    fn utility_scores_pick_the_disposition_the_state_calls_for() {
        // Clear margins (> inertia + jitter) so outcomes are deterministic.
        let rested = LifeState {
            energy: 0.9,
            mood: 0.8,
            boredom: 0.1,
            curiosity: 0.2,
            social_need: 0.2,
            attachment: 0.3,
            ..LifeState::default()
        };
        assert_eq!(
            AmbientMind::default().step(rested, 0.0, 0.0, RepoVigil::None),
            AmbientBehavior::Idle
        );

        let bored = LifeState {
            energy: 0.8,
            boredom: 1.0,
            curiosity: 1.0,
            social_need: 0.1,
            ..LifeState::default()
        };
        assert_eq!(
            AmbientMind::default().step(bored, 0.0, 0.0, RepoVigil::None),
            AmbientBehavior::Explore
        );

        let lonely = LifeState {
            energy: 0.9,
            boredom: 0.0,
            curiosity: 0.0,
            social_need: 1.0,
            attachment: 1.0,
            ..LifeState::default()
        };
        assert_eq!(
            AmbientMind::default().step(lonely, 0.0, 0.0, RepoVigil::None),
            AmbientBehavior::Approach
        );

        // A long quiet stretch tilts a merely tired mind toward sleep.
        let tired = LifeState {
            energy: 0.5,
            boredom: 0.3,
            curiosity: 0.2,
            social_need: 0.2,
            attachment: 0.2,
            ..LifeState::default()
        };
        assert_eq!(
            AmbientMind::default().step(tired, 60.0, 0.0, RepoVigil::None),
            AmbientBehavior::Sleep
        );
    }

    #[test]
    fn exhaustion_overrides_scoring_and_dispositions_hold_before_rescoring() {
        let mut mind = AmbientMind::default();
        let exhausted = LifeState {
            energy: 0.1,
            boredom: 1.0,
            curiosity: 1.0,
            ..LifeState::default()
        };
        assert_eq!(
            mind.step(exhausted, 0.0, 0.0, RepoVigil::None),
            AmbientBehavior::Sleep
        );

        // Held for 2.5s even when the state now argues for something else.
        let recovered = LifeState {
            energy: 0.9,
            boredom: 1.0,
            curiosity: 1.0,
            social_need: 0.1,
            ..LifeState::default()
        };
        assert_eq!(
            mind.step(recovered, 0.0, 1.0, RepoVigil::None),
            AmbientBehavior::Sleep
        );
        assert_eq!(
            mind.step(recovered, 0.0, 1.0, RepoVigil::None),
            AmbientBehavior::Sleep
        );
        assert_eq!(
            mind.step(recovered, 0.0, 1.0, RepoVigil::None),
            AmbientBehavior::Explore
        );

        mind.interrupt();
        assert_eq!(mind.current(), AmbientBehavior::Idle);

        // Hostile inputs never panic and always yield a valid disposition.
        let mut hostile = AmbientMind::default();
        for dt in [f32::NAN, f32::INFINITY, -3.0, 1e30] {
            hostile.step(LifeState::default(), f32::NAN, dt, RepoVigil::None);
        }
    }

    #[test]
    fn repo_vigils_keep_distinct_watch_but_never_override_exhaustion() {
        let mut mind = AmbientMind::default();
        let restless = LifeState {
            energy: 0.8,
            boredom: 1.0,
            curiosity: 1.0,
            ..LifeState::default()
        };
        for (vigil, expected) in [
            (RepoVigil::Failure, AmbientBehavior::GuardFailure),
            (RepoVigil::Stuck, AmbientBehavior::GuardStuck),
            (RepoVigil::Recovery, AmbientBehavior::GuardRecovery),
            (RepoVigil::CautiousRecovery, AmbientBehavior::GuardCautious),
        ] {
            let mut mapped = AmbientMind::default();
            assert_eq!(mapped.step(restless, 60.0, 0.0, vigil), expected);
        }
        assert_eq!(
            mind.step(restless, 60.0, 0.0, RepoVigil::Recovery),
            AmbientBehavior::GuardRecovery
        );
        assert_eq!(mind.current(), AmbientBehavior::GuardRecovery);

        let exhausted = LifeState {
            energy: 0.1,
            ..restless
        };
        assert_eq!(
            mind.step(exhausted, 60.0, 0.0, RepoVigil::Recovery),
            AmbientBehavior::Sleep
        );

        let barely_recovered = LifeState {
            energy: FORCED_REST_ENERGY + 0.01,
            ..restless
        };
        assert_eq!(
            mind.step(barely_recovered, 60.0, 1.0, RepoVigil::Recovery),
            AmbientBehavior::Sleep,
            "crossing the force-rest edge must not flutter awake"
        );
        let awake = LifeState {
            energy: REPO_VIGIL_WAKE_ENERGY,
            ..restless
        };
        assert_eq!(
            mind.step(awake, 60.0, 1.0, RepoVigil::Recovery),
            AmbientBehavior::GuardRecovery
        );

        assert_ne!(
            mind.step(restless, 0.0, 0.0, RepoVigil::None),
            AmbientBehavior::GuardRecovery,
            "clearing the durable intention must release its forced pose"
        );
    }

    #[test]
    fn an_exploring_cat_only_steps_while_actually_moving() {
        let calm = BodyLanguage::default();
        assert!(sprite_frame(Behavior::Explore, calm, false, 0).contains("> ^ <"));
        assert!(sprite_frame(Behavior::Explore, calm, true, 0).contains(">/ \\<"));
    }

    #[test]
    fn agent_commands_get_quiet_nods_and_the_big_celebrations_stay_human() {
        let mut organism = NativeOrganism::default();
        organism.set_agent_command(true);
        let started = organism.command_started(CommandKind::BuildOrTest);
        assert_eq!(started.behavior, Behavior::WatchAgent);
        assert_eq!(started.tone, Tone::Quiet);

        // Even a big recovery earns only a small, wordless celebration.
        organism.restore_repo_context(3, false, 0, 3);
        organism.set_agent_command(true);
        let recovery = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(recovery.behavior, Behavior::Celebrate);
        assert_eq!(recovery.speech, None);
        assert!(recovery.description.contains("agent-driven"));

        // The same recovery typed by the human celebrates at full strength.
        let mut human = NativeOrganism::default();
        human.restore_repo_context(3, false, 0, 3);
        let big = human.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert_eq!(big.behavior, Behavior::CelebrateBig);
        assert_eq!(big.speech, Some("终于。"));
    }

    #[test]
    fn a_repo_greeting_waits_for_the_humans_own_command() {
        let mut organism = NativeOrganism::default();
        organism.note_repo_arrival(RepoArrival::Home);
        organism.set_agent_command(true);
        let agent_start = organism.command_started(CommandKind::BuildOrTest);
        assert_eq!(agent_start.behavior, Behavior::WatchAgent);
        assert_eq!(agent_start.speech, None);
        organism.command_finished(CommandKind::BuildOrTest, Some(0), None);

        organism.set_agent_command(false);
        let human_start = organism.command_started(CommandKind::BuildOrTest);
        assert_eq!(human_start.speech, Some("回来了。"));
    }

    #[test]
    fn leaving_a_repo_cancels_its_queued_human_greeting() {
        let mut organism = NativeOrganism::default();
        organism.note_repo_arrival(RepoArrival::Home);
        organism.set_agent_command(true);
        organism.command_started(CommandKind::BuildOrTest);
        organism.command_finished(CommandKind::BuildOrTest, Some(0), None);

        organism.clear_repo_arrival();
        organism.set_agent_command(false);
        let elsewhere = organism.command_started(CommandKind::Other);
        assert_eq!(elsewhere.speech, None);
        assert!(!elsewhere.description.contains("well-known repo"));
    }

    #[test]
    fn agent_failures_spare_the_humans_confidence_and_stay_silent() {
        let mut organism = NativeOrganism::default();
        let confidence_before = organism.state().confidence;
        organism.set_agent_command(true);
        let failure = organism.command_finished(CommandKind::BuildOrTest, Some(101), None);
        assert_eq!(failure.speech, None);
        assert!(failure.description.contains("agent-driven"));
        assert_eq!(organism.state().confidence, confidence_before);

        // A sensitized first crack never triggers for the Agent's failure.
        let mut proud = NativeOrganism::default();
        proud.restore_repo_context(0, false, 9, 0);
        proud.set_agent_command(true);
        let crack = proud.command_finished(CommandKind::BuildOrTest, Some(101), None);
        assert!(!crack.description.contains("first crack"));

        // An agent push never claims the human's follow-through phrase.
        let mut push = NativeOrganism::default();
        push.restore_repo_context(1, false, 0, 1);
        push.command_finished(CommandKind::BuildOrTest, Some(0), None);
        push.set_agent_command(true);
        let pushed = push.command_finished(CommandKind::GitPush, Some(0), None);
        assert_eq!(pushed.speech, None);
    }

    #[test]
    fn agent_execution_lost_reacts_with_restrained_caution() {
        let mut organism = NativeOrganism::default();
        organism.set_agent_command(true);
        organism.command_started(CommandKind::BuildOrTest);
        let lost = organism.agent_execution_lost();
        assert_eq!(lost.behavior, Behavior::UnknownOutcome);
        assert_eq!(lost.tone, Tone::Warning);
        assert_eq!(lost.speech, None);

        // The stale flag is gone: the next human command is fully owned.
        let success = organism.command_finished(CommandKind::BuildOrTest, Some(0), None);
        assert!(!success.description.contains("agent-driven"));
        assert_eq!(success.speech, Some("过了。"));
    }

    #[test]
    fn agent_pulses_feed_social_need_and_stay_bounded() {
        let mut state = LifeState::default();
        let social_before = state.social_need;
        state = agent_pulse(state, AgentPulse::Working);
        state = agent_pulse(state, AgentPulse::AskingReview);
        state = agent_pulse(state, AgentPulse::Finished);
        state = agent_pulse(state, AgentPulse::Gone);
        assert!(state.social_need > social_before);

        for _ in 0..10_000 {
            state = agent_pulse(state, AgentPulse::Gone);
        }
        assert!(state
            .values()
            .into_iter()
            .all(|value| (0.0..=1.0).contains(&value)));
    }

    #[test]
    fn ambient_dispositions_map_to_their_display_behaviors() {
        assert_eq!(AmbientBehavior::Idle.display(), Behavior::Idle);
        assert_eq!(AmbientBehavior::Sleep.display(), Behavior::Sleep);
        assert_eq!(AmbientBehavior::Explore.display(), Behavior::Explore);
        assert_eq!(AmbientBehavior::Approach.display(), Behavior::Approach);
        assert_eq!(
            AmbientBehavior::GuardFailure.display(),
            Behavior::GuardFailure
        );
        assert_eq!(AmbientBehavior::GuardStuck.display(), Behavior::GuardStuck);
        assert_eq!(
            AmbientBehavior::GuardRecovery.display(),
            Behavior::GuardRecovery
        );
        assert_eq!(
            AmbientBehavior::GuardCautious.display(),
            Behavior::GuardCautious
        );
    }

    #[test]
    fn correction_pulses_stay_bounded_and_scale_with_dismissal_streaks() {
        let mut state = LifeState::default();
        for _ in 0..1_000 {
            state = correction_dismissed(state, 4);
        }
        assert!(state
            .values()
            .into_iter()
            .all(|value| (0.0..=1.0).contains(&value)));
        assert_eq!(state.boredom, 1.0);

        let single = correction_dismissed(LifeState::default(), 1);
        let heavy = correction_dismissed(LifeState::default(), 4);
        assert!(heavy.boredom > single.boredom);

        let accepted = correction_accepted(LifeState::default());
        assert!(accepted.confidence > LifeState::default().confidence);
    }

    #[test]
    fn persisted_state_and_repo_failure_streak_resume_safely() {
        let mut organism = NativeOrganism::from_persisted_state(LifeState {
            energy: f32::NAN,
            mood: 2.0,
            ..LifeState::default()
        });
        assert_eq!(organism.state().energy, 0.5);
        assert_eq!(organism.state().mood, 1.0);

        organism.restore_build_failures(3);
        organism.command_started(CommandKind::BuildOrTest);
        let reaction = organism.command_finished(CommandKind::BuildOrTest, Some(0), Some(100));
        assert_eq!(reaction.behavior, Behavior::CelebrateBig);
        assert_eq!(reaction.speech, Some("终于。"));
    }

    #[test]
    fn sustained_success_has_one_quiet_completion_pose_at_the_boundary() {
        for (duration, expected) in [
            (None, Behavior::Idle),
            (Some(0), Behavior::Idle),
            (Some(59_999), Behavior::Idle),
            (Some(60_000), Behavior::Celebrate),
            (Some(60_001), Behavior::Celebrate),
            (Some(u64::MAX), Behavior::Celebrate),
        ] {
            let mut organism = NativeOrganism::default();
            organism.command_started(CommandKind::Other);
            let reaction = organism.command_finished(CommandKind::Other, Some(0), duration);
            assert_eq!(reaction.behavior, expected, "{duration:?}");
            assert_eq!(reaction.tone, Tone::Quiet);
            assert_eq!(reaction.speech, None);
            assert!(reaction.description.starts_with("command finished cleanly"));
            assert_eq!(
                reaction.hold_duration(),
                Duration::from_millis(if expected == Behavior::Celebrate {
                    1800
                } else {
                    1500
                })
            );
        }
    }

    #[test]
    fn sustained_completion_requires_confirmed_success() {
        for exit in [None, Some(1), Some(130), Some(-1)] {
            let mut organism = NativeOrganism::default();
            organism.command_started(CommandKind::Other);
            let reaction = organism.command_finished(CommandKind::Other, exit, Some(60_000));
            assert_eq!(
                reaction.behavior,
                if exit.is_none() {
                    Behavior::UnknownOutcome
                } else {
                    Behavior::InspectError
                }
            );
        }
    }

    #[test]
    fn sustained_success_does_not_invent_progress_or_amplify_life_rewards() {
        let finish = |duration| {
            let mut organism = NativeOrganism::default();
            organism.command_started(CommandKind::Other);
            organism.command_finished(CommandKind::Other, Some(0), duration);
            organism
        };
        let short = finish(Some(10));
        let long = finish(Some(60_000));
        assert_eq!(short.state().values(), long.state().values());
        assert_eq!(short.repo_work_state(), long.repo_work_state());
        assert_eq!(long.idle_reaction().behavior, Behavior::Idle);
    }

    #[test]
    fn sustained_success_preserves_unresolved_and_recovered_repo_work() {
        for work in [
            RepoWorkState::new(1, false, 0),
            RepoWorkState::new(3, false, 0),
            RepoWorkState::new(0, true, 1),
            RepoWorkState::new(0, true, 3),
        ] {
            let mut organism = NativeOrganism::default();
            organism.sync_repo_work_state(work);
            let idle = organism.idle_reaction().behavior;
            organism.command_started(CommandKind::Other);
            let reaction = organism.command_finished(CommandKind::Other, Some(0), Some(60_000));
            assert_eq!(reaction.behavior, Behavior::Celebrate);
            assert_eq!(reaction.tone, Tone::Quiet);
            assert_eq!(organism.repo_work_state(), work);
            assert_eq!(organism.idle_reaction().behavior, idle);
        }
    }

    #[test]
    fn sustained_success_retains_build_push_and_correction_semantics() {
        let mut build = NativeOrganism::default();
        build.command_started(CommandKind::BuildOrTest);
        let passed = build.command_finished(CommandKind::Other, Some(0), Some(60_000));
        assert_eq!(
            (passed.behavior, passed.tone),
            (Behavior::Celebrate, Tone::Success)
        );
        assert_eq!(passed.speech, Some("过了。"));
        let mut push = NativeOrganism::default();
        push.command_started(CommandKind::GitPush);
        let pushed = push.command_finished(CommandKind::Other, Some(0), Some(60_000));
        assert_eq!(pushed.behavior, Behavior::RestAfterPush);
        let mut corrected = NativeOrganism::default();
        corrected.note_assisted_command();
        corrected.command_started(CommandKind::Other);
        let accepted = corrected.command_finished(CommandKind::Other, Some(0), Some(60_000));
        assert_eq!(accepted.tone, Tone::Success);
        assert!(accepted.description.starts_with("corrected command worked"));
    }

    #[test]
    fn sustained_agent_success_is_quiet_and_new_work_supersedes_it() {
        let mut organism = NativeOrganism::default();
        organism.set_agent_command(true);
        organism.command_started(CommandKind::Other);
        let finished = organism.command_finished(CommandKind::Other, Some(0), Some(60_000));
        assert_eq!(
            (finished.behavior, finished.tone),
            (Behavior::Celebrate, Tone::Quiet)
        );
        assert_eq!(finished.speech, None);
        let next = organism.command_started(CommandKind::Other);
        assert_eq!(next.behavior, Behavior::WatchCommand);
        assert_eq!(next.speech, None);
        let unknown = organism.command_finished(CommandKind::Other, None, Some(60_000));
        assert_eq!(unknown.behavior, Behavior::UnknownOutcome);
    }

    #[test]
    fn reaction_holds_are_the_shared_bounded_presentation_contract() {
        for (behavior, millis) in [
            (Behavior::Idle, 1500),
            (Behavior::Celebrate, 2500),
            (Behavior::InspectError, 5000),
            (Behavior::SitNearError, 10000),
            (Behavior::CelebrateBig, 7000),
            (Behavior::RestAfterPush, 5000),
            (Behavior::UnknownOutcome, 4500),
            (Behavior::GlanceAside, 1400),
            (Behavior::WatchCommand, 2500),
            (Behavior::Sleep, 2500),
            (Behavior::Explore, 2500),
            (Behavior::Approach, 2500),
            (Behavior::WatchAgent, 2500),
            (Behavior::WatchSettled, 2500),
            (Behavior::GuardFailure, 2500),
            (Behavior::GuardStuck, 2500),
            (Behavior::GuardRecovery, 2500),
            (Behavior::GuardCautious, 2500),
        ] {
            for tone in [
                Tone::Quiet,
                Tone::Active,
                Tone::Success,
                Tone::Error,
                Tone::Warning,
            ] {
                let reaction = Reaction {
                    behavior,
                    tone,
                    description: String::new(),
                    speech: None,
                };
                let expected = if behavior == Behavior::Celebrate && tone == Tone::Quiet {
                    1800
                } else {
                    millis
                };
                assert_eq!(reaction.hold_duration(), Duration::from_millis(expected));
            }
        }
    }
}
